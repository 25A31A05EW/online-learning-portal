# CertiLearn: Course & Certification Management Platform

A modern, responsive online learning and accreditation platform built with React, TypeScript, and a decoupled C++ REST API backend powered by MySQL 8.0.

![CertiLearn Platform](https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1200&q=80)

---

## 1. Key Pedagogical Architecture

### Primary Teaching Method: Recorded Video Classes
- Instruction is delivered through high-definition, **on-demand recorded video lectures**.
- Students learn asynchronously at their own convenience without rigid daily live-lecture requirements.
- Full player controls: 10s skip/rewind, speed adjustment (0.75x to 2x), fullscreen, and volume control.
- **Second-Precision Progress Tracking**: Resumes playback automatically where the student left off.
- Lessons marked completed automatically upon reaching 90% or via explicit manual confirmation.

### Dedicated Teacher Doubt-Clearing Sessions
- **Live online sessions are conducted strictly at scheduled times for resolving student doubts** (not for daily routine lecture delivery).
- Teachers schedule meetings with course topic, date, start/end time, and Google Meet or Zoom link.
- Students RSVP, receive reminders, submit questions ahead of time with screenshots, and attend live Q&A.
- Recorded explanations and notes are archived for review after the session completes.

### 20-Question Timed Online Examination
- Comprehensive final evaluation consisting of 20 multiple-choice questions (weight: 100 marks).
- Live 20-minute countdown timer with interactive question palette.
- Strict **70% passing threshold** (14/20 correct) required to earn certification.
- Instant score computation with detailed answer review and explanations.

### Automatic Verifiable Certificate Generation
- High-resolution, archival-quality digital certificate generated immediately upon passing.
- Contains student name, course title, completion date, unique Certificate ID (e.g., `CERT-2026-PY-9842`), instructor signature, and academic director seal.
- **Public Verification Registry**: Anyone can enter the Certificate ID or verification code to validate authentic issuance.

---

## 2. Multi-Role Permissions

| Feature | Student | Teacher | Admin |
| :--- | :---: | :---: | :---: |
| Browse & Search Recorded Courses | ✅ | ✅ | ✅ |
| Watch Recorded Lectures & Save Progress | ✅ | ✅ | ✅ |
| Download PDF Notes & Study Materials | ✅ | ✅ | ✅ |
| Submit Doubts with Screenshots | ✅ | ✅ | ✅ |
| Answer Doubts & Mark Resolved | ❌ | ✅ | ✅ |
| Schedule Google Meet Doubt Sessions | ❌ | ✅ | ✅ |
| RSVP / Attend Scheduled Doubt Sessions | ✅ | ✅ | ✅ |
| Submit Coursework Assignments | ✅ | ❌ | ❌ |
| Grade Assignments with Feedback | ❌ | ✅ | ✅ |
| Attempt 20-Question Final Examination | ✅ | ❌ | ❌ |
| Earn & Download Accredited Certificate | ✅ | ❌ | ❌ |
| Public Certificate Verification Registry | ✅ | ✅ | ✅ |
| Create New Courses, Modules & Lessons | ❌ | ✅ | ✅ |
| Platform Analytics & User Management | ❌ | ❌ | ✅ |
| Relational MySQL Schema & C++ Audit | ❌ | ❌ | ✅ |

---

## 3. Technology Stack & Directory Structure

```
certilearn/
├── backend-cpp/                 # High-performance C++ REST Backend
│   ├── CMakeLists.txt           # CMake 3.16+ build configuration
│   ├── Dockerfile               # Production container image
│   ├── schema.sql               # 17 normalized MySQL 8.0 tables with foreign keys
│   ├── README.md                # C++ setup & Crow/Drogon compilation steps
│   └── src/
│       └── main.cpp             # REST routing & MySQL connection pool
├── src/
│   ├── assets/images/           # High-resolution generated educational banners
│   ├── components/
│   │   ├── Navbar.tsx           # Top Bar (3-zone contract, role switcher)
│   │   ├── Footer.tsx           # Accreditation & academic contact links
│   │   ├── Hero.tsx             # "Learn Anytime, Anywhere. Build Your Skills."
│   │   ├── CourseCard.tsx       # Unboxed metadata course presentation
│   │   ├── CourseExplorer.tsx   # Category filtering & search engine
│   │   ├── VideoPlayer.tsx      # Recorded player with resume & speed controls
│   │   ├── ClassroomView.tsx    # Unified player, notes, doubts, exam tab
│   │   ├── DoubtSessionsView.tsx# Scheduled Meet/Zoom doubt clearing
│   │   ├── DoubtModal.tsx       # Question submission with screenshots
│   │   ├── ExamModal.tsx        # 20-question timed exam (70% pass mark)
│   │   ├── CertificateModal.tsx # Canvas-rendered verifiable PDF/PNG credential
│   │   ├── CertificateVerifier.tsx # Public credential verification registry
│   │   ├── StudentDashboard.tsx # Learning progress & certificate portfolio
│   │   ├── TeacherDashboard.tsx # Studio: course builder, grader, doubt host
│   │   ├── AdminDashboard.tsx   # Platform telemetry, user management
│   │   ├── AuthModal.tsx        # Authentication & 1-click persona switch
│   │   └── CppArchitectureModal.tsx # Live C++ & MySQL schema browser
│   ├── context/
│   │   ├── AuthContext.tsx      # User authentication & role management
│   │   └── CourseContext.tsx    # State synchronization & progress storage
│   ├── data/
│   │   └── initialData.ts       # Sample curricula, exam questions, doubts
│   ├── types/
│   │   └── index.ts             # TypeScript interfaces
│   ├── App.tsx                  # Root router & layout orchestration
│   ├── index.css                # Tailwind CSS v4 styling & print styles
│   └── main.tsx                 # React entry point
└── package.json
```

---

## 4. Quick Start (Web Application)

```bash
# Install dependencies
npm install

# Start Vite development server on port 3000
npm run dev

# Build production bundle
npm run build
```

---

## 5. C++ Backend & MySQL Execution Guide

See `backend-cpp/README.md` for full instructions.

```bash
# 1. Initialize MySQL Database
mysql -u root -p < backend-cpp/schema.sql

# 2. Compile C++ Backend with CMake
cd backend-cpp
mkdir -p build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
make -j$(nproc)

# 3. Start C++ REST Service (Port 8080)
./certilearn_server
```

---

## 6. Demonstration Accounts (1-Click Switch in Header)

- **Student Persona**: `Rohan Sharma` (`rohan.sharma@example.com`)
  - Enrolled in Python Programming Masterclass
  - Recorded video progress tracked with resume points
  - Unlocked final exam with certificate `CERT-2026-PY-9842`
- **Teacher Persona**: `Dr. Elena Vance` (`elena.vance@certilearn.edu`)
  - Course author of Python Masterclass & AI Foundations
  - Hosts scheduled Thursday Google Meet doubt-clearing sessions
  - Answers unresolved doubts and grades coursework submissions
- **Admin Persona**: `Chief Administrator` (`admin@certilearn.edu`)
  - Platform metrics supervisor
  - User and teacher role management
  - Certificate audit and MySQL schema inspector
