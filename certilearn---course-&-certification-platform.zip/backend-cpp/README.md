# CertiLearn C++ Backend Service & MySQL Database

High-performance REST API architecture for the CertiLearn Course & Certification Management Platform.

## Architecture Highlights
- **Framework**: C++17 with Crow / Drogon REST architecture.
- **Database**: MySQL 8.0+ / MariaDB 10.5+ with InnoDB storage engine.
- **Primary Teaching Paradigm**: Recorded Video Classes with second-precision resume position & progress tracking.
- **Teacher Live Sessions**: Dedicated scheduled doubt-clearing sessions using Google Meet / Zoom links (No daily live teaching overhead).
- **Certification Engine**: Automatic certificate generation and cryptographic public verification upon achieving $\ge 70\%$ on final exams.

---

## 1. Database Setup (MySQL)

Create the database and import the relational schema:

```bash
# Log in to MySQL server
mysql -u root -p

# Inside MySQL prompt (or pass directly):
CREATE DATABASE certilearn_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

# Import the complete schema
mysql -u root -p certilearn_db < schema.sql
```

The schema provisions 17 tables:
- `users`, `course_categories`, `courses`, `modules`, `lessons`
- `enrollments`, `video_progress`, `study_materials`
- `doubts`, `doubt_replies`, `doubt_sessions`, `session_registrations`
- `assignments`, `assignment_submissions`, `exam_questions`, `exam_attempts`, `certificates`

---

## 2. Building the C++ Backend

### Prerequisites
- GCC 11+ or Clang 14+
- CMake 3.16+
- OpenSSL (`libssl-dev`)
- MySQL Client Development Libraries (`libmysqlclient-dev`)
- Threads & POSIX sockets

### Native Build Instructions
```bash
# Navigate to backend directory
cd backend-cpp

# Generate build configuration
mkdir -p build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release

# Compile
make -j$(nproc)

# Run server on port 8080
./certilearn_server
```

### Docker Build Instructions
```bash
docker build -t certilearn-backend-cpp .
docker run -p 8080:8080 --name certilearn-cpp certilearn-backend-cpp
```

---

## 3. REST API Endpoints Specification

### Authentication & Users
- `POST /api/auth/register` — Register student or teacher account
- `POST /api/auth/login` — Authenticate and retrieve JWT bearer token
- `GET  /api/auth/me` — Retrieve current authenticated session

### Recorded Courses & Video Progress
- `GET  /api/courses` — List all published courses with category filtering
- `GET  /api/courses/:id` — Get course details, syllabus, modules, and lessons
- `POST /api/courses/:id/enroll` — Enroll student in a course
- `POST /api/video/progress` — Save video timestamp, duration watched, and completion flag
- `GET  /api/video/progress/:courseId/:lessonId` — Retrieve last watched second for seamless resumption

### Study Materials
- `GET  /api/courses/:id/materials` — Retrieve downloadable PDF notes, PPT slides, and code examples
- `POST /api/courses/:id/materials` — Teacher upload study document

### Doubt Clearing & Live Sessions
- `GET  /api/doubts?courseId=...` — View questions filterable by pending/resolved
- `POST /api/doubts` — Submit student question with optional screenshot
- `POST /api/doubts/:id/replies` — Teacher/Student reply to doubt thread
- `PUT  /api/doubts/:id/resolve` — Mark doubt as resolved
- `GET  /api/sessions/upcoming` — List scheduled teacher doubt sessions
- `POST /api/sessions/schedule` — Teacher schedule online Google Meet/Zoom session
- `POST /api/sessions/:id/register` — Student RSVP for doubt session

### Assignments & Examinations
- `POST /api/assignments/:id/submit` — Submit coursework assignment
- `POST /api/assignments/grade` — Teacher grade submission with marks and feedback
- `GET  /api/exams/:courseId` — Fetch timed 20-question certification exam
- `POST /api/exams/:courseId/submit` — Automatically evaluate score; issue certificate if $\ge 70\%$

### Certificate Verification
- `GET  /api/certificates/verify/:certId` — Public verification lookup by Certificate ID or Verification Code
