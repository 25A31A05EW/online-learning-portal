import { Course, Doubt, DoubtSession, Assignment, ExamQuestion, Certificate, User, AssignmentSubmission } from '../types';

export const INITIAL_USERS: User[] = [
  {
    id: 'user-student-1',
    name: 'Rohan Sharma',
    email: 'rohan.sharma@example.com',
    phone: '+91 98765 43210',
    role: 'student',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    bio: 'Aspiring software developer passionate about Python, backend systems, and data engineering.',
    joinedDate: '2026-01-15',
  },
  {
    id: 'user-teacher-1',
    name: 'Dr. Elena Vance',
    email: 'elena.vance@certilearn.edu',
    phone: '+1 415 555 0192',
    role: 'teacher',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80',
    bio: 'Senior Computer Science Professor with 14+ years teaching algorithms, Python, and scalable distributed systems.',
    joinedDate: '2025-08-10',
  },
  {
    id: 'user-teacher-2',
    name: 'Marcus Sterling',
    email: 'marcus.s@certilearn.edu',
    phone: '+1 415 555 0148',
    role: 'teacher',
    avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=200&q=80',
    bio: 'Principal Database Architect & Full Stack Lead specializing in MySQL schema optimization and modern React.',
    joinedDate: '2025-09-01',
  },
  {
    id: 'user-admin-1',
    name: 'Chief Admin',
    email: 'admin@certilearn.edu',
    phone: '+1 800 555 0100',
    role: 'admin',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
    bio: 'Platform Director overseeing academic accreditations, curriculum standards, and certificate issuance.',
    joinedDate: '2025-01-01',
  },
];

export const INITIAL_COURSES: Course[] = [
  {
    id: 'course-python-101',
    title: 'Python Programming Masterclass: From Fundamentals to Production',
    subtitle: 'Comprehensive recorded curriculum covering syntax, OOP, modules, and data structures with weekly doubt-clearing sessions.',
    description: 'Master Python through structured, self-paced recorded video lectures. You will progress from writing your first line of code to building enterprise-grade backend scripts. Doubts are addressed during scheduled live teacher sessions.',
    category: 'Programming Languages',
    level: 'Beginner',
    durationHours: 32,
    teacherId: 'user-teacher-1',
    teacherName: 'Dr. Elena Vance',
    teacherAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80',
    teacherTitle: 'Professor of Computer Science & Author',
    imageUrl: '/src/assets/images/course_python_hero_1794126944045.jpg',
    rating: 4.9,
    reviewCount: 1420,
    status: 'published',
    passingPercentage: 70,
    enrolledStudentsCount: 3840,
    requirements: [
      'No prior programming knowledge required; beginners welcome.',
      'A computer (Windows, macOS, or Linux) with internet access to download Python 3.12+.',
      'Dedication to complete coding exercises and the 20-question final exam.'
    ],
    whatYouWillLearn: [
      'Core syntax, variables, conditional logic, and looping structures',
      'Advanced data structures: Lists, Tuples, Dictionaries, and Sets',
      'Object-Oriented Programming principles with clean class hierarchies',
      'Exception handling, file I/O operations, and standard library modules',
      'Automated testing, debugging workflows, and script packaging'
    ],
    modules: [
      {
        id: 'mod-py-1',
        courseId: 'course-python-101',
        title: 'Module 1: Introduction to Python',
        order: 1,
        lessons: [
          {
            id: 'les-py-1-1',
            moduleId: 'mod-py-1',
            title: 'Lesson 1: Introduction to Python & Language Philosophy',
            durationMinutes: 18,
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
            description: 'Discover why Python became the worlds most popular programming language, its design philosophy, and typical application domains.',
            codeSnippet: '# Python philosophy: Readability counts!\nprint("Welcome to CertiLearn Python Masterclass!")\nimport this',
            codeLanguage: 'python',
            order: 1
          },
          {
            id: 'les-py-1-2',
            moduleId: 'mod-py-1',
            title: 'Lesson 2: Installing Python & Setting Up Development Environment',
            durationMinutes: 24,
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
            description: 'Step-by-step walkthrough installing Python 3.12, configuring virtual environments (venv), and using VS Code with syntax highlighters.',
            codeSnippet: '# Terminal command to check version\n# python3 --version\n# python3 -m venv venv\n# source venv/bin/activate',
            codeLanguage: 'bash',
            order: 2
          },
          {
            id: 'les-py-1-3',
            moduleId: 'mod-py-1',
            title: 'Lesson 3: Writing Your First Python Program',
            durationMinutes: 20,
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
            description: 'Understand the Python execution model, bytecode interpretation, and running scripts from the CLI with standard output.',
            codeSnippet: 'def greet_user(name: str) -> str:\n    return f"Hello, {name}! Ready to master Python?"\n\nif __name__ == "__main__":\n    print(greet_user("Learner"))',
            codeLanguage: 'python',
            order: 3
          }
        ]
      },
      {
        id: 'mod-py-2',
        courseId: 'course-python-101',
        title: 'Module 2: Python Fundamentals',
        order: 2,
        lessons: [
          {
            id: 'les-py-2-1',
            moduleId: 'mod-py-2',
            title: 'Lesson 1: Variables, Memory References & Identifiers',
            durationMinutes: 22,
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
            description: 'Deep dive into Python dynamic typing, memory management, garbage collection references, and naming conventions.',
            codeSnippet: 'course_title = "Python Masterclass"\nstudent_count = 3840\ncompletion_rate = 94.6\nis_active = True\n\nprint(type(course_title), id(course_title))',
            codeLanguage: 'python',
            order: 1
          },
          {
            id: 'les-py-2-2',
            moduleId: 'mod-py-2',
            title: 'Lesson 2: Primitive & Collection Data Types',
            durationMinutes: 30,
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
            description: 'Explore numbers, strings, lists, tuples, sets, and dictionaries with time complexities of common operations.',
            codeSnippet: '# Dictionaries and list comprehensions\nscores = {"Alice": 95, "Bob": 82, "Charlie": 88}\nhonor_roll = [student for student, score in scores.items() if score >= 85]\nprint("Honor Roll:", honor_roll)',
            codeLanguage: 'python',
            order: 2
          },
          {
            id: 'les-py-2-3',
            moduleId: 'mod-py-2',
            title: 'Lesson 3: Arithmetic, Comparison & Logical Operators',
            durationMinutes: 19,
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4',
            description: 'Master arithmetic operations, modulo, floor division, precedence rules, and short-circuit boolean evaluation.',
            codeSnippet: 'a = 15\nb = 4\nprint(f"Division: {a / b}, Floor: {a // b}, Remainder: {a % b}")\n# Short-circuit logical evaluation\nresult = (b != 0) and (a / b > 3)',
            codeLanguage: 'python',
            order: 3
          }
        ]
      },
      {
        id: 'mod-py-3',
        courseId: 'course-python-101',
        title: 'Module 3: Control Statements',
        order: 3,
        lessons: [
          {
            id: 'les-py-3-1',
            moduleId: 'mod-py-3',
            title: 'Lesson 1: Conditional Branching (If-Else & Elif)',
            durationMinutes: 25,
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4',
            description: 'Write robust decision logic, ternary operators, and structural pattern matching introduced in modern Python.',
            codeSnippet: 'score = 88\nif score >= 90:\n    grade = "A"\nelif score >= 75:\n    grade = "B"\nelif score >= 70:\n    grade = "Pass"\nelse:\n    grade = "Fail"\nprint(f"Grade: {grade}")',
            codeLanguage: 'python',
            order: 1
          },
          {
            id: 'les-py-3-2',
            moduleId: 'mod-py-3',
            title: 'Lesson 2: Loops (For, While, Range & Iterators)',
            durationMinutes: 28,
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
            description: 'Iterating over sequences, using range(), enumerate(), zip(), and handling loop control with break and continue.',
            codeSnippet: 'for idx, item in enumerate(["Python", "MySQL", "React"], start=1):\n    print(f"Subject {idx}: {item}")',
            codeLanguage: 'python',
            order: 2
          },
          {
            id: 'les-py-3-3',
            moduleId: 'mod-py-3',
            title: 'Lesson 3: Nested Loops & Complex Algorithmic Flow',
            durationMinutes: 26,
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4',
            description: 'Multi-dimensional arrays, matrix manipulation with nested loops, and avoidance of quadratic slowdowns.',
            codeSnippet: 'matrix = [\n    [1, 2, 3],\n    [4, 5, 6],\n    [7, 8, 9]\n]\ntransposed = [[row[i] for row in matrix] for i in range(3)]\nprint("Transposed:", transposed)',
            codeLanguage: 'python',
            order: 3
          }
        ]
      }
    ],
    materials: [
      {
        id: 'mat-py-1',
        courseId: 'course-python-101',
        lessonId: 'les-py-1-1',
        title: 'Python Official Course Notes & Cheat Sheet (Modules 1-3)',
        type: 'pdf',
        fileSize: '4.2 MB',
        downloadUrl: '#download-notes-pdf',
        description: 'Comprehensive 48-page distilled reference covering Python syntax, memory diagrams, and built-in function cheat sheet.',
        uploadedAt: '2026-02-10'
      },
      {
        id: 'mat-py-2',
        courseId: 'course-python-101',
        lessonId: 'les-py-2-2',
        title: 'Lecture Slides: Data Types, Memory Layout & Pointers',
        type: 'ppt',
        fileSize: '8.7 MB',
        downloadUrl: '#download-slides-ppt',
        description: 'Keynote presentation slides with visual diagrams of PyObject headers, reference counting, and hash map collision handling.',
        uploadedAt: '2026-02-12'
      },
      {
        id: 'mat-py-3',
        courseId: 'course-python-101',
        lessonId: 'les-py-3-3',
        title: 'Hands-on Code Repository: 50 Algorithmic Python Problems',
        type: 'code',
        fileSize: '1.4 MB',
        downloadUrl: '#download-code-zip',
        description: 'Ready-to-run Python solution scripts and unit tests covering conditional logic, pattern matching, and nested iteration.',
        uploadedAt: '2026-02-15'
      }
    ]
  },
  {
    id: 'course-mysql-201',
    title: 'Relational Database Design & MySQL Mastery',
    subtitle: 'From normalization and indexes to high-throughput query execution and transaction ACID isolation.',
    description: 'Learn professional relational modeling, write complex joins, subqueries, and window functions, and optimize queries with EXPLAIN ANALYZE in MySQL 8.0.',
    category: 'Database Management',
    level: 'Intermediate',
    durationHours: 28,
    teacherId: 'user-teacher-2',
    teacherName: 'Marcus Sterling',
    teacherAvatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=200&q=80',
    teacherTitle: 'Principal Database Architect',
    imageUrl: '/src/assets/images/course_database_mysql_1794126944526.jpg',
    rating: 4.8,
    reviewCount: 910,
    status: 'published',
    passingPercentage: 70,
    enrolledStudentsCount: 2150,
    requirements: [
      'Basic familiarity with command-line interfaces.',
      'Understanding of basic data structures is beneficial but not required.'
    ],
    whatYouWillLearn: [
      'Relational schema design from 1NF to BCNF normalization',
      'Advanced SQL: CTEs, Window Functions, and Recursive queries',
      'B-Tree and Hash indexing strategies to prevent full table scans',
      'ACID transactions, deadlocks, and InnoDB buffer pool tuning'
    ],
    modules: [
      {
        id: 'mod-sql-1',
        courseId: 'course-mysql-201',
        title: 'Module 1: Relational Modeling & DDL Foundations',
        order: 1,
        lessons: [
          {
            id: 'les-sql-1-1',
            moduleId: 'mod-sql-1',
            title: 'Lesson 1: Relational Algebra & ER Diagrams',
            durationMinutes: 22,
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
            description: 'Entities, relationships, cardinality constraints, and foreign key rules.',
            codeSnippet: 'CREATE TABLE users (\n  id INT PRIMARY KEY AUTO_INCREMENT,\n  email VARCHAR(255) UNIQUE NOT NULL,\n  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n);',
            codeLanguage: 'sql',
            order: 1
          },
          {
            id: 'les-sql-1-2',
            moduleId: 'mod-sql-1',
            title: 'Lesson 2: Data Normalization (1NF, 2NF, 3NF & BCNF)',
            durationMinutes: 28,
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
            description: 'Eliminating update anomalies, transitive dependencies, and redundancy.',
            codeSnippet: '-- Decomposing orders into header and order_items\nSELECT * FROM orders JOIN order_items ON orders.id = order_items.order_id;',
            codeLanguage: 'sql',
            order: 2
          }
        ]
      }
    ],
    materials: [
      {
        id: 'mat-sql-1',
        courseId: 'course-mysql-201',
        title: 'Production MySQL Schema Template & Migration DDL',
        type: 'code',
        fileSize: '350 KB',
        downloadUrl: '#download-schema-sql',
        description: 'Standard enterprise SQL schema file with foreign keys, indexes, and sample seeds.',
        uploadedAt: '2026-02-14'
      }
    ]
  },
  {
    id: 'course-webdev-301',
    title: 'Modern Full-Stack Web Development: React, TypeScript & REST',
    subtitle: 'Architect scalable web applications with responsive design, state managers, and secure API integrations.',
    description: 'Learn modern web standards from UI component architecture to production builds, RESTful API design, and client state orchestration.',
    category: 'Web Development',
    level: 'Intermediate',
    durationHours: 36,
    teacherId: 'user-teacher-2',
    teacherName: 'Marcus Sterling',
    teacherAvatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=200&q=80',
    teacherTitle: 'Principal Database Architect & Full Stack Lead',
    imageUrl: '/src/assets/images/course_web_dev_1794126943246.jpg',
    rating: 4.9,
    reviewCount: 1680,
    status: 'published',
    passingPercentage: 70,
    enrolledStudentsCount: 4210,
    requirements: [
      'Basic HTML and CSS knowledge.',
      'Understanding of modern JavaScript fundamentals.'
    ],
    whatYouWillLearn: [
      'Component-driven architecture and hooks with React 19',
      'TypeScript static typing, generics, and strict contract definitions',
      'REST API design principles, authentication tokens, and CORS',
      'Responsive design with Tailwind CSS and accessibility guidelines'
    ],
    modules: [
      {
        id: 'mod-web-1',
        courseId: 'course-webdev-301',
        title: 'Module 1: React & TypeScript Foundations',
        order: 1,
        lessons: [
          {
            id: 'les-web-1-1',
            moduleId: 'mod-web-1',
            title: 'Lesson 1: Modern React 19 Paradigms & Architecture',
            durationMinutes: 25,
            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
            description: 'JSX internals, component tree reconciliation, and declarative UI development.',
            codeSnippet: 'export function Header({ title }: { title: string }) {\n  return <h1 className="text-2xl font-bold">{title}</h1>;\n}',
            codeLanguage: 'typescript',
            order: 1
          }
        ]
      }
    ],
    materials: []
  },
  {
    id: 'course-ai-401',
    title: 'Artificial Intelligence & Algorithmic Foundations',
    subtitle: 'Explore search algorithms, neural network math, optimization heuristics, and prompt engineering.',
    description: 'A mathematical and programmatic exploration of machine learning algorithms, backpropagation, decision trees, and generative foundation models.',
    category: 'Artificial Intelligence',
    level: 'Advanced',
    durationHours: 40,
    teacherId: 'user-teacher-1',
    teacherName: 'Dr. Elena Vance',
    teacherAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80',
    teacherTitle: 'Professor of Computer Science & Author',
    imageUrl: '/src/assets/images/course_ai_algorithms_1794126944956.jpg',
    rating: 4.9,
    reviewCount: 820,
    status: 'published',
    passingPercentage: 70,
    enrolledStudentsCount: 1980,
    requirements: [
      'Proficiency in Python and basic linear algebra.'
    ],
    whatYouWillLearn: [
      'Gradient descent, backpropagation, and loss functions',
      'Supervised vs Unsupervised learning paradigms',
      'Decision Trees, Random Forests, and Ensemble methods',
      'Transformer attention mechanisms and modern LLM application patterns'
    ],
    modules: [],
    materials: []
  }
];

export const INITIAL_DOUBTS: Doubt[] = [
  {
    id: 'doubt-1',
    courseId: 'course-python-101',
    courseTitle: 'Python Programming Masterclass',
    lessonId: 'les-py-2-2',
    lessonTitle: 'Lesson 2: Primitive & Collection Data Types',
    studentId: 'user-student-1',
    studentName: 'Rohan Sharma',
    studentAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    title: 'Difference between shallow copy vs deep copy in nested lists?',
    description: 'In Lesson 2, when I use list.copy() on a list containing inner sublists, modifying an element in the inner list changes both the original and copied list. How does copy.deepcopy() prevent this memory reference aliasing?',
    screenshotUrl: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=600&q=80',
    status: 'resolved',
    createdAt: '2026-03-01 14:32',
    replies: [
      {
        id: 'reply-1',
        doubtId: 'doubt-1',
        authorId: 'user-teacher-1',
        authorName: 'Dr. Elena Vance',
        authorRole: 'teacher',
        authorAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80',
        content: 'Great question Rohan! A shallow copy (`list.copy()` or `[:]`) creates a new outer container, but keeps the exact same memory references (pointers) to nested mutable objects. `copy.deepcopy()` recursively traverses the compound object and duplicates every single child structure into fresh memory addresses. I will also demonstrate this visually in our upcoming Thursday doubt session!',
        createdAt: '2026-03-01 16:15'
      }
    ]
  },
  {
    id: 'doubt-2',
    courseId: 'course-python-101',
    courseTitle: 'Python Programming Masterclass',
    lessonId: 'les-py-3-2',
    lessonTitle: 'Lesson 2: Loops (For, While, Range & Iterators)',
    studentId: 'user-student-1',
    studentName: 'Rohan Sharma',
    studentAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80',
    title: 'Does Python `else` clause in a for-loop execute if `break` is triggered?',
    description: 'I noticed that python loops can have an optional `else:` block. Under what exact conditions will the else block run or be skipped?',
    status: 'pending',
    createdAt: '2026-03-03 10:15',
    replies: []
  }
];

export const INITIAL_DOUBT_SESSIONS: DoubtSession[] = [
  {
    id: 'session-101',
    courseId: 'course-python-101',
    courseTitle: 'Python Programming Masterclass',
    teacherId: 'user-teacher-1',
    teacherName: 'Dr. Elena Vance',
    teacherAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80',
    topic: 'Live Doubt Clearing: Control Flow, Nested Iteration & Memory References',
    description: 'Interactive session clarifying student doubts from Modules 1 through 3. Dr. Vance will review submitted student doubts live, demonstrate memory layout on the shared whiteboard, and answer open Q&A.',
    sessionDate: '2026-03-12',
    startTime: '18:00',
    endTime: '19:30',
    meetingLink: 'https://meet.google.com/ert-bnmo-qwe',
    registeredStudentIds: ['user-student-1'],
    status: 'upcoming'
  },
  {
    id: 'session-102',
    courseId: 'course-mysql-201',
    courseTitle: 'Relational Database Design & MySQL Mastery',
    teacherId: 'user-teacher-2',
    teacherName: 'Marcus Sterling',
    teacherAvatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=200&q=80',
    topic: 'Live Doubt Clearing: Normalization Edge Cases & Index Selection',
    description: 'Scheduled office hour for database students needing clarity on 3NF vs BCNF and composite index ordering.',
    sessionDate: '2026-03-15',
    startTime: '17:00',
    endTime: '18:15',
    meetingLink: 'https://meet.google.com/dfg-hjkl-zxc',
    registeredStudentIds: [],
    status: 'upcoming'
  },
  {
    id: 'session-100',
    courseId: 'course-python-101',
    courseTitle: 'Python Programming Masterclass',
    teacherId: 'user-teacher-1',
    teacherName: 'Dr. Elena Vance',
    teacherAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80',
    topic: 'Module 1 Clarification: Virtual Environments & Path Configuration',
    description: 'Completed doubt-clearing session covering Windows PATH issues, VS Code interpreter selection, and pip package management.',
    sessionDate: '2026-02-24',
    startTime: '18:00',
    endTime: '19:00',
    meetingLink: 'https://meet.google.com/past-py-session',
    registeredStudentIds: ['user-student-1'],
    recordingUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
    status: 'completed'
  }
];

export const INITIAL_ASSIGNMENTS: Assignment[] = [
  {
    id: 'assign-py-1',
    courseId: 'course-python-101',
    title: 'Assignment 1: Student Grade Calculation & Automated Report Generator',
    instructions: 'Create a Python program that accepts a dictionary of student marks across 5 subjects, calculates GPA, determines letter grade, and outputs a formatted report text file adhering to PEP 8 standards.',
    deadline: '2026-03-20',
    totalMarks: 50,
    starterCode: '# Assignment 1 Starter Code\ndef generate_report(student_name: str, grades: dict[str, float]) -> str:\n    # TODO: Implement GPA calculation and formatted summary\n    pass'
  }
];

export const INITIAL_SUBMISSIONS: AssignmentSubmission[] = [
  {
    id: 'sub-1',
    assignmentId: 'assign-py-1',
    courseId: 'course-python-101',
    studentId: 'user-student-1',
    studentName: 'Rohan Sharma',
    submissionText: 'Implemented complete grading script with validation for negative scores and automated text output formatting using f-strings.',
    attachmentName: 'rohan_grading_system.py',
    submittedAt: '2026-03-02 11:20',
    marksAwarded: 48,
    teacherFeedback: 'Outstanding work! Clean type hints and defensive error handling for division by zero. Keep up the high standard.',
    gradedAt: '2026-03-03 09:30',
    status: 'graded'
  }
];

export const PYTHON_EXAM_QUESTIONS: ExamQuestion[] = [
  {
    id: 'q1',
    question: 'Which of the following is an immutable data type in Python?',
    options: ['List', 'Dictionary', 'Tuple', 'Set'],
    correctAnswerIndex: 2,
    explanation: 'Tuples and strings in Python are immutable; their elements cannot be modified once created.'
  },
  {
    id: 'q2',
    question: 'What is the output of `print(type(5 / 2))` in Python 3?',
    options: ["<class 'int'>", "<class 'float'>", "<class 'double'>", "<class 'number'>"],
    correctAnswerIndex: 1,
    explanation: 'In Python 3, single slash `/` always produces floating point division, returning `float` (2.5).'
  },
  {
    id: 'q3',
    question: 'How do you insert an element at a specific index in a Python list `lst`?',
    options: ['lst.add(index, elem)', 'lst.insert(index, elem)', 'lst.append(elem, index)', 'lst.push(index, elem)'],
    correctAnswerIndex: 1,
    explanation: 'The `insert(index, element)` method places the new element at the specified position.'
  },
  {
    id: 'q4',
    question: 'What does the `pass` statement do in Python?',
    options: [
      'Terminates the program execution immediately',
      'Acts as a null placeholder where syntax requires a statement',
      'Skips to the next iteration of the loop',
      'Passes an argument to a function'
    ],
    correctAnswerIndex: 1,
    explanation: '`pass` is a null statement used when a statement is required syntactically but no code needs to execute.'
  },
  {
    id: 'q5',
    question: 'Which built-in function returns both the index and value when iterating over a sequence?',
    options: ['zip()', 'range()', 'enumerate()', 'map()'],
    correctAnswerIndex: 2,
    explanation: '`enumerate(iterable)` yields pairs containing count (index) and the value.'
  },
  {
    id: 'q6',
    question: 'What is the correct way to handle an exception in Python?',
    options: [
      'try ... catch ... finally',
      'try ... except ... finally',
      'do ... catch ... end',
      'attempt ... error ... close'
    ],
    correctAnswerIndex: 1,
    explanation: 'Python uses `try:` followed by `except:` blocks, with optional `else:` and `finally:`.'
  },
  {
    id: 'q7',
    question: 'What will `bool([])` evaluate to in Python?',
    options: ['True', 'False', 'None', 'ValueError'],
    correctAnswerIndex: 1,
    explanation: 'Empty containers (lists, tuples, dicts, sets) and empty strings evaluate to `False` in boolean context.'
  },
  {
    id: 'q8',
    question: 'What keyword is used to create an anonymous inline function in Python?',
    options: ['def', 'func', 'lambda', 'inline'],
    correctAnswerIndex: 2,
    explanation: '`lambda arguments: expression` defines small anonymous single-expression functions.'
  },
  {
    id: 'q9',
    question: 'What is the result of `2 ** 3 ** 2` according to Python operator precedence?',
    options: ['64', '512', '18', '256'],
    correctAnswerIndex: 1,
    explanation: 'The exponentiation operator `**` has right-to-left associativity: 3 ** 2 = 9, then 2 ** 9 = 512.'
  },
  {
    id: 'q10',
    question: 'Which method removes and returns the last item from a list (or from a given index)?',
    options: ['remove()', 'pop()', 'delete()', 'discard()'],
    correctAnswerIndex: 1,
    explanation: '`pop([i])` removes and returns the item at index `i` (defaulting to the last item).'
  },
  {
    id: 'q11',
    question: 'What does `__init__` signify in a Python class?',
    options: [
      'A method to initialize static memory',
      'The constructor/initializer called when a new instance is instantiated',
      'A private module import trigger',
      'The destructor method executed during garbage collection'
    ],
    correctAnswerIndex: 1,
    explanation: '`__init__` is the instance initializer called automatically when an object of the class is constructed.'
  },
  {
    id: 'q12',
    question: 'How do you access the value associated with key "role" safely from dictionary `d` with a fallback default?',
    options: ['d["role"]', 'd.find("role", "guest")', 'd.get("role", "guest")', 'd.fetch("role")'],
    correctAnswerIndex: 2,
    explanation: '`d.get(key, default)` returns the value if the key exists, or the default value without raising a `KeyError`.'
  },
  {
    id: 'q13',
    question: 'What is the output of `"hello".split("l")`?',
    options: ["['he', 'o']", "['he', '', 'o']", "['he', 'l', 'l', 'o']", "['h', 'e', 'o']"],
    correctAnswerIndex: 1,
    explanation: 'Splitting on `"l"` yields `["he", "", "o"]` because there is an empty string between consecutive delimiter characters.'
  },
  {
    id: 'q14',
    question: 'Which module in the Python standard library provides random number generation functions?',
    options: ['math', 'sys', 'random', 'crypto'],
    correctAnswerIndex: 2,
    explanation: 'The `random` module implements pseudo-random number generators for various distributions.'
  },
  {
    id: 'q15',
    question: 'What is a list comprehension syntax for numbers squared from 0 to 4?',
    options: [
      '[x ^ 2 for x in 5]',
      '[x**2 for x in range(5)]',
      '{x**2 in range(5)}',
      'map(lambda x: x**2, 5)'
    ],
    correctAnswerIndex: 1,
    explanation: '`[x**2 for x in range(5)]` generates `[0, 1, 4, 9, 16]`.'
  },
  {
    id: 'q16',
    question: 'What does the `is` operator compare in Python?',
    options: [
      'Value equality (equivalent to ==)',
      'Memory identity (whether both operands refer to the same object in memory)',
      'Data type matching',
      'String alphabetical order'
    ],
    correctAnswerIndex: 1,
    explanation: '`is` checks for object identity (memory address `id(a) == id(b)`), whereas `==` checks value equality.'
  },
  {
    id: 'q17',
    question: 'How do you open a file for writing in UTF-8 text mode safely using context management?',
    options: [
      'open("file.txt", "w")',
      'with open("file.txt", "w", encoding="utf-8") as f:',
      'using file("file.txt", mode="write")',
      'try file.open("file.txt")'
    ],
    correctAnswerIndex: 1,
    explanation: 'The `with open(...) as f:` construct automatically handles closing the file handle even if exceptions occur.'
  },
  {
    id: 'q18',
    question: 'What will `sorted([4, 1, 3, 2], reverse=True)` return?',
    options: ['[1, 2, 3, 4]', '[4, 3, 2, 1]', '[2, 3, 1, 4]', 'None'],
    correctAnswerIndex: 1,
    explanation: '`sorted()` with `reverse=True` sorts elements in descending order.'
  },
  {
    id: 'q19',
    question: 'What does the `*args` parameter in a function definition allow?',
    options: [
      'Passing any number of positional arguments as a tuple',
      'Passing keyword arguments as a dictionary',
      'Pointer dereferencing similar to C/C++',
      'Restricting arguments to integers only'
    ],
    correctAnswerIndex: 0,
    explanation: '`*args` collects arbitrary positional arguments into a tuple inside the function.'
  },
  {
    id: 'q20',
    question: 'What is the passing percentage required on CertiLearn for final certification?',
    options: ['50%', '60%', '70%', '80%'],
    correctAnswerIndex: 2,
    explanation: 'As per platform requirements, students must achieve 70% or higher (14 out of 20 questions) to pass and earn an official certificate.'
  }
];

export const INITIAL_CERTIFICATES: Certificate[] = [
  {
    id: 'CERT-2026-PY-9842',
    courseId: 'course-python-101',
    courseTitle: 'Python Programming Masterclass: From Fundamentals to Production',
    studentId: 'user-student-1',
    studentName: 'Rohan Sharma',
    issueDate: '2026-03-03',
    teacherName: 'Dr. Elena Vance',
    scorePercentage: 90,
    verificationCode: 'CL-VERIFY-9842-PY-2026'
  }
];
