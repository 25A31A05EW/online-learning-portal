import React, { useRef, useEffect } from 'react';
import { Certificate } from '../types';
import { X, Download, Printer, ShieldCheck, CheckCircle2, Award } from 'lucide-react';

interface CertificateModalProps {
  certificate: Certificate;
  onClose: () => void;
}

export const CertificateModal: React.FC<CertificateModalProps> = ({ certificate, onClose }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Draw high-resolution certificate on canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // High-resolution canvas size (1200 x 850)
    canvas.width = 1200;
    canvas.height = 850;

    // Background
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, 1200, 850);

    // Outer subtle border
    ctx.strokeStyle = '#1E3A8A';
    ctx.lineWidth = 14;
    ctx.strokeRect(20, 20, 1160, 810);

    // Inner gold hairline border
    ctx.strokeStyle = '#D97706';
    ctx.lineWidth = 3;
    ctx.strokeRect(36, 36, 1128, 778);

    // Corner flourishes
    const drawFlourish = (x: number, y: number, angle: number) => {
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(angle);
      ctx.strokeStyle = '#D97706';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(30, 0);
      ctx.moveTo(0, 0);
      ctx.lineTo(0, 30);
      ctx.stroke();
      ctx.restore();
    };
    drawFlourish(46, 46, 0);
    drawFlourish(1154, 46, Math.PI / 2);
    drawFlourish(1154, 804, Math.PI);
    drawFlourish(46, 804, -Math.PI / 2);

    // Header Logo & Platform Name
    ctx.fillStyle = '#1E3A8A';
    ctx.font = 'bold 36px "Plus Jakarta Sans", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('CERTILEARN ACADEMIC COUNCIL', 600, 110);

    ctx.fillStyle = '#64748B';
    ctx.font = '14px "Plus Jakarta Sans", sans-serif';
    ctx.fillText('OFFICIAL CERTIFICATE OF COURSE COMPLETION & MASTERY', 600, 140);

    // Divider line
    ctx.strokeStyle = '#E2E8F0';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(350, 160);
    ctx.lineTo(850, 160);
    ctx.stroke();

    // Body: "This is to certify that"
    ctx.fillStyle = '#475569';
    ctx.font = 'italic 18px Georgia, serif';
    ctx.fillText('This document is proudly presented to verify that', 600, 210);

    // Student Name
    ctx.fillStyle = '#0F172A';
    ctx.font = 'bold 44px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(certificate.studentName, 600, 275);

    // Underline beneath student name
    ctx.strokeStyle = '#2563EB';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(250, 295);
    ctx.lineTo(950, 295);
    ctx.stroke();

    // Fulfilled Requirements Text
    ctx.fillStyle = '#334155';
    ctx.font = '18px "Plus Jakarta Sans", sans-serif';
    ctx.fillText('has satisfactorily fulfilled all academic requirements, attended recorded video coursework,', 600, 350);
    ctx.fillText('and successfully cleared the final comprehensive examination for the course:', 600, 380);

    // Course Title
    ctx.fillStyle = '#1D4ED8';
    ctx.font = 'bold 28px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(certificate.courseTitle, 600, 435);

    // Passing grade & Date
    ctx.fillStyle = '#64748B';
    ctx.font = '15px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(`Examination Score: ${certificate.scorePercentage}% · Issued On: ${certificate.issueDate}`, 600, 480);

    // Gold Seal Medal in Center-Bottom
    const sealX = 600;
    const sealY = 580;
    ctx.save();
    ctx.beginPath();
    ctx.arc(sealX, sealY, 46, 0, Math.PI * 2);
    ctx.fillStyle = '#FEF3C7';
    ctx.fill();
    ctx.strokeStyle = '#D97706';
    ctx.lineWidth = 4;
    ctx.stroke();

    ctx.fillStyle = '#92400E';
    ctx.font = 'bold 12px "Plus Jakarta Sans", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('VERIFIED', sealX, sealY - 8);
    ctx.fillText('EXCELLENCE', sealX, sealY + 8);
    ctx.fillText('2026', sealX, sealY + 22);
    ctx.restore();

    // Left Signature: Instructor
    ctx.textAlign = 'center';
    ctx.fillStyle = '#1E293B';
    ctx.font = 'italic bold 22px Georgia, serif';
    ctx.fillText(certificate.teacherName, 260, 680);

    ctx.strokeStyle = '#94A3B8';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(140, 695);
    ctx.lineTo(380, 695);
    ctx.stroke();

    ctx.fillStyle = '#64748B';
    ctx.font = '13px "Plus Jakarta Sans", sans-serif';
    ctx.fillText('Lead Academic Instructor', 260, 715);

    // Right Signature: Director
    ctx.textAlign = 'center';
    ctx.fillStyle = '#1E293B';
    ctx.font = 'italic bold 22px Georgia, serif';
    ctx.fillText('Chief Academic Director', 940, 680);

    ctx.strokeStyle = '#94A3B8';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(820, 695);
    ctx.lineTo(1060, 695);
    ctx.stroke();

    ctx.fillStyle = '#64748B';
    ctx.font = '13px "Plus Jakarta Sans", sans-serif';
    ctx.fillText('CertiLearn Accreditation Board', 940, 715);

    // Bottom Verification Strip
    ctx.textAlign = 'center';
    ctx.fillStyle = '#475569';
    ctx.font = '12px "JetBrains Mono", monospace';
    ctx.fillText(`Certificate ID: ${certificate.id}  ·  Verification Code: ${certificate.verificationCode}`, 600, 770);
    ctx.fillText('Verify public status anytime at certilearn.edu/verify', 600, 790);

  }, [certificate]);

  // Download high-resolution PNG
  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const url = canvas.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = url;
    a.download = `${certificate.id}_${certificate.studentName.replace(/\s+/g, '_')}.png`;
    a.click();
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-4xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[95vh]">
        
        {/* Top Control Bar */}
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-600" />
            <div>
              <h3 className="text-sm font-bold text-slate-900">
                Official Verifiable Certificate
              </h3>
              <div className="text-[11px] text-slate-500 font-mono">
                ID: {certificate.id}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg shadow-2xs flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / PDF</span>
            </button>
            <button
              onClick={handleDownload}
              className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download High-Res</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/60 ml-2"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Certificate Display Area */}
        <div className="p-6 overflow-y-auto bg-slate-100/70 flex flex-col items-center justify-center">
          <div
            id="printable-certificate"
            className="w-full max-w-3xl bg-white shadow-xl rounded-lg overflow-hidden border border-slate-300"
          >
            <canvas ref={canvasRef} className="w-full h-auto block" />
          </div>

          <div className="mt-4 text-xs text-slate-500 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>
              This credential is permanently registered with unique ID <strong>{certificate.id}</strong>.
            </span>
          </div>
        </div>

      </div>
    </div>
  );
};
