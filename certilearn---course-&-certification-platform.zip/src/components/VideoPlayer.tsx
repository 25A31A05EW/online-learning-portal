import React, { useRef, useState, useEffect } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  RotateCw,
  Volume2,
  VolumeX,
  Maximize,
  Minimize,
  CheckCircle2,
  BookmarkCheck,
  ChevronLeft,
  ChevronRight,
  Settings
} from 'lucide-react';
import { useCourse } from '../context/CourseContext';

interface VideoPlayerProps {
  courseId: string;
  lessonId: string;
  videoUrl: string;
  title: string;
  onPrevLesson?: () => void;
  onNextLesson?: () => void;
  hasPrev?: boolean;
  hasNext?: boolean;
}

export const VideoPlayer: React.FC<VideoPlayerProps> = ({
  courseId,
  lessonId,
  videoUrl,
  title,
  onPrevLesson,
  onNextLesson,
  hasPrev = false,
  hasNext = false
}) => {
  const { saveVideoProgress, getLessonProgress } = useCourse();
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const [resumePrompt, setResumePrompt] = useState<number | null>(null);
  const [controlsVisible, setControlsVisible] = useState(true);
  const controlsTimeoutRef = useRef<number | null>(null);

  const progress = getLessonProgress(courseId, lessonId);
  const isCompleted = progress?.completed || false;

  // Format time (mm:ss)
  const formatTime = (secs: number) => {
    if (isNaN(secs)) return '00:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // Check saved progress on load
  useEffect(() => {
    const saved = getLessonProgress(courseId, lessonId);
    if (saved && saved.watchedSeconds > 10 && !saved.completed) {
      setResumePrompt(saved.watchedSeconds);
    } else {
      setResumePrompt(null);
    }
    // Reset video state
    if (videoRef.current) {
      videoRef.current.currentTime = 0;
      setCurrentTime(0);
      setIsPlaying(false);
    }
  }, [courseId, lessonId]);

  // Handle resume action
  const handleResume = (seconds: number) => {
    if (videoRef.current) {
      videoRef.current.currentTime = seconds;
      setCurrentTime(seconds);
      videoRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
    }
    setResumePrompt(null);
  };

  const handleRestart = () => {
    if (videoRef.current) {
      videoRef.current.currentTime = 0;
      setCurrentTime(0);
      videoRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
    }
    setResumePrompt(null);
  };

  // Play / Pause toggle
  const togglePlay = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
      saveVideoProgress(courseId, lessonId, currentTime, duration || 1200);
    } else {
      videoRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
    }
  };

  // Skip +/- 10s
  const skip = (delta: number) => {
    if (!videoRef.current) return;
    const next = Math.max(0, Math.min(duration, videoRef.current.currentTime + delta));
    videoRef.current.currentTime = next;
    setCurrentTime(next);
  };

  // Seek
  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    if (videoRef.current) {
      videoRef.current.currentTime = val;
      setCurrentTime(val);
    }
  };

  // Volume
  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    setIsMuted(val === 0);
    if (videoRef.current) {
      videoRef.current.volume = val;
      videoRef.current.muted = val === 0;
    }
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    if (isMuted) {
      videoRef.current.muted = false;
      videoRef.current.volume = volume || 0.7;
      setIsMuted(false);
    } else {
      videoRef.current.muted = true;
      setIsMuted(true);
    }
  };

  // Speed
  const handleSpeedChange = (speed: number) => {
    setPlaybackSpeed(speed);
    if (videoRef.current) {
      videoRef.current.playbackRate = speed;
    }
    setShowSpeedMenu(false);
  };

  // Fullscreen
  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  // Handle Mark Completed manually
  const handleMarkCompleted = () => {
    saveVideoProgress(courseId, lessonId, duration || 1200, duration || 1200, true);
  };

  // Auto-hide controls
  const handleMouseMove = () => {
    setControlsVisible(true);
    if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
    controlsTimeoutRef.current = window.setTimeout(() => {
      if (isPlaying) setControlsVisible(false);
    }, 3000);
  };

  // Time update listener
  const handleTimeUpdate = () => {
    if (!videoRef.current) return;
    const cur = videoRef.current.currentTime;
    setCurrentTime(cur);

    // Save every 4 seconds
    if (Math.floor(cur) % 4 === 0) {
      saveVideoProgress(courseId, lessonId, cur, duration);
    }

    // Auto complete at 90%
    if (duration > 0 && cur >= duration * 0.9 && !isCompleted) {
      saveVideoProgress(courseId, lessonId, cur, duration, true);
    }
  };

  return (
    <div
      ref={containerRef}
      onMouseMove={handleMouseMove}
      className="relative aspect-video w-full bg-slate-950 rounded-xl overflow-hidden shadow-lg select-none group flex flex-col justify-between"
    >
      {/* Video Element */}
      <video
        ref={videoRef}
        src={videoUrl}
        className="w-full h-full object-contain cursor-pointer"
        onClick={togglePlay}
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={() => {
          if (videoRef.current) {
            setDuration(videoRef.current.duration || 1200);
          }
        }}
        onEnded={() => {
          setIsPlaying(false);
          saveVideoProgress(courseId, lessonId, duration, duration, true);
        }}
      />

      {/* Resume from last position prompt */}
      {resumePrompt !== null && (
        <div className="absolute top-4 left-4 right-4 z-30 bg-slate-900/90 backdrop-blur-md border border-slate-700/80 rounded-xl p-3 flex items-center justify-between shadow-2xl text-white text-xs">
          <div className="flex items-center gap-2.5">
            <BookmarkCheck className="w-4 h-4 text-blue-400" />
            <span>
              Resume recorded lecture at <strong>{formatTime(resumePrompt)}</strong>?
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => handleResume(resumePrompt)}
              className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-md transition-colors"
            >
              Resume
            </button>
            <button
              onClick={handleRestart}
              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-md transition-colors"
            >
              Start Over
            </button>
          </div>
        </div>
      )}

      {/* Top Bar Overlay */}
      <div
        className={`absolute top-0 inset-x-0 p-4 bg-gradient-to-b from-black/80 via-black/40 to-transparent transition-opacity duration-300 z-20 flex items-center justify-between text-white ${
          controlsVisible ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
      >
        <div className="flex items-center gap-2 truncate max-w-[70%]">
          <span className="text-xs text-blue-400 font-semibold tracking-wide uppercase">
            Recorded Class:
          </span>
          <span className="text-sm font-semibold truncate">{title}</span>
        </div>

        <div className="flex items-center gap-2">
          {isCompleted ? (
            <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-400 bg-emerald-950/80 border border-emerald-800/80 px-2.5 py-1 rounded-md">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Completed</span>
            </span>
          ) : (
            <button
              onClick={handleMarkCompleted}
              className="px-2.5 py-1 text-[11px] font-medium text-slate-200 bg-slate-800/80 hover:bg-slate-700 rounded-md border border-slate-700 transition-colors"
            >
              Mark as Completed
            </button>
          )}
        </div>
      </div>

      {/* Bottom Controls Overlay */}
      <div
        className={`absolute bottom-0 inset-x-0 p-4 bg-gradient-to-t from-black/90 via-black/60 to-transparent transition-opacity duration-300 z-20 space-y-2.5 ${
          controlsVisible ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
      >
        {/* Progress Timeline Slider */}
        <div className="flex items-center gap-3">
          <input
            type="range"
            min={0}
            max={duration || 100}
            value={currentTime}
            onChange={handleSeek}
            className="w-full h-1.5 bg-slate-700 accent-blue-500 rounded-lg cursor-pointer transition-all"
          />
        </div>

        <div className="flex items-center justify-between text-white text-xs">
          
          {/* Left Controls */}
          <div className="flex items-center gap-3">
            <button
              onClick={togglePlay}
              className="p-1.5 hover:text-blue-400 transition-colors focus:outline-none"
              title={isPlaying ? 'Pause' : 'Play'}
            >
              {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
            </button>

            <button
              onClick={() => skip(-10)}
              className="p-1.5 hover:text-blue-400 transition-colors focus:outline-none text-slate-300"
              title="Rewind 10 seconds"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <button
              onClick={() => skip(10)}
              className="p-1.5 hover:text-blue-400 transition-colors focus:outline-none text-slate-300"
              title="Skip 10 seconds"
            >
              <RotateCw className="w-4 h-4" />
            </button>

            {/* Prev / Next buttons */}
            <div className="h-4 w-px bg-slate-700 mx-1" />

            <button
              onClick={onPrevLesson}
              disabled={!hasPrev}
              className={`p-1.5 transition-colors ${
                hasPrev ? 'hover:text-blue-400 text-slate-300' : 'text-slate-600 cursor-not-allowed'
              }`}
              title="Previous Lesson"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <button
              onClick={onNextLesson}
              disabled={!hasNext}
              className={`p-1.5 transition-colors ${
                hasNext ? 'hover:text-blue-400 text-slate-300' : 'text-slate-600 cursor-not-allowed'
              }`}
              title="Next Lesson"
            >
              <ChevronRight className="w-4 h-4" />
            </button>

            {/* Volume */}
            <div className="flex items-center gap-1.5 ml-1">
              <button onClick={toggleMute} className="hover:text-blue-400 text-slate-300">
                {isMuted || volume === 0 ? (
                  <VolumeX className="w-4 h-4" />
                ) : (
                  <Volume2 className="w-4 h-4" />
                )}
              </button>
              <input
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={isMuted ? 0 : volume}
                onChange={handleVolumeChange}
                className="w-16 h-1 bg-slate-700 accent-blue-500 rounded-lg cursor-pointer"
              />
            </div>

            {/* Timestamp */}
            <div className="text-[11px] text-slate-300 tabular-nums ml-2">
              <span>{formatTime(currentTime)}</span>
              <span className="text-slate-500 mx-1">/</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>

          {/* Right Controls */}
          <div className="flex items-center gap-3">
            
            {/* Speed Selector */}
            <div className="relative">
              <button
                onClick={() => setShowSpeedMenu(!showSpeedMenu)}
                className="px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-800/80 hover:bg-slate-700 text-slate-200 transition-colors"
                title="Playback Speed"
              >
                {playbackSpeed}x
              </button>

              {showSpeedMenu && (
                <div className="absolute right-0 bottom-full mb-2 bg-slate-900 border border-slate-700 rounded-lg py-1 shadow-xl z-50 text-xs">
                  {[0.75, 1, 1.25, 1.5, 2].map(speed => (
                    <button
                      key={speed}
                      onClick={() => handleSpeedChange(speed)}
                      className={`block w-full text-left px-3 py-1 hover:bg-slate-800 ${
                        playbackSpeed === speed ? 'text-blue-400 font-bold' : 'text-slate-300'
                      }`}
                    >
                      {speed}x
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Fullscreen */}
            <button
              onClick={toggleFullscreen}
              className="p-1.5 hover:text-blue-400 transition-colors text-slate-300"
              title="Fullscreen"
            >
              {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
            </button>

          </div>

        </div>
      </div>
    </div>
  );
};
