import React, { useState } from 'react';
import { useCourse } from '../context/CourseContext';
import { useAuth } from '../context/AuthContext';
import { INITIAL_USERS } from '../data/initialData';
import { User, Certificate } from '../types';
import {
  ShieldAlert,
  Users,
  BookOpen,
  Award,
  Terminal,
  CheckCircle2,
  XCircle,
  Database,
  Calendar,
  Layers,
  Lock,
  Search
} from 'lucide-react';

interface AdminDashboardProps {
  onOpenCppDocs: () => void;
  onOpenCertificateModal: (cert: Certificate) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  onOpenCppDocs,
  onOpenCertificateModal
}) => {
  const { courses, certificates, doubtSessions, doubts } = useCourse();
  const [usersList, setUsersList] = useState<User[]>(INITIAL_USERS);
  const [selectedTab, setSelectedTab] = useState<'metrics' | 'users' | 'courses' | 'certificates'>('metrics');
  const [userSearch, setUserSearch] = useState('');

  const totalStudents = usersList.filter(u => u.role === 'student').length + 3840; // Simulated full cohort
  const totalTeachers = usersList.filter(u => u.role === 'teacher').length;
  const totalCourses = courses.length;
  const totalCertificates = certificates.length;

  const toggleUserStatus = (userId: string) => {
    // Toggle active state demonstration
    alert(`Account permissions updated for User ID: ${userId}`);
  };

  const filteredUsers = usersList.filter(
    u => u.name.toLowerCase().includes(userSearch.toLowerCase()) || u.email.toLowerCase().includes(userSearch.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Header */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-6 border border-slate-800">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-purple-300 bg-purple-950/80 border border-purple-800 px-3 py-1 rounded-md">
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>Administrator Control Console</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight mt-2">
            Platform Operations & Accreditation Command
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-xl leading-relaxed">
            Monitor institutional metrics, supervise student and teacher accounts, audit issued tamper-proof certificates, and review MySQL relational database state.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={onOpenCppDocs}
            className="px-4 py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm flex items-center gap-2 whitespace-nowrap"
          >
            <Terminal className="w-4 h-4" />
            <span>C++ Engine & MySQL DDL</span>
          </button>
        </div>
      </div>

      {/* 4 Core Platform Metrics Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="text-xs text-slate-500 flex items-center justify-between">
            <span>Total Enrolled Students</span>
            <Users className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-2 font-mono tabular-nums">
            {totalStudents.toLocaleString()}
          </div>
          <div className="text-[11px] text-emerald-600 mt-1">Active verified learners</div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="text-xs text-slate-500 flex items-center justify-between">
            <span>Certified Faculty Instructors</span>
            <ShieldAlert className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-2 font-mono tabular-nums">
            {totalTeachers}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Course authors & doubt hosts</div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="text-xs text-slate-500 flex items-center justify-between">
            <span>Published Curricula</span>
            <BookOpen className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-2 font-mono tabular-nums">
            {totalCourses}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Recorded video tracks</div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="text-xs text-slate-500 flex items-center justify-between">
            <span>Verifiable Certificates Issued</span>
            <Award className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-2 font-mono tabular-nums">
            {totalCertificates}
          </div>
          <div className="text-[11px] text-amber-600 mt-1">70%+ Exam score verified</div>
        </div>

      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 text-xs font-semibold">
        <button
          onClick={() => setSelectedTab('metrics')}
          className={`px-4 py-2 rounded-lg transition-colors ${
            selectedTab === 'metrics' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Operational Overview
        </button>
        <button
          onClick={() => setSelectedTab('users')}
          className={`px-4 py-2 rounded-lg transition-colors ${
            selectedTab === 'users' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Manage Accounts (Students & Teachers)
        </button>
        <button
          onClick={() => setSelectedTab('courses')}
          className={`px-4 py-2 rounded-lg transition-colors ${
            selectedTab === 'courses' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Course Management & Approvals
        </button>
        <button
          onClick={() => setSelectedTab('certificates')}
          className={`px-4 py-2 rounded-lg transition-colors ${
            selectedTab === 'certificates' ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Certificates Ledger ({certificates.length})
        </button>
      </div>

      {/* Tab: Operational Overview */}
      {selectedTab === 'metrics' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
            <h3 className="text-sm font-bold text-slate-900">Teaching Model Enforcement</h3>
            <div className="p-4 bg-blue-50/70 border border-blue-200/60 rounded-xl space-y-2 text-xs text-blue-900 leading-relaxed">
              <strong>Primary Vehicle: Recorded Video Classes</strong>
              <p>
                Platform policy strictly designates recorded video lectures as the primary mode of instruction. Students progress through lessons at their own schedule without daily live attendance pressure.
              </p>
              <div className="pt-2 text-slate-700">
                <strong>Scheduled Live Doubt Clearing:</strong> Teachers conduct Google Meet / Zoom sessions exclusively during published scheduled slots to address complex questions.
              </div>
            </div>

            <div className="space-y-2 text-xs text-slate-600">
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span>Total Recorded Lessons in Library</span>
                <span className="font-bold text-slate-900">
                  {courses.reduce((sum, c) => sum + c.modules.reduce((msum, m) => msum + m.lessons.length, 0), 0)} lectures
                </span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span>Completed Doubt Sessions</span>
                <span className="font-bold text-slate-900">
                  {doubtSessions.filter(s => s.status === 'completed').length} sessions
                </span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-slate-100">
                <span>Active Student Doubts</span>
                <span className="font-bold text-slate-900">{doubts.length} questions</span>
              </div>
              <div className="flex justify-between py-1.5">
                <span>Exam Passing Threshold</span>
                <span className="font-bold text-emerald-600">70% Minimum</span>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
            <h3 className="text-sm font-bold text-slate-900">C++ Backend & MySQL Storage Sync</h3>
            <p className="text-xs text-slate-500">
              CertiLearn backend is architected in C++ using Crow / Drogon REST microframework with an ACID-compliant MySQL 8.0 relational schema.
            </p>

            <div className="space-y-2 text-xs">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between">
                <div>
                  <div className="font-bold text-slate-800">MySQL Database Schema</div>
                  <div className="text-[11px] text-slate-400">17 Normalized Tables with Foreign Keys</div>
                </div>
                <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                  InnoDB Active
                </span>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between">
                <div>
                  <div className="font-bold text-slate-800">C++ REST Engine</div>
                  <div className="text-[11px] text-slate-400">Port 8080 · JWT Authentication · Multithreaded</div>
                </div>
                <span className="text-[11px] font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded">
                  Ready
                </span>
              </div>
            </div>

            <button
              onClick={onOpenCppDocs}
              className="w-full py-2.5 text-xs font-semibold text-blue-600 hover:text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors flex items-center justify-center gap-1.5"
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>Inspect C++ Code & MySQL Schema</span>
            </button>
          </div>
        </div>
      )}

      {/* Tab: Users Management */}
      {selectedTab === 'users' && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <h3 className="text-sm font-bold text-slate-900">Platform Accounts Directory</h3>
            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                placeholder="Search name or email..."
                value={userSearch}
                onChange={e => setUserSearch(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="px-4 py-3">User</th>
                  <th className="px-4 py-3">Role</th>
                  <th className="px-4 py-3">Phone</th>
                  <th className="px-4 py-3">Joined Date</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredUsers.map(u => (
                  <tr key={u.id} className="hover:bg-slate-50">
                    <td className="px-4 py-3">
                      <div className="font-bold text-slate-900">{u.name}</div>
                      <div className="text-[11px] text-slate-400">{u.email}</div>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-0.5 rounded capitalize font-semibold text-[11px] ${
                        u.role === 'admin'
                          ? 'bg-purple-100 text-purple-800'
                          : u.role === 'teacher'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-blue-100 text-blue-800'
                      }`}>
                        {u.role}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-slate-600 font-mono">{u.phone || 'N/A'}</td>
                    <td className="px-4 py-3 text-slate-600">{u.joinedDate}</td>
                    <td className="px-4 py-3 text-right">
                      <button
                        onClick={() => toggleUserStatus(u.id)}
                        className="text-blue-600 hover:text-blue-800 font-semibold"
                      >
                        Manage Permissions
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab: Courses Management */}
      {selectedTab === 'courses' && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
          <h3 className="text-sm font-bold text-slate-900">Course Curricula & Accreditation</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="px-4 py-3">Course Title</th>
                  <th className="px-4 py-3">Category</th>
                  <th className="px-4 py-3">Instructor</th>
                  <th className="px-4 py-3">Enrolled</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {courses.map(c => (
                  <tr key={c.id} className="hover:bg-slate-50">
                    <td className="px-4 py-3 font-bold text-slate-900">{c.title}</td>
                    <td className="px-4 py-3 text-slate-600">{c.category}</td>
                    <td className="px-4 py-3 text-slate-600">{c.teacherName}</td>
                    <td className="px-4 py-3 text-slate-600 tabular-nums font-mono">{c.enrolledStudentsCount.toLocaleString()}</td>
                    <td className="px-4 py-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-100 text-emerald-800 uppercase">
                        {c.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <button
                        onClick={() => alert(`Course audit logs for ${c.title} verified.`)}
                        className="text-blue-600 hover:text-blue-800 font-semibold"
                      >
                        Audit Syllabus
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab: Certificates Ledger */}
      {selectedTab === 'certificates' && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">Official Certificate Registry</h3>
            <span className="text-xs text-slate-500 font-mono">{certificates.length} Total Issued</span>
          </div>

          <div className="divide-y divide-slate-100">
            {certificates.map(cert => (
              <div key={cert.id} className="py-3 flex items-center justify-between gap-4">
                <div>
                  <div className="font-mono text-xs font-bold text-blue-600">{cert.id}</div>
                  <div className="text-xs font-semibold text-slate-900">{cert.studentName} — {cert.courseTitle}</div>
                  <div className="text-[11px] text-slate-400">
                    Score: {cert.scorePercentage}% · Issued: {cert.issueDate} · Instructor: {cert.teacherName}
                  </div>
                </div>

                <button
                  onClick={() => onOpenCertificateModal(cert)}
                  className="px-3 py-1.5 text-xs font-semibold text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-lg whitespace-nowrap"
                >
                  View Certificate
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
