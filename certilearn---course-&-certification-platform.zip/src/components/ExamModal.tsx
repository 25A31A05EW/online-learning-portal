import React, { useState, useEffect } from 'react';
import { Course, ExamAttempt } from '../types';
import { PYTHON_EXAM_QUESTIONS } from '../data/initialData';
import { useCourse } from '../context/CourseContext';
import {
  X,
  Clock,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  ArrowRight,
  ArrowLeft,
  Award,
  RotateCcw
} from 'lucide-react';

interface ExamModalProps {
  course: Course;
  onClose: () => void;
  onCertificateEarned: () => void;
}

export const ExamModal: React.FC<ExamModalProps> = ({
  course,
  onClose,
  onCertificateEarned
}) => {
  const { submitExam } = useCourse();
  const questions = PYTHON_EXAM_QUESTIONS; // 20 questions

  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<{ [qId: string]: number }>({});
  const [timeLeftSeconds, setTimeLeftSeconds] = useState(20 * 60); // 20 mins
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [resultAttempt, setResultAttempt] = useState<ExamAttempt | null>(null);

  // Timer countdown
  useEffect(() => {
    if (isSubmitted) return;
    const interval = setInterval(() => {
      setTimeLeftSeconds(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          handleSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isSubmitted, answers]);

  const formatTimer = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleSelectOption = (questionId: string, optIndex: number) => {
    if (isSubmitted) return;
    setAnswers(prev => ({ ...prev, [questionId]: optIndex }));
  };

  const handleSubmit = () => {
    const attempt = submitExam(course.id, answers);
    setResultAttempt(attempt);
    setIsSubmitted(true);
  };

  const currentQ = questions[currentIndex];
  const answeredCount = Object.keys(answers).length;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div>
            <div className="text-[11px] font-bold text-blue-600 uppercase tracking-wider">
              Certification Examination · 70% Pass Mark
            </div>
            <h2 className="text-base font-bold text-slate-900">{course.title}</h2>
          </div>

          <div className="flex items-center gap-4">
            {!isSubmitted && (
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white border border-slate-200 text-xs font-mono font-bold text-slate-800 shadow-2xs">
                <Clock className={`w-4 h-4 ${timeLeftSeconds < 300 ? 'text-red-500 animate-pulse' : 'text-blue-600'}`} />
                <span>{formatTimer(timeLeftSeconds)}</span>
              </div>
            )}
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/60"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          
          {/* Result Screen */}
          {isSubmitted && resultAttempt ? (
            <div className="space-y-6">
              
              <div className={`p-6 rounded-2xl text-center space-y-3 ${
                resultAttempt.passed
                  ? 'bg-emerald-50 border border-emerald-200 text-emerald-950'
                  : 'bg-red-50 border border-red-200 text-red-950'
              }`}>
                <div className="inline-flex p-3 rounded-full bg-white shadow-xs">
                  {resultAttempt.passed ? (
                    <Award className="w-10 h-10 text-emerald-600" />
                  ) : (
                    <AlertCircle className="w-10 h-10 text-red-600" />
                  )}
                </div>

                <h3 className="text-xl font-bold">
                  {resultAttempt.passed
                    ? 'Congratulations! You Passed the Examination!'
                    : 'Examination Attempt Not Cleared'}
                </h3>

                <p className="text-xs text-slate-600 max-w-md mx-auto">
                  {resultAttempt.passed
                    ? 'Your score meets the academic standard. Your verified certificate has been automatically issued and registered on the blockchain ledger.'
                    : `You scored ${resultAttempt.percentage}%. CertiLearn requires at least 70% to issue an authorized certificate. Review your answers below and retake when ready.`}
                </p>

                <div className="flex items-center justify-center gap-8 pt-3 text-xs">
                  <div>
                    <div className="text-slate-500">Correct Answers</div>
                    <div className="text-lg font-bold text-slate-900">
                      {resultAttempt.score} / {resultAttempt.totalQuestions}
                    </div>
                  </div>
                  <div>
                    <div className="text-slate-500">Calculated Score</div>
                    <div className={`text-lg font-bold ${resultAttempt.passed ? 'text-emerald-600' : 'text-red-600'}`}>
                      {resultAttempt.percentage}%
                    </div>
                  </div>
                  <div>
                    <div className="text-slate-500">Result Status</div>
                    <div className={`text-lg font-bold ${resultAttempt.passed ? 'text-emerald-600' : 'text-red-600'}`}>
                      {resultAttempt.passed ? 'PASSED' : 'FAILED'}
                    </div>
                  </div>
                </div>

                {resultAttempt.passed && (
                  <div className="pt-2">
                    <button
                      onClick={() => {
                        onClose();
                        onCertificateEarned();
                      }}
                      className="px-6 py-3 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm"
                    >
                      View & Download My Certificate
                    </button>
                  </div>
                )}
              </div>

              {/* Review Question List */}
              <div className="space-y-4">
                <h4 className="text-sm font-bold text-slate-900">Detailed Answer Review</h4>
                <div className="space-y-3">
                  {questions.map((q, idx) => {
                    const studentAns = resultAttempt.answers[q.id];
                    const isCorrect = studentAns === q.correctAnswerIndex;

                    return (
                      <div
                        key={q.id}
                        className={`p-4 rounded-xl border text-xs space-y-2 ${
                          isCorrect
                            ? 'border-emerald-200 bg-emerald-50/30'
                            : 'border-red-200 bg-red-50/30'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <span className="font-bold text-slate-900">
                            Q{idx + 1}. {q.question}
                          </span>
                          <span className={`px-2 py-0.5 rounded font-semibold text-[10px] ${
                            isCorrect ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                          }`}>
                            {isCorrect ? 'Correct (+5 pts)' : 'Incorrect (0 pts)'}
                          </span>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                          {q.options.map((opt, optIdx) => {
                            const isSelected = studentAns === optIdx;
                            const isRight = optIdx === q.correctAnswerIndex;

                            let optStyle = 'border-slate-200 bg-white text-slate-700';
                            if (isRight) optStyle = 'border-emerald-400 bg-emerald-100/60 font-semibold text-emerald-900';
                            else if (isSelected && !isRight) optStyle = 'border-red-400 bg-red-100/60 text-red-900';

                            return (
                              <div
                                key={optIdx}
                                className={`p-2 rounded-lg border text-[11px] ${optStyle}`}
                              >
                                {opt}
                              </div>
                            );
                          })}
                        </div>

                        <div className="text-[11px] text-slate-500 pt-1">
                          <strong>Explanation:</strong> {q.explanation}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

            </div>
          ) : (
            // Active Exam Taking Screen
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Question Stage (8 cols) */}
              <div className="lg:col-span-8 space-y-5">
                <div className="flex items-center justify-between text-xs text-slate-500">
                  <span>Question {currentIndex + 1} of {questions.length}</span>
                  <span>Weight: 5 marks</span>
                </div>

                <div className="p-5 bg-slate-50 rounded-xl border border-slate-200 text-sm font-semibold text-slate-900 leading-relaxed">
                  {currentQ.question}
                </div>

                <div className="space-y-2.5">
                  {currentQ.options.map((option, optIdx) => {
                    const isSelected = answers[currentQ.id] === optIdx;
                    return (
                      <button
                        key={optIdx}
                        onClick={() => handleSelectOption(currentQ.id, optIdx)}
                        className={`w-full text-left p-3.5 rounded-xl border transition-all text-xs flex items-center gap-3 ${
                          isSelected
                            ? 'border-blue-600 bg-blue-50/70 text-blue-900 font-medium shadow-2xs'
                            : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                        }`}
                      >
                        <div
                          className={`w-5 h-5 rounded-full border flex items-center justify-center text-[10px] shrink-0 ${
                            isSelected
                              ? 'border-blue-600 bg-blue-600 text-white font-bold'
                              : 'border-slate-300 text-slate-500'
                          }`}
                        >
                          {String.fromCharCode(65 + optIdx)}
                        </div>
                        <span className="flex-1">{option}</span>
                      </button>
                    );
                  })}
                </div>

                {/* Bottom Navigator */}
                <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                  <button
                    onClick={() => setCurrentIndex(prev => Math.max(0, prev - 1))}
                    disabled={currentIndex === 0}
                    className={`px-4 py-2 text-xs font-semibold rounded-lg flex items-center gap-1.5 ${
                      currentIndex === 0
                        ? 'text-slate-300 cursor-not-allowed'
                        : 'text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Previous</span>
                  </button>

                  {currentIndex < questions.length - 1 ? (
                    <button
                      onClick={() => setCurrentIndex(prev => Math.min(questions.length - 1, prev + 1))}
                      className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg flex items-center gap-1.5"
                    >
                      <span>Next</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  ) : (
                    <button
                      onClick={handleSubmit}
                      className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm"
                    >
                      Submit Exam ({answeredCount}/20)
                    </button>
                  )}
                </div>
              </div>

              {/* Question Navigation Palette (4 cols) */}
              <div className="lg:col-span-4 bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-4">
                <div className="text-xs font-bold text-slate-800">
                  Question Palette ({answeredCount}/{questions.length} Answered)
                </div>

                <div className="grid grid-cols-5 gap-2">
                  {questions.map((q, idx) => {
                    const isAnswered = answers[q.id] !== undefined;
                    const isCurrent = idx === currentIndex;

                    let btnClass = 'bg-white border-slate-200 text-slate-600 hover:border-slate-300';
                    if (isCurrent) btnClass = 'bg-blue-600 border-blue-600 text-white font-bold ring-2 ring-blue-300';
                    else if (isAnswered) btnClass = 'bg-emerald-500 border-emerald-500 text-white font-semibold';

                    return (
                      <button
                        key={q.id}
                        onClick={() => setCurrentIndex(idx)}
                        className={`h-9 rounded-lg border text-xs flex items-center justify-center transition-all ${btnClass}`}
                      >
                        {idx + 1}
                      </button>
                    );
                  })}
                </div>

                <div className="pt-2 border-t border-slate-200/80 text-[11px] text-slate-500 space-y-1">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded bg-emerald-500" />
                    <span>Answered ({answeredCount})</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded bg-white border border-slate-300" />
                    <span>Unanswered ({questions.length - answeredCount})</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded bg-blue-600" />
                    <span>Current Active</span>
                  </div>
                </div>

                <div className="pt-3">
                  <button
                    onClick={handleSubmit}
                    className="w-full py-2.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs"
                  >
                    Finish & Submit Exam
                  </button>
                </div>
              </div>

            </div>
          )}

        </div>

      </div>
    </div>
  );
};
