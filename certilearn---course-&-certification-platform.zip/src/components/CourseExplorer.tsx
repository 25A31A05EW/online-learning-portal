import React, { useState } from 'react';
import { useCourse } from '../context/CourseContext';
import { CourseCard } from './CourseCard';
import { Search, Filter, BookOpen } from 'lucide-react';

interface CourseExplorerProps {
  onSelectCourse: (courseId: string) => void;
}

const CATEGORIES = [
  'All Tracks',
  'Programming Languages',
  'Web Development',
  'Database Management',
  'Artificial Intelligence',
  'Data Structures and Algorithms',
  'Cybersecurity'
];

export const CourseExplorer: React.FC<CourseExplorerProps> = ({ onSelectCourse }) => {
  const { courses } = useCourse();
  const [selectedCategory, setSelectedCategory] = useState('All Tracks');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLevel, setSelectedLevel] = useState<string>('All');

  const filteredCourses = courses.filter(c => {
    const matchesCat = selectedCategory === 'All Tracks' || c.category === selectedCategory;
    const matchesLevel = selectedLevel === 'All' || c.level === selectedLevel;
    const matchesSearch =
      c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesLevel && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
      
      {/* Title & Introduction */}
      <div className="space-y-2">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Explore Recorded Video Courses
        </h1>
        <p className="text-sm text-slate-500 max-w-2xl leading-relaxed">
          All courses are delivered via on-demand recorded video lectures. Learn at your own convenience, practice hands-on assignments, and join scheduled weekly doubt-clearing sessions.
        </p>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search python, database, react, algorithms..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs border border-slate-300 rounded-xl bg-white shadow-2xs focus:outline-none focus:border-blue-500"
          />
        </div>

        {/* Level Selector */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500 font-medium">Difficulty:</span>
          <select
            value={selectedLevel}
            onChange={e => setSelectedLevel(e.target.value)}
            className="text-xs border border-slate-300 rounded-lg px-2.5 py-1.5 bg-white shadow-2xs focus:outline-none"
          >
            <option value="All">All Levels</option>
            <option value="Beginner">Beginner</option>
            <option value="Intermediate">Intermediate</option>
            <option value="Advanced">Advanced</option>
          </select>
        </div>

      </div>

      {/* Interactive Category Segmented Bar (Zero-pill compliant buttons) */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs font-semibold">
        {CATEGORIES.map(cat => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3.5 py-2 rounded-lg transition-colors whitespace-nowrap ${
              selectedCategory === cat
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Course Grid */}
      {filteredCourses.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3">
          <BookOpen className="w-10 h-10 text-slate-300 mx-auto" />
          <h3 className="text-base font-bold text-slate-800">No Courses Found</h3>
          <p className="text-xs text-slate-500">
            Try adjusting your search query or switching categories.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCourses.map(course => (
            <CourseCard
              key={course.id}
              course={course}
              onSelectCourse={onSelectCourse}
            />
          ))}
        </div>
      )}

    </div>
  );
};
