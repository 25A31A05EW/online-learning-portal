import React, { useState } from 'react';
import { Course, Lesson } from '../types';
import { useCourse } from '../context/CourseContext';
import { useAuth } from '../context/AuthContext';
import { VideoPlayer } from './VideoPlayer';
import {
  BookOpen,
  FileText,
  HelpCircle,
  Award,
  Download,
  CheckCircle2,
  Lock,
  MessageSquare,
  Send,
  Plus,
  Calendar,
  AlertCircle,
  ExternalLink,
  ChevronDown,
  ChevronRight,
  Code2
} from 'lucide-react';

interface ClassroomViewProps {
  course: Course;
  onOpenExam: () => void;
  onOpenCertificate: () => void;
  onOpenDoubtModal: (lessonId?: string) => void;
}

export const ClassroomView: React.FC<ClassroomViewProps> = ({
  course,
  onOpenExam,
  onOpenCertificate,
  onOpenDoubtModal
}) => {
  const {
    isEnrolled,
    enrollInCourse,
    getLessonProgress,
    getCourseCompletionPercentage,
    doubts,
    replyToDoubt,
    resolveDoubt,
    assignments,
    submissions,
    submitAssignment,
    certificates
  } = useCourse();

  const { currentUser } = useAuth();
  const enrolled = isEnrolled(course.id);
  const completionPercentage = enrolled ? getCourseCompletionPercentage(course.id) : 0;

  // Flatten all lessons in order for prev/next
  const allLessons: { lesson: Lesson; moduleTitle: string }[] = [];
  course.modules.forEach(m => {
    m.lessons.forEach(l => {
      allLessons.push({ lesson: l, moduleTitle: m.title });
    });
  });

  const [activeLessonId, setActiveLessonId] = useState<string>(() => {
    return allLessons[0]?.lesson.id || '';
  });

  const [activeTab, setActiveTab] = useState<'overview' | 'materials' | 'doubts' | 'assignment' | 'exam'>('overview');
  const [doubtReplyText, setDoubtReplyText] = useState<{ [doubtId: string]: string }>({});
  const [assignmentInput, setAssignmentInput] = useState('');
  const [assignmentSubmittedMsg, setAssignmentSubmittedMsg] = useState(false);

  // Active lesson object
  const activeLesson = allLessons.find(item => item.lesson.id === activeLessonId)?.lesson || allLessons[0]?.lesson;
  const activeIndex = allLessons.findIndex(item => item.lesson.id === activeLesson?.id);

  // Filter doubts for this course
  const courseDoubts = doubts.filter(d => d.courseId === course.id);

  // User certificate if issued
  const userCertificate = certificates.find(
    c => c.courseId === course.id && c.studentId === currentUser?.id
  );

  // Course assignment
  const courseAssignment = assignments.find(a => a.courseId === course.id);
  const userSubmission = submissions.find(
    s => s.courseId === course.id && s.studentId === currentUser?.id
  );

  const handleNextLesson = () => {
    if (activeIndex < allLessons.length - 1) {
      setActiveLessonId(allLessons[activeIndex + 1].lesson.id);
    }
  };

  const handlePrevLesson = () => {
    if (activeIndex > 0) {
      setActiveLessonId(allLessons[activeIndex - 1].lesson.id);
    }
  };

  const handleSendReply = (doubtId: string) => {
    const text = doubtReplyText[doubtId];
    if (text && text.trim()) {
      replyToDoubt(doubtId, text.trim());
      setDoubtReplyText(prev => ({ ...prev, [doubtId]: '' }));
    }
  };

  const handleAssignmentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!assignmentInput.trim() || !courseAssignment) return;
    submitAssignment(courseAssignment.id, course.id, assignmentInput.trim(), 'grade_calculator.py');
    setAssignmentInput('');
    setAssignmentSubmittedMsg(true);
    setTimeout(() => setAssignmentSubmittedMsg(false), 4000);
  };

  if (!enrolled) {
    return (
      <div className="max-w-5xl mx-auto px-4 py-12">
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
          <div className="aspect-video relative bg-slate-900 overflow-hidden max-h-[380px]">
            <img
              src={course.imageUrl}
              alt={course.title}
              className="w-full h-full object-cover opacity-75"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent flex items-end p-8">
              <div className="space-y-3 max-w-2xl text-white">
                <div className="text-xs uppercase tracking-wider text-blue-400 font-bold">
                  {course.category} · {course.level}
                </div>
                <h1 className="text-2xl sm:text-3xl font-extrabold">{course.title}</h1>
                <p className="text-sm text-slate-300 leading-relaxed">{course.subtitle}</p>
              </div>
            </div>
          </div>

          <div className="p-8 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-blue-50/70 border border-blue-200/60 rounded-xl">
              <div>
                <h3 className="text-sm font-bold text-blue-900">Recorded Learning Track</h3>
                <p className="text-xs text-blue-700">
                  Enroll to unlock all {allLessons.length} recorded video lectures, downloadable notes, doubt forums, and the final 20-question certification exam.
                </p>
              </div>
              <button
                onClick={() => enrollInCourse(course.id)}
                className="px-6 py-3 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm whitespace-nowrap"
              >
                Enroll in Course (Free)
              </button>
            </div>

            {/* Syllabus Overview */}
            <div className="space-y-4">
              <h3 className="text-base font-bold text-slate-900">Curriculum Syllabus</h3>
              <div className="space-y-3">
                {course.modules.map((m, idx) => (
                  <div key={m.id} className="border border-slate-200 rounded-xl p-4 bg-slate-50">
                    <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wide">
                      {m.title}
                    </h4>
                    <div className="mt-2 divide-y divide-slate-200/60">
                      {m.lessons.map(l => (
                        <div key={l.id} className="py-2 flex items-center justify-between text-xs text-slate-600">
                          <span className="font-medium text-slate-700">{l.title}</span>
                          <span className="text-slate-400">{l.durationMinutes} mins</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Top Banner: Course Title & Completion Status */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xs">
        <div>
          <div className="text-xs text-slate-500 flex items-center gap-2">
            <span>{course.category}</span>
            <span aria-hidden="true">·</span>
            <span>Recorded Self-Paced Track</span>
          </div>
          <h1 className="text-lg font-bold text-slate-900">{course.title}</h1>
        </div>

        <div className="flex items-center gap-4">
          <div className="text-right">
            <div className="text-xs text-slate-500">Course Progress</div>
            <div className="text-sm font-bold text-blue-600">{completionPercentage}% Completed</div>
          </div>
          <div className="w-24 h-2 bg-slate-100 rounded-full overflow-hidden">
            <div
              className="h-full bg-blue-600 rounded-full transition-all duration-300"
              style={{ width: `${completionPercentage}%` }}
            />
          </div>
          {userCertificate ? (
            <button
              onClick={onOpenCertificate}
              className="px-3 py-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-300 hover:bg-emerald-100 rounded-lg flex items-center gap-1.5"
            >
              <Award className="w-4 h-4 text-emerald-600" />
              <span>View Certificate</span>
            </button>
          ) : (
            <button
              onClick={onOpenExam}
              className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs flex items-center gap-1.5"
            >
              <Award className="w-4 h-4" />
              <span>Final Exam ({course.passingPercentage}% Pass)</span>
            </button>
          )}
        </div>
      </div>

      {/* Main 2-Column Split: Player & Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: Video Player + Tabbed Content (8 cols) */}
        <div className="lg:col-span-8 space-y-5">
          
          {/* Custom HTML5 Video Player */}
          {activeLesson && (
            <VideoPlayer
              courseId={course.id}
              lessonId={activeLesson.id}
              videoUrl={activeLesson.videoUrl}
              title={activeLesson.title}
              onPrevLesson={handlePrevLesson}
              onNextLesson={handleNextLesson}
              hasPrev={activeIndex > 0}
              hasNext={activeIndex < allLessons.length - 1}
            />
          )}

          {/* Tab Navigation */}
          <div className="border-b border-slate-200 flex items-center gap-1 overflow-x-auto text-xs font-semibold text-slate-600">
            <button
              onClick={() => setActiveTab('overview')}
              className={`py-3 px-4 border-b-2 transition-colors whitespace-nowrap ${
                activeTab === 'overview'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent hover:text-slate-900'
              }`}
            >
              Lesson Notes & Code
            </button>
            <button
              onClick={() => setActiveTab('materials')}
              className={`py-3 px-4 border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                activeTab === 'materials'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent hover:text-slate-900'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Study Materials ({course.materials.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('doubts')}
              className={`py-3 px-4 border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                activeTab === 'doubts'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent hover:text-slate-900'
              }`}
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Doubt Forum ({courseDoubts.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('assignment')}
              className={`py-3 px-4 border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                activeTab === 'assignment'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent hover:text-slate-900'
              }`}
            >
              <Code2 className="w-3.5 h-3.5" />
              <span>Course Assignment</span>
            </button>
            <button
              onClick={() => setActiveTab('exam')}
              className={`py-3 px-4 border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                activeTab === 'exam'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent hover:text-slate-900'
              }`}
            >
              <Award className="w-3.5 h-3.5" />
              <span>Final Certification</span>
            </button>
          </div>

          {/* Tab 1: Lesson Notes & Code */}
          {activeTab === 'overview' && activeLesson && (
            <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
              <div>
                <h3 className="text-base font-bold text-slate-900">{activeLesson.title}</h3>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  {activeLesson.description}
                </p>
              </div>

              {activeLesson.codeSnippet && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <span className="font-semibold uppercase tracking-wider text-slate-600">
                      Executable Code Snippet ({activeLesson.codeLanguage || 'python'})
                    </span>
                    <button
                      onClick={() => navigator.clipboard.writeText(activeLesson.codeSnippet || '')}
                      className="text-blue-600 hover:underline"
                    >
                      Copy Snippet
                    </button>
                  </div>
                  <pre className="p-4 bg-slate-900 text-slate-100 rounded-lg text-xs font-mono overflow-x-auto leading-relaxed border border-slate-800">
                    {activeLesson.codeSnippet}
                  </pre>
                </div>
              )}

              <div className="p-4 bg-blue-50/70 border border-blue-200/60 rounded-xl flex items-center justify-between">
                <div className="text-xs text-blue-900">
                  <strong>Have a question on this lesson?</strong> Submit your doubt to Dr. Elena Vance and get clarification in the weekly scheduled live session.
                </div>
                <button
                  onClick={() => onOpenDoubtModal(activeLesson.id)}
                  className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg whitespace-nowrap ml-4"
                >
                  Ask Doubt
                </button>
              </div>
            </div>
          )}

          {/* Tab 2: Study Materials */}
          {activeTab === 'materials' && (
            <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
              <div>
                <h3 className="text-base font-bold text-slate-900">Course Study Materials</h3>
                <p className="text-xs text-slate-500">
                  Download official lecture notes, slide decks, practice problem sets, and starter code repositories.
                </p>
              </div>

              <div className="space-y-3">
                {course.materials.map(mat => (
                  <div
                    key={mat.id}
                    className="p-4 border border-slate-200 rounded-xl hover:border-blue-300 transition-colors flex items-center justify-between gap-4 bg-slate-50/50"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs uppercase shrink-0">
                        {mat.type}
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-slate-900">{mat.title}</h4>
                        <div className="text-[11px] text-slate-500 flex items-center gap-2 mt-0.5">
                          <span>{mat.fileSize}</span>
                          <span aria-hidden="true">·</span>
                          <span>Uploaded {mat.uploadedAt}</span>
                        </div>
                        <p className="text-xs text-slate-600 mt-1">{mat.description}</p>
                      </div>
                    </div>

                    <a
                      href={mat.downloadUrl}
                      onClick={(e) => {
                        e.preventDefault();
                        // Trigger synthetic text file download
                        const blob = new Blob([`CertiLearn Material: ${mat.title}\nCourse: ${course.title}\nDescription: ${mat.description}`], { type: 'text/plain' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = `${mat.title.replace(/\s+/g, '_')}.txt`;
                        a.click();
                      }}
                      className="px-3.5 py-2 text-xs font-semibold text-slate-700 hover:text-blue-600 bg-white border border-slate-200 hover:border-blue-300 rounded-lg shadow-2xs transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download</span>
                    </a>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tab 3: Dedicated Doubt Section */}
          {activeTab === 'doubts' && (
            <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-slate-900">Student Doubts & Questions</h3>
                  <p className="text-xs text-slate-500">
                    Submit questions related to recorded lessons. Doubts are answered by teachers and reviewed in scheduled live doubt sessions.
                  </p>
                </div>
                <button
                  onClick={() => onOpenDoubtModal(activeLesson?.id)}
                  className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs flex items-center gap-1.5 whitespace-nowrap"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Submit New Doubt</span>
                </button>
              </div>

              {courseDoubts.length === 0 ? (
                <div className="text-center py-8 text-xs text-slate-500">
                  No doubts submitted yet for this course. Be the first to ask!
                </div>
              ) : (
                <div className="space-y-4">
                  {courseDoubts.map(doubt => (
                    <div
                      key={doubt.id}
                      className="border border-slate-200 rounded-xl p-5 space-y-3 bg-white"
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex items-center gap-2">
                          <img
                            src={doubt.studentAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80'}
                            alt={doubt.studentName}
                            referrerPolicy="no-referrer"
                            className="w-7 h-7 rounded-full object-cover"
                          />
                          <div>
                            <div className="text-xs font-bold text-slate-900">{doubt.studentName}</div>
                            <div className="text-[11px] text-slate-400">
                              {doubt.lessonTitle ? `On ${doubt.lessonTitle}` : 'General Course Doubt'} · {doubt.createdAt}
                            </div>
                          </div>
                        </div>

                        {doubt.status === 'resolved' ? (
                          <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-md">
                            Resolved
                          </span>
                        ) : (
                          <span className="text-[11px] font-semibold text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-md">
                            Pending Teacher Reply
                          </span>
                        )}
                      </div>

                      <div>
                        <h4 className="text-xs font-bold text-slate-900">{doubt.title}</h4>
                        <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                          {doubt.description}
                        </p>
                      </div>

                      {doubt.screenshotUrl && (
                        <div className="rounded-lg overflow-hidden border border-slate-200 max-w-sm">
                          <img
                            src={doubt.screenshotUrl}
                            alt="Student screenshot"
                            className="w-full object-cover"
                          />
                        </div>
                      )}

                      {/* Replies */}
                      {doubt.replies.length > 0 && (
                        <div className="pt-3 border-t border-slate-100 space-y-2.5">
                          {doubt.replies.map(rep => (
                            <div key={rep.id} className="p-3 bg-slate-50 rounded-lg text-xs space-y-1">
                              <div className="flex items-center justify-between">
                                <span className="font-bold text-slate-800">
                                  {rep.authorName} ({rep.authorRole === 'teacher' ? 'Instructor' : 'Peer'})
                                </span>
                                <span className="text-[10px] text-slate-400">{rep.createdAt}</span>
                              </div>
                              <p className="text-slate-600 leading-relaxed">{rep.content}</p>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Reply Form */}
                      <div className="pt-2 flex items-center gap-2">
                        <input
                          type="text"
                          value={doubtReplyText[doubt.id] || ''}
                          onChange={e =>
                            setDoubtReplyText(prev => ({ ...prev, [doubt.id]: e.target.value }))
                          }
                          placeholder="Write a response or discussion comment..."
                          className="flex-1 px-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-none focus:border-blue-500"
                        />
                        <button
                          onClick={() => handleSendReply(doubt.id)}
                          className="px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg flex items-center gap-1"
                        >
                          <Send className="w-3 h-3" />
                          <span>Reply</span>
                        </button>
                        {currentUser?.role === 'teacher' && doubt.status !== 'resolved' && (
                          <button
                            onClick={() => resolveDoubt(doubt.id)}
                            className="px-3 py-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 rounded-lg"
                          >
                            Mark Resolved
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Tab 4: Course Assignment */}
          {activeTab === 'assignment' && courseAssignment && (
            <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-5">
              <div>
                <div className="text-xs text-blue-600 font-bold uppercase tracking-wider">
                  Module Practical Assignment
                </div>
                <h3 className="text-base font-bold text-slate-900 mt-1">{courseAssignment.title}</h3>
                <div className="text-xs text-slate-500 flex items-center gap-3 mt-1">
                  <span>Total Marks: {courseAssignment.totalMarks}</span>
                  <span aria-hidden="true">·</span>
                  <span>Submission Deadline: {courseAssignment.deadline}</span>
                </div>
              </div>

              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                <h4 className="text-xs font-bold text-slate-800">Instructions:</h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {courseAssignment.instructions}
                </p>
              </div>

              {courseAssignment.starterCode && (
                <div className="space-y-1.5">
                  <div className="text-xs font-semibold text-slate-700">Starter Code Template:</div>
                  <pre className="p-3 bg-slate-900 text-slate-100 rounded-lg text-xs font-mono">
                    {courseAssignment.starterCode}
                  </pre>
                </div>
              )}

              {/* Status and Submission Form */}
              {userSubmission ? (
                <div className="p-4 border border-emerald-200 bg-emerald-50/50 rounded-xl space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-emerald-800">
                      Submission Status: {userSubmission.status === 'graded' ? 'Graded' : 'Under Review'}
                    </span>
                    <span className="text-xs text-emerald-700">
                      Submitted on {userSubmission.submittedAt}
                    </span>
                  </div>

                  {userSubmission.status === 'graded' ? (
                    <div className="p-3 bg-white border border-emerald-300 rounded-lg space-y-1.5 text-xs">
                      <div className="flex items-center justify-between font-bold text-slate-900">
                        <span>Marks Awarded:</span>
                        <span className="text-blue-600 text-sm">
                          {userSubmission.marksAwarded} / {courseAssignment.totalMarks}
                        </span>
                      </div>
                      <div className="text-slate-600">
                        <strong>Instructor Feedback:</strong> {userSubmission.teacherFeedback}
                      </div>
                    </div>
                  ) : (
                    <p className="text-xs text-slate-600">
                      Your solution ({userSubmission.attachmentName}) was received and will be reviewed by {course.teacherName}.
                    </p>
                  )}
                </div>
              ) : (
                <form onSubmit={handleAssignmentSubmit} className="space-y-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-800">
                      Paste Solution Code or Summary:
                    </label>
                    <textarea
                      rows={5}
                      value={assignmentInput}
                      onChange={e => setAssignmentInput(e.target.value)}
                      placeholder="Paste your complete Python script or solution text here..."
                      className="w-full p-3 text-xs font-mono border border-slate-300 rounded-lg focus:outline-none focus:border-blue-500"
                      required
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="text-xs text-slate-400">
                      File format: .py / .sql / .zip
                    </div>
                    <button
                      type="submit"
                      className="px-5 py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm"
                    >
                      Submit Assignment
                    </button>
                  </div>

                  {assignmentSubmittedMsg && (
                    <div className="p-3 bg-emerald-50 text-emerald-800 rounded-lg text-xs font-medium border border-emerald-200">
                      Assignment submitted successfully!
                    </div>
                  )}
                </form>
              )}
            </div>
          )}

          {/* Tab 5: Final Exam & Certification */}
          {activeTab === 'exam' && (
            <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-6">
              <div>
                <div className="text-xs font-bold text-blue-600 uppercase tracking-wider">
                  Academic Certification Standard
                </div>
                <h3 className="text-lg font-bold text-slate-900 mt-1">
                  Final Comprehensive Examination
                </h3>
                <p className="text-xs text-slate-500 leading-relaxed mt-1">
                  CertiLearn issues downloadable, verifiable certificates only to candidates who satisfy the coursework and pass this official 20-question evaluation with at least 70% accuracy.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                  <div className="text-xs text-slate-500">Total Questions</div>
                  <div className="text-xl font-bold text-slate-900 mt-1">20 MCQs</div>
                </div>
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                  <div className="text-xs text-slate-500">Passing Threshold</div>
                  <div className="text-xl font-bold text-blue-600 mt-1">70% (14/20)</div>
                </div>
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                  <div className="text-xs text-slate-500">Time Limit</div>
                  <div className="text-xl font-bold text-slate-900 mt-1">20 Minutes</div>
                </div>
              </div>

              {userCertificate ? (
                <div className="p-5 bg-emerald-50 border border-emerald-300 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <Award className="w-8 h-8 text-emerald-600 shrink-0" />
                    <div>
                      <h4 className="text-sm font-bold text-emerald-900">
                        Certificate Earned & Issued!
                      </h4>
                      <p className="text-xs text-emerald-700">
                        ID: {userCertificate.id} · Issued {userCertificate.issueDate} with {userCertificate.scorePercentage}% score.
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={onOpenCertificate}
                    className="px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm whitespace-nowrap"
                  >
                    View & Download Certificate
                  </button>
                </div>
              ) : (
                <div className="p-5 bg-blue-50/70 border border-blue-200/60 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="space-y-1">
                    <h4 className="text-xs font-bold text-blue-900">Ready to test your skills?</h4>
                    <p className="text-xs text-blue-700">
                      Ensure you have watched all recorded lectures before starting the timed evaluation.
                    </p>
                  </div>
                  <button
                    onClick={onOpenExam}
                    className="px-5 py-2.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm whitespace-nowrap"
                  >
                    Start Online Examination
                  </button>
                </div>
              )}
            </div>
          )}

        </div>

        {/* Right Column: Curriculum Playlist Sidebar (4 cols) */}
        <div className="lg:col-span-4 bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          
          <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
              Course Content ({allLessons.length} Recorded Lessons)
            </h3>
            <span className="text-[11px] font-semibold text-blue-600">
              {allLessons.filter(item => getLessonProgress(course.id, item.lesson.id)?.completed).length}/{allLessons.length} Completed
            </span>
          </div>

          <div className="divide-y divide-slate-100 max-h-[700px] overflow-y-auto">
            {course.modules.map((m, mIdx) => (
              <div key={m.id} className="py-2">
                <div className="px-4 py-2 font-bold text-xs text-slate-900 bg-slate-50/80 flex items-center justify-between">
                  <span>{m.title}</span>
                  <span className="text-[10px] text-slate-400 font-normal">
                    {m.lessons.length} lessons
                  </span>
                </div>

                <div className="divide-y divide-slate-50">
                  {m.lessons.map((l, lIdx) => {
                    const prog = getLessonProgress(course.id, l.id);
                    const isDone = prog?.completed;
                    const isActive = l.id === activeLesson?.id;

                    return (
                      <button
                        key={l.id}
                        onClick={() => setActiveLessonId(l.id)}
                        className={`w-full text-left px-4 py-3 flex items-start gap-3 transition-colors text-xs ${
                          isActive
                            ? 'bg-blue-50/80 text-blue-900 font-medium'
                            : 'hover:bg-slate-50 text-slate-700'
                        }`}
                      >
                        <div className="mt-0.5 shrink-0">
                          {isDone ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          ) : (
                            <div
                              className={`w-4 h-4 rounded-full border flex items-center justify-center text-[10px] ${
                                isActive
                                  ? 'border-blue-600 text-blue-600 font-bold'
                                  : 'border-slate-300 text-slate-400'
                              }`}
                            >
                              {lIdx + 1}
                            </div>
                          )}
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className={`truncate ${isActive ? 'font-bold text-blue-700' : ''}`}>
                            {l.title}
                          </div>
                          <div className="text-[11px] text-slate-400 mt-0.5">
                            {l.durationMinutes} mins · Recorded
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>

        </div>

      </div>

    </div>
  );
};
