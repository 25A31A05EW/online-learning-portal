import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { UserRole } from '../types';
import {
  GraduationCap,
  UserCheck,
  ShieldAlert,
  BookOpen,
  Calendar,
  Award,
  Terminal,
  LogOut,
  LogIn,
  ChevronDown,
  User as UserIcon,
  Menu,
  X
} from 'lucide-react';

interface NavbarProps {
  currentView: string;
  setCurrentView: (view: string) => void;
  onOpenAuth: (mode?: 'login' | 'register') => void;
  onOpenCppDocs: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  setCurrentView,
  onOpenAuth,
  onOpenCppDocs
}) => {
  const { currentUser, logout, switchRoleDemo } = useAuth();
  const [roleMenuOpen, setRoleMenuOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleRoleSelect = (role: UserRole) => {
    switchRoleDemo(role);
    setRoleMenuOpen(false);
    if (role === 'student') setCurrentView('student-dashboard');
    else if (role === 'teacher') setCurrentView('teacher-dashboard');
    else if (role === 'admin') setCurrentView('admin-dashboard');
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-8">
          
          {/* Zone 1: Single text element wordmark with icon */}
          <button
            onClick={() => setCurrentView('home')}
            className="flex items-center gap-2.5 text-left group whitespace-nowrap shrink-0 focus:outline-none"
          >
            <div className="w-9 h-9 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-sm transition-transform group-hover:scale-105">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xl font-bold tracking-tight text-slate-900">
                Certi<span className="text-blue-600">Learn</span>
              </span>
            </div>
          </button>

          {/* Zone 2: 4-5 clean single-line navigation links */}
          <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-slate-600">
            <button
              onClick={() => setCurrentView('home')}
              className={`hover:text-blue-600 transition-colors whitespace-nowrap shrink-0 ${
                currentView === 'home' ? 'text-blue-600 font-semibold' : ''
              }`}
            >
              Home
            </button>
            <button
              onClick={() => setCurrentView('explore')}
              className={`hover:text-blue-600 transition-colors whitespace-nowrap shrink-0 ${
                currentView === 'explore' ? 'text-blue-600 font-semibold' : ''
              }`}
            >
              Explore Courses
            </button>
            <button
              onClick={() => setCurrentView('doubt-sessions')}
              className={`hover:text-blue-600 transition-colors whitespace-nowrap shrink-0 ${
                currentView === 'doubt-sessions' ? 'text-blue-600 font-semibold' : ''
              }`}
            >
              Doubt Sessions
            </button>
            <button
              onClick={() => setCurrentView('verify-certificate')}
              className={`hover:text-blue-600 transition-colors whitespace-nowrap shrink-0 ${
                currentView === 'verify-certificate' ? 'text-blue-600 font-semibold' : ''
              }`}
            >
              Verify Certificate
            </button>
            <button
              onClick={onOpenCppDocs}
              className="text-slate-500 hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
            >
              <Terminal className="w-4 h-4 text-blue-500" />
              <span>C++ & MySQL Specs</span>
            </button>
          </nav>

          {/* Zone 3: 1 primary action or User Profile & Role Switcher */}
          <div className="hidden sm:flex items-center gap-3 shrink-0">
            {/* Quick Demo Switcher */}
            <div className="relative">
              <button
                onClick={() => setRoleMenuOpen(!roleMenuOpen)}
                className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors border border-slate-200"
                title="Switch demo persona between Student, Teacher, and Admin"
              >
                <span className="text-slate-500">Role:</span>
                <span className="capitalize font-semibold text-blue-700">
                  {currentUser?.role || 'Guest'}
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
              </button>

              {roleMenuOpen && (
                <div className="absolute right-0 mt-2 w-52 bg-white rounded-xl shadow-lg border border-slate-200 py-1.5 z-50 text-xs">
                  <div className="px-3 py-1.5 font-semibold text-slate-400 border-b border-slate-100">
                    Switch Test Persona
                  </div>
                  <button
                    onClick={() => handleRoleSelect('student')}
                    className="w-full text-left px-3 py-2 hover:bg-blue-50 text-slate-700 hover:text-blue-700 flex items-center gap-2"
                  >
                    <GraduationCap className="w-4 h-4 text-blue-600" />
                    <div>
                      <div className="font-semibold">Student: Rohan Sharma</div>
                      <div className="text-[11px] text-slate-400">Recorded classes, exams, certs</div>
                    </div>
                  </button>
                  <button
                    onClick={() => handleRoleSelect('teacher')}
                    className="w-full text-left px-3 py-2 hover:bg-blue-50 text-slate-700 hover:text-blue-700 flex items-center gap-2"
                  >
                    <UserCheck className="w-4 h-4 text-emerald-600" />
                    <div>
                      <div className="font-semibold">Teacher: Dr. Elena Vance</div>
                      <div className="text-[11px] text-slate-400">Course studio, doubt sessions</div>
                    </div>
                  </button>
                  <button
                    onClick={() => handleRoleSelect('admin')}
                    className="w-full text-left px-3 py-2 hover:bg-blue-50 text-slate-700 hover:text-blue-700 flex items-center gap-2"
                  >
                    <ShieldAlert className="w-4 h-4 text-purple-600" />
                    <div>
                      <div className="font-semibold">Admin: Chief Administrator</div>
                      <div className="text-[11px] text-slate-400">Platform stats, users, approvals</div>
                    </div>
                  </button>
                </div>
              )}
            </div>

            {currentUser ? (
              <div className="flex items-center gap-3">
                <button
                  onClick={() => {
                    if (currentUser.role === 'student') setCurrentView('student-dashboard');
                    else if (currentUser.role === 'teacher') setCurrentView('teacher-dashboard');
                    else setCurrentView('admin-dashboard');
                  }}
                  className="px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm transition-colors whitespace-nowrap"
                >
                  My Dashboard
                </button>
                <button
                  onClick={logout}
                  className="p-2 text-slate-500 hover:text-red-600 transition-colors rounded-lg hover:bg-slate-100"
                  title="Logout"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => onOpenAuth('login')}
                  className="px-3 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 transition-colors whitespace-nowrap"
                >
                  Log In
                </button>
                <button
                  onClick={() => onOpenAuth('register')}
                  className="px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm transition-colors whitespace-nowrap"
                >
                  Register
                </button>
              </div>
            )}
          </div>

          {/* Mobile menu trigger */}
          <div className="flex sm:hidden items-center gap-2">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-600 hover:text-slate-900"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="sm:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-5 space-y-2 text-sm">
          <button
            onClick={() => { setCurrentView('home'); setMobileMenuOpen(false); }}
            className="block w-full text-left py-2 font-medium text-slate-700 hover:text-blue-600"
          >
            Home
          </button>
          <button
            onClick={() => { setCurrentView('explore'); setMobileMenuOpen(false); }}
            className="block w-full text-left py-2 font-medium text-slate-700 hover:text-blue-600"
          >
            Explore Courses
          </button>
          <button
            onClick={() => { setCurrentView('doubt-sessions'); setMobileMenuOpen(false); }}
            className="block w-full text-left py-2 font-medium text-slate-700 hover:text-blue-600"
          >
            Scheduled Doubt Sessions
          </button>
          <button
            onClick={() => { setCurrentView('verify-certificate'); setMobileMenuOpen(false); }}
            className="block w-full text-left py-2 font-medium text-slate-700 hover:text-blue-600"
          >
            Verify Certificate
          </button>
          <button
            onClick={() => { onOpenCppDocs(); setMobileMenuOpen(false); }}
            className="block w-full text-left py-2 font-medium text-blue-600"
          >
            C++ & MySQL Architecture
          </button>
          
          <div className="pt-3 border-t border-slate-100 flex flex-col gap-2">
            <div className="text-xs font-semibold text-slate-400">Switch Persona:</div>
            <div className="flex gap-2">
              <button
                onClick={() => { handleRoleSelect('student'); setMobileMenuOpen(false); }}
                className="flex-1 py-1.5 text-xs bg-slate-100 hover:bg-blue-50 text-slate-700 rounded-md font-medium"
              >
                Student
              </button>
              <button
                onClick={() => { handleRoleSelect('teacher'); setMobileMenuOpen(false); }}
                className="flex-1 py-1.5 text-xs bg-slate-100 hover:bg-emerald-50 text-slate-700 rounded-md font-medium"
              >
                Teacher
              </button>
              <button
                onClick={() => { handleRoleSelect('admin'); setMobileMenuOpen(false); }}
                className="flex-1 py-1.5 text-xs bg-slate-100 hover:bg-purple-50 text-slate-700 rounded-md font-medium"
              >
                Admin
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
