import React, { useState } from 'react';
import { useCourse } from '../context/CourseContext';
import { X, HelpCircle, Image, Upload } from 'lucide-react';

interface DoubtModalProps {
  courseId: string;
  initialLessonId?: string;
  onClose: () => void;
}

export const DoubtModal: React.FC<DoubtModalProps> = ({
  courseId,
  initialLessonId,
  onClose
}) => {
  const { courses, submitDoubt } = useCourse();
  const course = courses.find(c => c.id === courseId);

  const [lessonId, setLessonId] = useState<string>(initialLessonId || '');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [screenshotUrl, setScreenshotUrl] = useState('');
  const [submitted, setSubmitted] = useState(false);

  // Flatten lessons
  const allLessons: { id: string; title: string }[] = [];
  course?.modules.forEach(m => {
    m.lessons.forEach(l => {
      allLessons.push({ id: l.id, title: l.title });
    });
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) return;

    submitDoubt(
      courseId,
      lessonId || undefined,
      title.trim(),
      description.trim(),
      screenshotUrl.trim() || undefined
    );

    setSubmitted(true);
    setTimeout(() => {
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden">
        
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-5 h-5 text-blue-600" />
            <h3 className="text-base font-bold text-slate-900">Ask a Doubt</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-700 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          <div className="p-8 text-center space-y-2">
            <div className="text-emerald-600 font-bold text-base">
              Doubt Submitted Successfully!
            </div>
            <p className="text-xs text-slate-500">
              Your question has been routed to the instructor and added to the doubt queue.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
            
            <div className="space-y-1.5">
              <label className="font-bold text-slate-700">Course Track</label>
              <input
                type="text"
                value={course?.title || 'Selected Course'}
                disabled
                className="w-full p-2.5 bg-slate-100 border border-slate-200 rounded-lg text-slate-600 font-medium"
              />
            </div>

            <div className="space-y-1.5">
              <label className="font-bold text-slate-700">Related Recorded Lesson (Optional)</label>
              <select
                value={lessonId}
                onChange={e => setLessonId(e.target.value)}
                className="w-full p-2.5 bg-white border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:border-blue-500"
              >
                <option value="">General Course Question</option>
                {allLessons.map(l => (
                  <option key={l.id} value={l.id}>
                    {l.title}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="font-bold text-slate-700">Doubt Title</label>
              <input
                type="text"
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="e.g. Why does Python dictionary lookup have O(1) average complexity?"
                className="w-full p-2.5 border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:border-blue-500"
                required
              />
            </div>

            <div className="space-y-1.5">
              <label className="font-bold text-slate-700">Detailed Description & Context</label>
              <textarea
                rows={4}
                value={description}
                onChange={e => setDescription(e.target.value)}
                placeholder="Describe your question, what you tried, or what line of code produced an error..."
                className="w-full p-2.5 border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:border-blue-500"
                required
              />
            </div>

            <div className="space-y-1.5">
              <label className="font-bold text-slate-700 flex items-center justify-between">
                <span>Screenshot URL or Diagram Link (Optional)</span>
              </label>
              <input
                type="url"
                value={screenshotUrl}
                onChange={e => setScreenshotUrl(e.target.value)}
                placeholder="https://..."
                className="w-full p-2.5 border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-slate-600 hover:text-slate-900 font-semibold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg shadow-sm"
              >
                Submit Doubt
              </button>
            </div>

          </form>
        )}

      </div>
    </div>
  );
};
