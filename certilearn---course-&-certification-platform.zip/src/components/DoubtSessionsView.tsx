import React, { useState } from 'react';
import { useCourse } from '../context/CourseContext';
import { useAuth } from '../context/AuthContext';
import {
  Calendar,
  Clock,
  Video,
  User,
  CheckCircle2,
  ExternalLink,
  Plus,
  PlayCircle,
  AlertCircle
} from 'lucide-react';

interface DoubtSessionsViewProps {
  onScheduleNew?: () => void;
}

export const DoubtSessionsView: React.FC<DoubtSessionsViewProps> = ({ onScheduleNew }) => {
  const { doubtSessions, registerForSession } = useCourse();
  const { currentUser } = useAuth();
  const [filter, setFilter] = useState<'upcoming' | 'completed'>('upcoming');

  const filteredSessions = doubtSessions.filter(s => s.status === filter);

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Header and Explanation */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-6">
        <div>
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-600 uppercase tracking-wider">
            <Video className="w-3.5 h-3.5" />
            <span>Interactive Q&A Architecture</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
            Scheduled Doubt-Clearing Sessions
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-2xl leading-relaxed">
            CertiLearn utilizes <strong>recorded classes</strong> for primary instruction. Teachers host live online sessions exclusively at scheduled intervals to resolve student questions and clarify complex topics.
          </p>
        </div>

        {currentUser?.role === 'teacher' && onScheduleNew && (
          <button
            onClick={onScheduleNew}
            className="px-4 py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm flex items-center gap-2 whitespace-nowrap self-start"
          >
            <Plus className="w-4 h-4" />
            <span>Schedule New Doubt Session</span>
          </button>
        )}
      </div>

      {/* Segmented Filter */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => setFilter('upcoming')}
          className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors ${
            filter === 'upcoming'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
          }`}
        >
          Upcoming Doubt Sessions
        </button>
        <button
          onClick={() => setFilter('completed')}
          className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors ${
            filter === 'completed'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
          }`}
        >
          Past Sessions & Recordings
        </button>
      </div>

      {/* Session Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredSessions.map(session => {
          const isRegistered = currentUser && session.registeredStudentIds.includes(currentUser.id);

          return (
            <div
              key={session.id}
              className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs hover:shadow-md transition-all flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                
                <div className="flex items-center justify-between text-xs text-slate-500">
                  <span className="font-semibold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-md">
                    {session.courseTitle}
                  </span>
                  <span className="flex items-center gap-1.5 font-mono">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    <span>{session.sessionDate}</span>
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900 leading-snug">
                  {session.topic}
                </h3>

                <p className="text-xs text-slate-600 leading-relaxed">
                  {session.description}
                </p>

                {/* Teacher Profile */}
                <div className="flex items-center gap-2.5 pt-2">
                  <img
                    src={session.teacherAvatar}
                    alt={session.teacherName}
                    referrerPolicy="no-referrer"
                    className="w-8 h-8 rounded-full object-cover"
                  />
                  <div>
                    <div className="text-xs font-bold text-slate-900">{session.teacherName}</div>
                    <div className="text-[11px] text-slate-400">Host Instructor</div>
                  </div>
                </div>

                {/* Time & Duration */}
                <div className="flex items-center gap-4 text-xs text-slate-500 pt-2 border-t border-slate-100">
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    <span>{session.startTime} - {session.endTime} (UTC)</span>
                  </div>
                  <div>·</div>
                  <div>{session.registeredStudentIds.length} students RSVP'd</div>
                </div>

              </div>

              {/* Action Buttons */}
              <div className="pt-2">
                {session.status === 'upcoming' ? (
                  <div className="flex items-center gap-3">
                    {isRegistered ? (
                      <span className="flex-1 py-2 px-3 text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center justify-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span>Registered (Reminder Set)</span>
                      </span>
                    ) : (
                      <button
                        onClick={() => registerForSession(session.id)}
                        className="flex-1 py-2 px-3 text-xs font-semibold text-blue-600 hover:text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors text-center"
                      >
                        Register for Session
                      </button>
                    )}

                    <a
                      href={session.meetingLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="py-2 px-4 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-2xs flex items-center gap-1.5 whitespace-nowrap"
                    >
                      <Video className="w-3.5 h-3.5" />
                      <span>Join Meeting</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                ) : (
                  <div>
                    {session.recordingUrl ? (
                      <a
                        href={session.recordingUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full py-2 px-3 text-xs font-semibold text-slate-700 hover:text-blue-600 bg-slate-50 hover:bg-slate-100 rounded-lg border border-slate-200 flex items-center justify-center gap-1.5"
                      >
                        <PlayCircle className="w-4 h-4 text-blue-600" />
                        <span>Watch Session Recording</span>
                      </a>
                    ) : (
                      <span className="text-xs text-slate-400 text-center block">
                        Completed Session
                      </span>
                    )}
                  </div>
                )}
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
};
