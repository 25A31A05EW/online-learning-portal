import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useCourse } from '../context/CourseContext';
import { Course, Doubt, DoubtSession } from '../types';
import {
  BookOpen,
  Plus,
  Video,
  Calendar,
  HelpCircle,
  Award,
  Users,
  CheckCircle2,
  Send,
  FileText,
  Clock,
  Sparkles
} from 'lucide-react';

interface TeacherDashboardProps {
  onSelectCourse: (courseId: string) => void;
}

export const TeacherDashboard: React.FC<TeacherDashboardProps> = ({ onSelectCourse }) => {
  const { currentUser } = useAuth();
  const {
    courses,
    doubts,
    replyToDoubt,
    resolveDoubt,
    doubtSessions,
    createDoubtSession,
    createCourse,
    addLessonToCourse,
    submissions,
    gradeSubmission
  } = useCourse();

  const [activeTab, setActiveTab] = useState<'courses' | 'doubts' | 'sessions' | 'grading'>('doubts');
  
  // New Course modal state
  const [showNewCourseModal, setShowNewCourseModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newSubtitle, setNewSubtitle] = useState('');
  const [newCategory, setNewCategory] = useState('Programming Languages');
  const [newLevel, setNewLevel] = useState<'Beginner' | 'Intermediate' | 'Advanced'>('Beginner');

  // New Doubt Session state
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [sessionCourseId, setSessionCourseId] = useState(courses[0]?.id || '');
  const [sessionTopic, setSessionTopic] = useState('');
  const [sessionDesc, setSessionDesc] = useState('');
  const [sessionDate, setSessionDate] = useState('2026-03-18');
  const [startTime, setStartTime] = useState('18:00');
  const [endTime, setEndTime] = useState('19:30');
  const [meetLink, setMeetLink] = useState('https://meet.google.com/new-session-qna');

  // Quick reply text
  const [replyInputs, setReplyInputs] = useState<{ [doubtId: string]: string }>({});

  // Grade state
  const [gradeInputs, setGradeInputs] = useState<{ [subId: string]: { marks: number; feedback: string } }>({});

  const teacherCourses = courses.filter(c => c.teacherId === currentUser?.id || true);
  const unresolvedDoubts = doubts.filter(d => d.status === 'pending');

  const handleCreateCourseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    createCourse({
      title: newTitle,
      subtitle: newSubtitle,
      category: newCategory,
      level: newLevel,
      modules: [
        {
          id: `mod-${Date.now()}`,
          courseId: '',
          title: 'Module 1: Getting Started & Recorded Overview',
          order: 1,
          lessons: [
            {
              id: `les-${Date.now()}`,
              moduleId: '',
              title: 'Lesson 1: Foundations & Architecture',
              durationMinutes: 20,
              videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
              description: 'Initial lecture on course goals, setup, and key paradigms.',
              order: 1
            }
          ]
        }
      ]
    });

    setNewTitle('');
    setNewSubtitle('');
    setShowNewCourseModal(false);
  };

  const handleScheduleSessionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!sessionTopic.trim() || !sessionCourseId) return;

    const course = courses.find(c => c.id === sessionCourseId);

    createDoubtSession({
      courseId: sessionCourseId,
      courseTitle: course?.title || 'Selected Course',
      teacherId: currentUser?.id || 'teacher-1',
      teacherName: currentUser?.name || 'Dr. Elena Vance',
      teacherAvatar: currentUser?.avatar || 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80',
      topic: sessionTopic,
      description: sessionDesc,
      sessionDate,
      startTime,
      endTime,
      meetingLink: meetLink
    });

    setShowScheduleModal(false);
    setSessionTopic('');
    setSessionDesc('');
  };

  const handleSendTeacherReply = (doubtId: string) => {
    const text = replyInputs[doubtId];
    if (text && text.trim()) {
      replyToDoubt(doubtId, text.trim());
      resolveDoubt(doubtId);
      setReplyInputs(prev => ({ ...prev, [doubtId]: '' }));
    }
  };

  const handleGradeSubmit = (submissionId: string) => {
    const data = gradeInputs[submissionId];
    if (!data) return;
    gradeSubmission(submissionId, data.marks || 45, data.feedback || 'Well done!');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Studio Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-md">
            <span>Faculty Studio</span>
            <span>·</span>
            <span>Recorded Lectures & Scheduled Doubt Clearing</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mt-1">
            Instructor Portal: {currentUser?.name}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-xl leading-relaxed">
            Manage your recorded video curricula, review student doubts submitted on lectures, host scheduled Google Meet / Zoom doubt-clearing sessions, and grade practical assignments.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => setShowScheduleModal(true)}
            className="px-4 py-2.5 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-white border border-slate-300 rounded-lg shadow-2xs flex items-center gap-2 whitespace-nowrap"
          >
            <Calendar className="w-4 h-4 text-blue-600" />
            <span>Schedule Doubt Session</span>
          </button>
          <button
            onClick={() => setShowNewCourseModal(true)}
            className="px-4 py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm flex items-center gap-2 whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            <span>Create New Course</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="text-xs text-slate-500">Active Courses</div>
          <div className="text-2xl font-bold text-slate-900 mt-1">{teacherCourses.length}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Recorded tracks published</div>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="text-xs text-slate-500">Pending Doubts</div>
          <div className="text-2xl font-bold text-amber-600 mt-1">{unresolvedDoubts.length}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Awaiting instructor reply</div>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="text-xs text-slate-500">Scheduled Doubt Sessions</div>
          <div className="text-2xl font-bold text-blue-600 mt-1">{doubtSessions.length}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Google Meet / Zoom Q&A</div>
        </div>
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="text-xs text-slate-500">Submissions to Grade</div>
          <div className="text-2xl font-bold text-purple-600 mt-1">
            {submissions.filter(s => s.status === 'submitted').length}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">Coursework evaluations</div>
        </div>
      </div>

      {/* Segmented Control Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 text-xs font-semibold">
        <button
          onClick={() => setActiveTab('doubts')}
          className={`px-4 py-2 rounded-lg transition-colors flex items-center gap-2 ${
            activeTab === 'doubts'
              ? 'bg-blue-600 text-white shadow-2xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <HelpCircle className="w-4 h-4" />
          <span>Student Doubts Queue ({unresolvedDoubts.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('courses')}
          className={`px-4 py-2 rounded-lg transition-colors flex items-center gap-2 ${
            activeTab === 'courses'
              ? 'bg-blue-600 text-white shadow-2xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>Curricula & Recorded Lectures ({teacherCourses.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('sessions')}
          className={`px-4 py-2 rounded-lg transition-colors flex items-center gap-2 ${
            activeTab === 'sessions'
              ? 'bg-blue-600 text-white shadow-2xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>Scheduled Live Q&A Sessions</span>
        </button>
        <button
          onClick={() => setActiveTab('grading')}
          className={`px-4 py-2 rounded-lg transition-colors flex items-center gap-2 ${
            activeTab === 'grading'
              ? 'bg-blue-600 text-white shadow-2xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Award className="w-4 h-4" />
          <span>Assignment Grading</span>
        </button>
      </div>

      {/* Tab: Doubts Queue */}
      {activeTab === 'doubts' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Students submit these questions while watching recorded videos.</span>
            <span>{unresolvedDoubts.length} unresolved questions</span>
          </div>

          {doubts.length === 0 ? (
            <div className="bg-white rounded-xl border border-slate-200 p-8 text-center text-xs text-slate-500">
              No student doubts submitted.
            </div>
          ) : (
            <div className="space-y-4">
              {doubts.map(doubt => (
                <div
                  key={doubt.id}
                  className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="space-y-1">
                      <div className="text-[11px] font-semibold text-blue-600">
                        {doubt.courseTitle} {doubt.lessonTitle ? `· ${doubt.lessonTitle}` : ''}
                      </div>
                      <h3 className="text-sm font-bold text-slate-900">{doubt.title}</h3>
                      <div className="text-xs text-slate-500 flex items-center gap-2">
                        <span>Submitted by {doubt.studentName}</span>
                        <span>·</span>
                        <span>{doubt.createdAt}</span>
                      </div>
                    </div>

                    <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-md ${
                      doubt.status === 'resolved'
                        ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                        : 'bg-amber-50 text-amber-800 border border-amber-200'
                    }`}>
                      {doubt.status === 'resolved' ? 'Resolved' : 'Pending Response'}
                    </span>
                  </div>

                  <p className="text-xs text-slate-700 bg-slate-50 p-4 rounded-xl leading-relaxed">
                    {doubt.description}
                  </p>

                  {doubt.screenshotUrl && (
                    <div className="rounded-lg overflow-hidden border border-slate-200 max-w-sm">
                      <img
                        src={doubt.screenshotUrl}
                        alt="Doubt screenshot"
                        className="w-full object-cover"
                      />
                    </div>
                  )}

                  {/* Previous Replies */}
                  {doubt.replies.length > 0 && (
                    <div className="space-y-2 border-t border-slate-100 pt-3">
                      <div className="text-[11px] font-bold text-slate-500">Discussion History:</div>
                      {doubt.replies.map(r => (
                        <div key={r.id} className="p-3 bg-blue-50/50 rounded-lg text-xs space-y-1">
                          <div className="font-bold text-slate-800">{r.authorName}</div>
                          <p className="text-slate-600">{r.content}</p>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Teacher Response Form */}
                  <div className="pt-2 flex items-center gap-2">
                    <input
                      type="text"
                      value={replyInputs[doubt.id] || ''}
                      onChange={e =>
                        setReplyInputs(prev => ({ ...prev, [doubt.id]: e.target.value }))
                      }
                      placeholder="Write comprehensive instructor explanation & mark resolved..."
                      className="flex-1 px-3.5 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:border-blue-500"
                    />
                    <button
                      onClick={() => handleSendTeacherReply(doubt.id)}
                      className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg flex items-center gap-1.5"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Answer & Resolve</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab: Courses & Curricula */}
      {activeTab === 'courses' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {teacherCourses.map(course => (
              <div
                key={course.id}
                className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between space-y-4"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <span className="font-semibold text-blue-600">{course.category}</span>
                    <span>{course.modules.length} Modules</span>
                  </div>

                  <h3 className="text-base font-bold text-slate-900">{course.title}</h3>
                  <p className="text-xs text-slate-600 line-clamp-2">{course.description}</p>

                  <div className="text-xs text-slate-500 flex items-center gap-4 pt-2 border-t border-slate-100">
                    <span>{course.enrolledStudentsCount.toLocaleString()} Students Enrolled</span>
                    <span>·</span>
                    <span>{course.passingPercentage}% Exam Threshold</span>
                  </div>
                </div>

                <div className="pt-2 flex items-center gap-3">
                  <button
                    onClick={() => onSelectCourse(course.id)}
                    className="flex-1 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg text-center"
                  >
                    Open Recorded Classroom View
                  </button>
                  <button
                    onClick={() => {
                      const mod = course.modules[0];
                      if (mod) {
                        const newLesTitle = prompt('Enter new lesson title:');
                        if (newLesTitle) {
                          addLessonToCourse(course.id, mod.id, {
                            title: newLesTitle,
                            durationMinutes: 20,
                            videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
                            description: 'Recorded lecture on ' + newLesTitle,
                            order: mod.lessons.length + 1
                          });
                        }
                      }
                    }}
                    className="px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg"
                  >
                    + Add Lesson
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab: Scheduled Doubt Sessions */}
      {activeTab === 'sessions' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">All Scheduled Online Doubt Sessions</h3>
            <button
              onClick={() => setShowScheduleModal(true)}
              className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-2xs flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Schedule Session</span>
            </button>
          </div>

          <div className="space-y-3">
            {doubtSessions.map(s => (
              <div
                key={s.id}
                className="bg-white rounded-xl border border-slate-200 p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xs"
              >
                <div className="space-y-1">
                  <div className="text-[11px] font-semibold text-blue-600">{s.courseTitle}</div>
                  <h4 className="text-sm font-bold text-slate-900">{s.topic}</h4>
                  <div className="text-xs text-slate-500 flex items-center gap-3">
                    <span className="flex items-center gap-1 font-mono">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      {s.sessionDate}
                    </span>
                    <span>·</span>
                    <span>{s.startTime} - {s.endTime} UTC</span>
                    <span>·</span>
                    <span className="font-semibold text-blue-700">{s.registeredStudentIds.length} Students RSVP'd</span>
                  </div>
                </div>

                <a
                  href={s.meetingLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-2xs whitespace-nowrap self-start sm:self-center"
                >
                  Launch Google Meet
                </a>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab: Assignment Grading */}
      {activeTab === 'grading' && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-slate-900">Student Coursework Submissions</h3>
          
          <div className="space-y-3">
            {submissions.map(sub => (
              <div
                key={sub.id}
                className="bg-white rounded-xl border border-slate-200 p-5 space-y-3 shadow-xs"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">
                      Student: {sub.studentName}
                    </h4>
                    <div className="text-[11px] text-slate-400">
                      Submitted on {sub.submittedAt} · File: {sub.attachmentName || 'code.py'}
                    </div>
                  </div>

                  <span className={`text-[11px] font-semibold px-2.5 py-0.5 rounded-md ${
                    sub.status === 'graded' ? 'bg-emerald-50 text-emerald-800' : 'bg-amber-50 text-amber-800'
                  }`}>
                    {sub.status === 'graded' ? `Graded: ${sub.marksAwarded} Marks` : 'Pending Evaluation'}
                  </span>
                </div>

                <pre className="p-3 bg-slate-900 text-slate-100 rounded-lg text-xs font-mono overflow-x-auto">
                  {sub.submissionText}
                </pre>

                {sub.status !== 'graded' ? (
                  <div className="pt-2 flex flex-col sm:flex-row items-center gap-3">
                    <input
                      type="number"
                      placeholder="Marks (out of 50)"
                      value={gradeInputs[sub.id]?.marks ?? ''}
                      onChange={e =>
                        setGradeInputs(prev => ({
                          ...prev,
                          [sub.id]: {
                            ...prev[sub.id],
                            marks: parseInt(e.target.value) || 0,
                            feedback: prev[sub.id]?.feedback || 'Good work.'
                          }
                        }))
                      }
                      className="w-36 px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                    />
                    <input
                      type="text"
                      placeholder="Instructor feedback notes..."
                      value={gradeInputs[sub.id]?.feedback ?? ''}
                      onChange={e =>
                        setGradeInputs(prev => ({
                          ...prev,
                          [sub.id]: {
                            ...prev[sub.id],
                            marks: prev[sub.id]?.marks || 45,
                            feedback: e.target.value
                          }
                        }))
                      }
                      className="flex-1 px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
                    />
                    <button
                      onClick={() => handleGradeSubmit(sub.id)}
                      className="px-4 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg"
                    >
                      Save Grade
                    </button>
                  </div>
                ) : (
                  <div className="text-xs text-slate-600 pt-1">
                    <strong>Feedback provided:</strong> {sub.teacherFeedback}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Modal: Create New Course */}
      {showNewCourseModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/75 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-xl">
            <h3 className="text-base font-bold text-slate-900">Create New Course Track</h3>
            <form onSubmit={handleCreateCourseSubmit} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700">Course Title</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={e => setNewTitle(e.target.value)}
                  placeholder="e.g. Distributed Systems Architecture with Go"
                  className="w-full p-2.5 border border-slate-300 rounded-lg mt-1"
                  required
                />
              </div>

              <div>
                <label className="font-bold text-slate-700">Course Subtitle</label>
                <input
                  type="text"
                  value={newSubtitle}
                  onChange={e => setNewSubtitle(e.target.value)}
                  placeholder="Brief 1-sentence synopsis"
                  className="w-full p-2.5 border border-slate-300 rounded-lg mt-1"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700">Category</label>
                  <select
                    value={newCategory}
                    onChange={e => setNewCategory(e.target.value)}
                    className="w-full p-2.5 border border-slate-300 rounded-lg mt-1"
                  >
                    <option value="Programming Languages">Programming Languages</option>
                    <option value="Web Development">Web Development</option>
                    <option value="Database Management">Database Management</option>
                    <option value="Data Structures and Algorithms">Data Structures and Algorithms</option>
                    <option value="Artificial Intelligence">Artificial Intelligence</option>
                    <option value="Cybersecurity">Cybersecurity</option>
                  </select>
                </div>
                <div>
                  <label className="font-bold text-slate-700">Target Level</label>
                  <select
                    value={newLevel}
                    onChange={e => setNewLevel(e.target.value as any)}
                    className="w-full p-2.5 border border-slate-300 rounded-lg mt-1"
                  >
                    <option value="Beginner">Beginner</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Advanced">Advanced</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowNewCourseModal(false)}
                  className="px-4 py-2 text-slate-600 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-white bg-blue-600 hover:bg-blue-700 font-bold rounded-lg"
                >
                  Create Course
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Schedule Doubt Session */}
      {showScheduleModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/75 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-xl">
            <h3 className="text-base font-bold text-slate-900">
              Schedule Live Teacher Doubt Session
            </h3>
            <p className="text-xs text-slate-500">
              Host a live Google Meet or Zoom session exclusively to answer doubts from enrolled students.
            </p>
            <form onSubmit={handleScheduleSessionSubmit} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700">Target Course</label>
                <select
                  value={sessionCourseId}
                  onChange={e => setSessionCourseId(e.target.value)}
                  className="w-full p-2.5 border border-slate-300 rounded-lg mt-1"
                >
                  {courses.map(c => (
                    <option key={c.id} value={c.id}>{c.title}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-700">Session Topic</label>
                <input
                  type="text"
                  value={sessionTopic}
                  onChange={e => setSessionTopic(e.target.value)}
                  placeholder="e.g. Q&A: Memory Layout & Asynchronous Loops"
                  className="w-full p-2.5 border border-slate-300 rounded-lg mt-1"
                  required
                />
              </div>

              <div>
                <label className="font-bold text-slate-700">Description</label>
                <textarea
                  rows={2}
                  value={sessionDesc}
                  onChange={e => setSessionDesc(e.target.value)}
                  placeholder="What will be reviewed during this doubt session..."
                  className="w-full p-2.5 border border-slate-300 rounded-lg mt-1"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="font-bold text-slate-700">Date</label>
                  <input
                    type="date"
                    value={sessionDate}
                    onChange={e => setSessionDate(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg mt-1"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700">Start Time</label>
                  <input
                    type="time"
                    value={startTime}
                    onChange={e => setStartTime(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg mt-1"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700">End Time</label>
                  <input
                    type="time"
                    value={endTime}
                    onChange={e => setEndTime(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg mt-1"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700">Google Meet / Zoom Meeting Link</label>
                <input
                  type="url"
                  value={meetLink}
                  onChange={e => setMeetLink(e.target.value)}
                  placeholder="https://meet.google.com/..."
                  className="w-full p-2.5 border border-slate-300 rounded-lg mt-1"
                  required
                />
              </div>

              <div className="pt-3 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowScheduleModal(false)}
                  className="px-4 py-2 text-slate-600 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-white bg-blue-600 hover:bg-blue-700 font-bold rounded-lg"
                >
                  Schedule Session
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
