import React from 'react';
import { Course } from '../types';
import { useCourse } from '../context/CourseContext';
import { Clock, BookOpen, Star, User, ArrowRight, CheckCircle2 } from 'lucide-react';

interface CourseCardProps {
  course: Course;
  onSelectCourse: (courseId: string) => void;
}

export const CourseCard: React.FC<CourseCardProps> = ({ course, onSelectCourse }) => {
  const { isEnrolled, getCourseCompletionPercentage } = useCourse();
  const enrolled = isEnrolled(course.id);
  const progressPercent = enrolled ? getCourseCompletionPercentage(course.id) : 0;

  // Calculate total lessons
  const totalLessons = course.modules.reduce((sum, m) => sum + m.lessons.length, 0);

  return (
    <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col group">
      
      {/* Course Banner */}
      <div className="relative aspect-video overflow-hidden bg-slate-900">
        <img
          src={course.imageUrl}
          alt={course.title}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          onError={(e) => {
            // Fallback gradient if path fails
            e.currentTarget.style.display = 'none';
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent opacity-80" />
        
        {/* Category & Level unboxed metadata at top */}
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between text-xs text-white/90 drop-shadow-sm font-medium">
          <span className="bg-slate-900/60 backdrop-blur-xs px-2.5 py-1 rounded-md text-[11px]">
            {course.category}
          </span>
          <span className="bg-slate-900/60 backdrop-blur-xs px-2.5 py-1 rounded-md text-[11px]">
            {course.level}
          </span>
        </div>

        {/* Rating and Reviews */}
        <div className="absolute bottom-3 left-3 flex items-center gap-1.5 text-white text-xs font-semibold drop-shadow-sm">
          <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
          <span>{course.rating.toFixed(1)}</span>
          <span className="text-white/70 font-normal">({course.reviewCount})</span>
        </div>
      </div>

      {/* Course Content */}
      <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
        
        <div className="space-y-2">
          {/* Unboxed metadata: duration · lessons · self-paced */}
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <span>{course.durationHours} hrs</span>
            <span aria-hidden="true">·</span>
            <span>{totalLessons} recorded lessons</span>
            <span aria-hidden="true">·</span>
            <span>Self-Paced</span>
          </div>

          <h3 className="text-base font-bold text-slate-900 line-clamp-2 leading-snug group-hover:text-blue-600 transition-colors">
            {course.title}
          </h3>

          <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
            {course.subtitle || course.description}
          </p>
        </div>

        {/* Instructor info */}
        <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <img
              src={course.teacherAvatar}
              alt={course.teacherName}
              referrerPolicy="no-referrer"
              className="w-6 h-6 rounded-full object-cover"
            />
            <span className="font-medium text-slate-800 truncate max-w-[130px]">
              {course.teacherName}
            </span>
          </div>
          <span className="text-[11px] text-slate-400">
            {course.enrolledStudentsCount.toLocaleString()} enrolled
          </span>
        </div>

        {/* Action / Enrollment Progress */}
        <div className="pt-2">
          {enrolled ? (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-500 font-medium">Learning Progress</span>
                <span className="font-bold text-blue-600">{progressPercent}%</span>
              </div>
              <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-blue-600 rounded-full transition-all duration-300"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
              <button
                onClick={() => onSelectCourse(course.id)}
                className="w-full py-2.5 px-4 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors flex items-center justify-center gap-1.5"
              >
                <span>Resume Recorded Lectures</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => onSelectCourse(course.id)}
              className="w-full py-2.5 px-4 text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 rounded-lg transition-colors flex items-center justify-center gap-1.5"
            >
              <span>View Curriculum & Enroll</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

      </div>

    </div>
  );
};
