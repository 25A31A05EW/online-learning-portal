import React, { useState } from 'react';
import { X, Terminal, Database, Code2, Copy, Check, FileText } from 'lucide-react';

interface CppArchitectureModalProps {
  onClose: () => void;
}

export const CppArchitectureModal: React.FC<CppArchitectureModalProps> = ({ onClose }) => {
  const [activeTab, setActiveTab] = useState<'schema' | 'cpp' | 'cmake' | 'readme'>('schema');
  const [copied, setCopied] = useState(false);

  const schemaContent = `-- MySQL 8.0 Relational Database Schema
-- 17 Normalized Tables for CertiLearn Platform
CREATE TABLE users (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    phone VARCHAR(30),
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('student', 'teacher', 'admin') NOT NULL DEFAULT 'student',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE courses (
    id VARCHAR(36) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    level ENUM('Beginner', 'Intermediate', 'Advanced'),
    duration_hours INT NOT NULL,
    teacher_id VARCHAR(36) NOT NULL,
    passing_percentage INT NOT NULL DEFAULT 70,
    FOREIGN KEY (teacher_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE modules (
    id VARCHAR(36) PRIMARY KEY,
    course_id VARCHAR(36) NOT NULL,
    title VARCHAR(255) NOT NULL,
    sort_order INT NOT NULL,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);

CREATE TABLE lessons (
    id VARCHAR(36) PRIMARY KEY,
    module_id VARCHAR(36) NOT NULL,
    title VARCHAR(255) NOT NULL,
    duration_minutes INT NOT NULL,
    video_url VARCHAR(500) NOT NULL, -- Recorded classes
    FOREIGN KEY (module_id) REFERENCES modules(id) ON DELETE CASCADE
);

CREATE TABLE video_progress (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    course_id VARCHAR(36) NOT NULL,
    lesson_id VARCHAR(36) NOT NULL,
    watched_seconds INT NOT NULL DEFAULT 0,
    completed BOOLEAN NOT NULL DEFAULT FALSE,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (lesson_id) REFERENCES lessons(id)
);

CREATE TABLE doubt_sessions (
    id VARCHAR(36) PRIMARY KEY,
    course_id VARCHAR(36) NOT NULL,
    teacher_id VARCHAR(36) NOT NULL,
    topic VARCHAR(255) NOT NULL,
    session_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    meeting_link VARCHAR(500) NOT NULL -- Google Meet / Zoom URL
);

CREATE TABLE certificates (
    id VARCHAR(60) PRIMARY KEY, -- e.g. CERT-2026-PY-9842
    course_id VARCHAR(36) NOT NULL,
    student_id VARCHAR(36) NOT NULL,
    student_name VARCHAR(150) NOT NULL,
    score_percentage INT NOT NULL,
    verification_code VARCHAR(100) NOT NULL UNIQUE,
    issue_date DATE NOT NULL
);`;

  const cppContent = `/**
 * CertiLearn C++ High-Performance Backend (Crow Framework)
 * Provides RESTful API for Recorded Learning & Doubt Clearing
 */
#include "crow.h"
#include <mysql/mysql.h>
#include <iostream>

int main() {
    crow::SimpleApp app;

    // Database Connection
    MYSQL* conn = mysql_init(nullptr);
    mysql_real_connect(conn, "localhost", "root", "secret", "certilearn_db", 3306, nullptr, 0);

    // 1. Recorded Courses List
    CROW_ROUTE(app, "/api/courses").methods(crow::HTTPMethod::GET)([]() {
        return crow::response(200, "{\\"status\\":\\"success\\",\\"courses\\":[...]}");
    });

    // 2. Video Progress Tracking (Resume from last watched second)
    CROW_ROUTE(app, "/api/video/progress").methods(crow::HTTPMethod::POST)([](const crow::request& req) {
        auto body = crow::json::load(req.body);
        // Persist timestamp in MySQL video_progress table
        return crow::response(200, "{\\"saved\\":true}");
    });

    // 3. Doubt Submission with Screenshot
    CROW_ROUTE(app, "/api/doubts").methods(crow::HTTPMethod::POST)([](const crow::request& req) {
        return crow::response(201, "{\\"status\\":\\"doubt_registered\\"}");
    });

    // 4. Scheduled Teacher Doubt-Clearing Sessions
    CROW_ROUTE(app, "/api/sessions/schedule").methods(crow::HTTPMethod::POST)([](const crow::request& req) {
        return crow::response(201, "{\\"status\\":\\"session_scheduled\\"}");
    });

    // 5. Automatic Certificate Evaluation
    CROW_ROUTE(app, "/api/exam/submit").methods(crow::HTTPMethod::POST)([](const crow::request& req) {
        // Evaluates 20 MCQs; generates CERT-XXXX-PY ID if >= 70%
        return crow::response(200, "{\\"score\\":90,\\"passed\\":true}");
    });

    std::cout << "CertiLearn C++ Backend listening on port 8080..." << std::endl;
    app.port(8080).multithreaded().run();
}`;

  const cmakeContent = `cmake_minimum_required(VERSION 3.16)
project(CertiLearnBackend VERSION 1.0.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

find_package(Threads REQUIRED)
find_package(OpenSSL REQUIRED)

include_directories(
    \${CMAKE_CURRENT_SOURCE_DIR}/include
    /usr/include/mysql
)

add_executable(certilearn_server src/main.cpp)

target_link_libraries(certilearn_server
    PRIVATE
    Threads::Threads
    OpenSSL::SSL
    OpenSSL::Crypto
    mysqlclient
)`;

  const readmeContent = `# CertiLearn C++ & MySQL System Setup

1. MySQL Initialization:
   $ mysql -u root -p < schema.sql

2. Compile C++ REST Backend:
   $ cd backend-cpp
   $ mkdir -p build && cd build
   $ cmake .. -DCMAKE_BUILD_TYPE=Release
   $ make -j$(nproc)
   $ ./certilearn_server

3. API Documentation:
   - POST /api/auth/login
   - GET  /api/courses
   - POST /api/video/progress
   - POST /api/doubts
   - POST /api/sessions/schedule
   - GET  /api/certificates/verify/:certId`;

  const getActiveCode = () => {
    switch (activeTab) {
      case 'schema': return schemaContent;
      case 'cpp': return cppContent;
      case 'cmake': return cmakeContent;
      case 'readme': return readmeContent;
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(getActiveCode());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-slate-950 text-slate-100 rounded-2xl max-w-4xl w-full border border-slate-800 shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900">
          <div className="flex items-center gap-2.5">
            <Terminal className="w-5 h-5 text-blue-400" />
            <div>
              <h3 className="text-sm font-bold text-white">
                C++ REST Backend & MySQL 8.0 Architecture
              </h3>
              <div className="text-[11px] text-slate-400">
                Full-stack decoupled architecture files included in /backend-cpp
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Strip */}
        <div className="px-6 pt-3 border-b border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('schema')}
              className={`pb-2 px-3 border-b-2 font-semibold transition-colors flex items-center gap-1.5 ${
                activeTab === 'schema'
                  ? 'border-blue-500 text-blue-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Database className="w-3.5 h-3.5" />
              <span>schema.sql (17 Tables)</span>
            </button>
            <button
              onClick={() => setActiveTab('cpp')}
              className={`pb-2 px-3 border-b-2 font-semibold transition-colors flex items-center gap-1.5 ${
                activeTab === 'cpp'
                  ? 'border-blue-500 text-blue-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Code2 className="w-3.5 h-3.5" />
              <span>main.cpp (Crow REST Server)</span>
            </button>
            <button
              onClick={() => setActiveTab('cmake')}
              className={`pb-2 px-3 border-b-2 font-semibold transition-colors flex items-center gap-1.5 ${
                activeTab === 'cmake'
                  ? 'border-blue-500 text-blue-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>CMakeLists.txt</span>
            </button>
            <button
              onClick={() => setActiveTab('readme')}
              className={`pb-2 px-3 border-b-2 font-semibold transition-colors flex items-center gap-1.5 ${
                activeTab === 'readme'
                  ? 'border-blue-500 text-blue-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Setup & API Docs</span>
            </button>
          </div>

          <button
            onClick={handleCopy}
            className="pb-2 text-slate-400 hover:text-white flex items-center gap-1 text-[11px]"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy Source'}</span>
          </button>
        </div>

        {/* Code Content */}
        <div className="p-6 overflow-y-auto flex-1 font-mono text-xs text-slate-300 leading-relaxed bg-slate-950">
          <pre>{getActiveCode()}</pre>
        </div>

      </div>
    </div>
  );
};
