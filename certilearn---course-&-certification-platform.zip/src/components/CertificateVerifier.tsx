import React, { useState } from 'react';
import { useCourse } from '../context/CourseContext';
import { Certificate } from '../types';
import { Search, ShieldCheck, AlertCircle, Award, Calendar, User, BookOpen } from 'lucide-react';

interface CertificateVerifierProps {
  onViewCertificateModal?: (cert: Certificate) => void;
}

export const CertificateVerifier: React.FC<CertificateVerifierProps> = ({ onViewCertificateModal }) => {
  const { verifyCertificateById } = useCourse();
  const [searchQuery, setSearchQuery] = useState('CERT-2026-PY-9842'); // Pre-fill with valid test sample
  const [searchedCert, setSearchedCert] = useState<Certificate | null | undefined>(undefined);
  const [hasSearched, setHasSearched] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    const cert = verifyCertificateById(searchQuery.trim());
    setSearchedCert(cert || null);
    setHasSearched(true);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12 space-y-8">
      
      <div className="text-center space-y-3">
        <div className="inline-flex p-3 rounded-full bg-blue-100/70 text-blue-700 shadow-2xs">
          <ShieldCheck className="w-8 h-8" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Public Certificate Verification Registry
        </h1>
        <p className="text-sm text-slate-600 max-w-xl mx-auto leading-relaxed">
          Verify the authenticity of any credential issued by CertiLearn. Every certificate is tied to verifiable coursework completion and proctored examination marks.
        </p>
      </div>

      {/* Search Input Box */}
      <form onSubmit={handleSearch} className="max-w-xl mx-auto">
        <div className="flex items-center gap-2 p-1.5 bg-white border border-slate-300 rounded-xl shadow-xs focus-within:border-blue-600 focus-within:ring-2 focus-within:ring-blue-100 transition-all">
          <div className="pl-3 text-slate-400">
            <Search className="w-5 h-5" />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Enter Certificate ID (e.g. CERT-2026-PY-9842)"
            className="flex-1 py-2 px-2 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none font-mono"
            required
          />
          <button
            type="submit"
            className="px-5 py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs transition-colors whitespace-nowrap"
          >
            Verify Credential
          </button>
        </div>
        <div className="text-[11px] text-slate-400 text-center mt-2">
          Try sample ID: <span className="font-mono text-blue-600 cursor-pointer underline" onClick={() => setSearchQuery('CERT-2026-PY-9842')}>CERT-2026-PY-9842</span>
        </div>
      </form>

      {/* Verification Result */}
      {hasSearched && (
        <div className="max-w-2xl mx-auto">
          {searchedCert ? (
            <div className="bg-white rounded-2xl border-2 border-emerald-400 p-6 sm:p-8 shadow-md space-y-6">
              
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-xs font-bold text-emerald-800 uppercase tracking-wider">
                    Official Authenticated Credential
                  </div>
                  <h3 className="text-lg font-bold text-slate-900">
                    Status: Valid & Verified by CertiLearn
                  </h3>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs pt-2 border-t border-slate-100">
                <div className="p-3 bg-slate-50 rounded-xl space-y-1">
                  <div className="text-slate-400 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5" />
                    <span>Recipient Student</span>
                  </div>
                  <div className="font-bold text-sm text-slate-900">{searchedCert.studentName}</div>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl space-y-1">
                  <div className="text-slate-400 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>Issue Date</span>
                  </div>
                  <div className="font-bold text-sm text-slate-900">{searchedCert.issueDate}</div>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl space-y-1 sm:col-span-2">
                  <div className="text-slate-400 flex items-center gap-1.5">
                    <BookOpen className="w-3.5 h-3.5" />
                    <span>Accredited Course</span>
                  </div>
                  <div className="font-bold text-sm text-slate-900">{searchedCert.courseTitle}</div>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl space-y-1">
                  <div className="text-slate-400">Instructor of Record</div>
                  <div className="font-semibold text-slate-800">{searchedCert.teacherName}</div>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl space-y-1">
                  <div className="text-slate-400">Exam Passing Score</div>
                  <div className="font-semibold text-emerald-700">{searchedCert.scorePercentage}% Score</div>
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl font-mono text-[11px] text-slate-500 break-all">
                Unique Security Token: {searchedCert.verificationCode}
              </div>

              {onViewCertificateModal && (
                <div className="pt-2 text-center">
                  <button
                    onClick={() => onViewCertificateModal(searchedCert)}
                    className="px-5 py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm"
                  >
                    View Official Certificate Graphic
                  </button>
                </div>
              )}

            </div>
          ) : (
            <div className="bg-white rounded-2xl border-2 border-red-200 p-8 text-center space-y-3 shadow-xs">
              <div className="w-12 h-12 rounded-full bg-red-100 text-red-600 flex items-center justify-center mx-auto">
                <AlertCircle className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-slate-900">Certificate Not Found</h3>
              <p className="text-xs text-slate-600 max-w-md mx-auto leading-relaxed">
                The identifier <strong>{searchQuery}</strong> does not correspond to any issued credential in the CertiLearn registry. Certificates are only issued to students who complete all modules and score $\ge 70\%$ on final exams.
              </p>
            </div>
          )}
        </div>
      )}

    </div>
  );
};
