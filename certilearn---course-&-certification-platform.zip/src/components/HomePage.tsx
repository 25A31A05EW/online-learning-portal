import React from 'react';
import { Hero } from './Hero';
import { CourseCard } from './CourseCard';
import { useCourse } from '../context/CourseContext';
import {
  Video,
  FileText,
  Calendar,
  Award,
  CheckCircle2,
  Clock,
  RotateCcw,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Star,
  Users,
  Code2,
  Database,
  Cpu,
  Layers,
  Terminal
} from 'lucide-react';

interface HomePageProps {
  onSelectCourse: (courseId: string) => void;
  onExplore: () => void;
  onOpenDoubtSessions: () => void;
  onVerify: () => void;
  onOpenAuth: (mode?: 'login' | 'register') => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onSelectCourse,
  onExplore,
  onOpenDoubtSessions,
  onVerify,
  onOpenAuth
}) => {
  const { courses } = useCourse();
  const popularCourses = courses.slice(0, 3);

  return (
    <div className="space-y-16 pb-16">
      
      {/* 1. Hero Section */}
      <Hero
        onExplore={onExplore}
        onOpenDoubtSessions={onOpenDoubtSessions}
        onVerify={onVerify}
      />

      {/* 2. Popular Courses Spotlight */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <div className="text-xs font-bold text-blue-600 uppercase tracking-wider">
              Featured Recorded Curricula
            </div>
            <h2 className="text-2xl font-bold text-slate-900 mt-1">
              Popular Certification Tracks
            </h2>
          </div>
          <button
            onClick={onExplore}
            className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1.5 self-start sm:self-auto"
          >
            <span>View all courses</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {popularCourses.map(course => (
            <CourseCard
              key={course.id}
              course={course}
              onSelectCourse={onSelectCourse}
            />
          ))}
        </div>
      </div>

      {/* 3. Course Categories */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <div className="text-xs font-bold text-blue-600 uppercase tracking-wider">
            Broad Specializations
          </div>
          <h2 className="text-2xl font-bold text-slate-900">
            Explore Course Disciplines
          </h2>
          <p className="text-xs sm:text-sm text-slate-500">
            Structured learning pathways from fundamentals to production architecture.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {[
            { name: 'Programming Languages', icon: Code2, desc: 'Python, C++, TypeScript' },
            { name: 'Web Development', icon: Layers, desc: 'React, Node, Full-Stack' },
            { name: 'Database Management', icon: Database, desc: 'MySQL, SQL, Optimization' },
            { name: 'Data Structures & Algorithms', icon: Terminal, desc: 'LeetCode, Big-O, Graphs' },
            { name: 'Artificial Intelligence', icon: Cpu, desc: 'Neural Nets, LLMs, ML' },
            { name: 'Cybersecurity', icon: ShieldCheck, desc: 'SecOps, Network Defense' },
          ].map((cat, i) => (
            <div
              key={i}
              onClick={onExplore}
              className="p-4 bg-white rounded-xl border border-slate-200 hover:border-blue-400 shadow-2xs hover:shadow-sm transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div className="w-9 h-9 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-colors">
                <cat.icon className="w-4 h-4" />
              </div>
              <div className="mt-3">
                <h4 className="text-xs font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                  {cat.name}
                </h4>
                <p className="text-[11px] text-slate-400 mt-1">{cat.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 4. How It Works - Highlighting Recorded Paradigm */}
      <div className="bg-slate-900 text-white py-16 border-y border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <div className="text-xs font-bold text-blue-400 uppercase tracking-wider">
              Student Learning Journey
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold">
              How the CertiLearn Platform Works
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              Designed specifically around self-paced recorded mastery and scheduled doubt resolution.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            
            <div className="bg-slate-800/80 p-6 rounded-2xl border border-slate-700/80 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold text-base">
                01
              </div>
              <h3 className="text-sm font-bold text-white">
                Learn via Recorded Classes
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Watch studio-recorded HD lectures whenever convenient. Pause, resume, and review complex code snippets at your own rhythm.
              </p>
            </div>

            <div className="bg-slate-800/80 p-6 rounded-2xl border border-slate-700/80 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold text-base">
                02
              </div>
              <h3 className="text-sm font-bold text-white">
                Access Study Materials
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Download companion PDF notes, presentation slides, practice code files, and starter templates for every lesson.
              </p>
            </div>

            <div className="bg-slate-800/80 p-6 rounded-2xl border border-slate-700/80 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold text-base">
                03
              </div>
              <h3 className="text-sm font-bold text-white">
                Scheduled Doubt Sessions
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Teachers host scheduled live online sessions exclusively to answer doubts. Ask questions ahead of time or join live via Google Meet.
              </p>
            </div>

            <div className="bg-slate-800/80 p-6 rounded-2xl border border-slate-700/80 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-base">
                04
              </div>
              <h3 className="text-sm font-bold text-white">
                Exam & Verifiable Certificate
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Clear the timed 20-question comprehensive evaluation with 70%+ score to automatically generate your official verified certificate.
              </p>
            </div>

          </div>

        </div>
      </div>

      {/* 5. Benefits of Online Learning */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <div className="text-xs font-bold text-blue-600 uppercase tracking-wider">
            Why Students Prefer CertiLearn
          </div>
          <h2 className="text-2xl font-bold text-slate-900">
            Benefits of Asynchronous Recorded Education
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 bg-white rounded-xl border border-slate-200 space-y-2 shadow-2xs">
            <Clock className="w-6 h-6 text-blue-600" />
            <h3 className="text-sm font-bold text-slate-900">Learn at Your Own Pace</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              No mandatory daily live streaming attendance. Learn early morning or late at night. Automatically resume from your last watched timestamp.
            </p>
          </div>

          <div className="p-6 bg-white rounded-xl border border-slate-200 space-y-2 shadow-2xs">
            <RotateCcw className="w-6 h-6 text-blue-600" />
            <h3 className="text-sm font-bold text-slate-900">Replay Lessons Anytime</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Rewind difficult sections, adjust playback speed up to 2x, and re-examine execution diagrams whenever you need a refresher.
            </p>
          </div>

          <div className="p-6 bg-white rounded-xl border border-slate-200 space-y-2 shadow-2xs">
            <ShieldCheck className="w-6 h-6 text-emerald-600" />
            <h3 className="text-sm font-bold text-slate-900">Cryptographically Verifiable</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Certificates are not handed out casually. Only students passing proctored 70% threshold evaluations receive verifiable credentials.
            </p>
          </div>
        </div>
      </div>

      {/* 6. Student Testimonials */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="text-center max-w-xl mx-auto space-y-2">
          <div className="text-xs font-bold text-blue-600 uppercase tracking-wider">
            Verified Learner Reviews
          </div>
          <h2 className="text-2xl font-bold text-slate-900">
            Real Student Outcomes
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            {
              name: 'Aarav Patel',
              role: 'Junior Backend Engineer',
              course: 'Python Programming Masterclass',
              comment: 'The recorded video lectures are exceptionally clear without live stream interruptions. The weekly scheduled doubt session with Dr. Vance helped me clarify complex memory reference pointers in Python.',
              rating: 5,
              certId: 'CERT-2026-PY-9842'
            },
            {
              name: 'Sarah Jenkins',
              role: 'Full-Stack Developer',
              course: 'Relational Database Design & MySQL Mastery',
              comment: 'The practical exercises and 20-question final exam made sure I actually understood 3NF normalization. Employers verified my certificate ID directly on the platform registry!',
              rating: 5,
              certId: 'CERT-2026-SQL-4210'
            },
            {
              name: 'Vikram Mehta',
              role: 'Data Analyst',
              course: 'Modern Web Development with React',
              comment: 'Having recorded lessons allowed me to learn around my full-time job. Whenever I got stuck, I posted my doubt with a screenshot and attended the scheduled Google Meet doubt hour.',
              rating: 5,
              certId: 'CERT-2026-WEB-1184'
            }
          ].map((t, i) => (
            <div key={i} className="p-6 bg-white rounded-xl border border-slate-200 shadow-2xs space-y-3 flex flex-col justify-between">
              <div className="space-y-2">
                <div className="flex items-center gap-1 text-amber-400">
                  {[...Array(t.rating)].map((_, idx) => (
                    <Star key={idx} className="w-3.5 h-3.5 fill-amber-400" />
                  ))}
                </div>
                <p className="text-xs text-slate-600 leading-relaxed italic">
                  "{t.comment}"
                </p>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <div>
                  <div className="font-bold text-slate-900">{t.name}</div>
                  <div className="text-[11px] text-slate-400">{t.role}</div>
                </div>
                <div className="text-[10px] text-blue-600 font-mono font-semibold">
                  {t.certId}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 7. Bottom CTA */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-2xl p-8 sm:p-12 text-white shadow-lg text-center space-y-5">
          <h2 className="text-2xl sm:text-3xl font-extrabold max-w-xl mx-auto">
            Ready to Master In-Demand Engineering Skills?
          </h2>
          <p className="text-xs sm:text-sm text-blue-100 max-w-lg mx-auto">
            Join thousands of active learners studying with structured recorded video lectures, scheduled teacher doubt clearing, and recognized certifications.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
            <button
              onClick={() => onOpenAuth('register')}
              className="px-6 py-3 text-xs font-bold text-blue-900 bg-white hover:bg-blue-50 rounded-lg shadow-sm"
            >
              Create Free Account
            </button>
            <button
              onClick={onExplore}
              className="px-6 py-3 text-xs font-bold text-white bg-blue-800/80 hover:bg-blue-800 rounded-lg border border-blue-400/40"
            >
              Browse Recorded Catalog
            </button>
          </div>
        </div>
      </div>

    </div>
  );
};
