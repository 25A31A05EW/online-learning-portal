import React from 'react';
import { PlayCircle, Award, Calendar, CheckCircle2, ArrowRight, ShieldCheck, Video, Clock } from 'lucide-react';

interface HeroProps {
  onExplore: () => void;
  onOpenDoubtSessions: () => void;
  onVerify: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onExplore, onOpenDoubtSessions, onVerify }) => {
  return (
    <div className="relative overflow-hidden bg-gradient-to-b from-blue-50/60 via-white to-slate-50 border-b border-slate-200">
      {/* Subtle grid background */}
      <div 
        className="absolute inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage: `radial-gradient(#1e3a8a 1px, transparent 1px)`,
          backgroundSize: '24px 24px'
        }}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-20 relative">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Core Value Proposition */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Context Notice - Clarifying Recorded Paradigm */}
            <div className="inline-flex items-center gap-2 text-xs font-medium text-blue-900 bg-blue-100/70 border border-blue-200/60 px-3 py-1.5 rounded-md">
              <Video className="w-3.5 h-3.5 text-blue-700" />
              <span>Self-Paced Recorded Video Lectures & Scheduled Live Doubt Clearing</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-slate-900 leading-[1.15]" style={{ textWrap: 'balance' }}>
              Learn Anytime, Anywhere. <br />
              <span className="text-blue-600">Build Your Skills.</span> <br />
              Earn Your Certificates.
            </h1>

            <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl">
              Master modern software engineering, databases, and algorithms through carefully produced, high-resolution recorded video classes. Study at your own pace without daily mandatory live lectures, and resolve doubts in scheduled teacher-led Q&A sessions.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={onExplore}
                className="px-6 py-3.5 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm hover:shadow transition-all flex items-center gap-2 whitespace-nowrap"
              >
                <span>Explore Recorded Courses</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onOpenDoubtSessions}
                className="px-5 py-3.5 text-sm font-semibold text-slate-700 hover:text-slate-900 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg shadow-xs transition-colors flex items-center gap-2 whitespace-nowrap"
              >
                <Calendar className="w-4 h-4 text-blue-600" />
                <span>View Doubt Sessions</span>
              </button>

              <button
                onClick={onVerify}
                className="text-xs font-medium text-slate-500 hover:text-blue-600 transition-colors underline underline-offset-4 py-2"
              >
                Verify Existing Certificate ID
              </button>
            </div>

            {/* Micro Trust Strip */}
            <div className="pt-6 border-t border-slate-200/80 flex flex-wrap items-center gap-6 text-xs text-slate-500">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>100% On-Demand Recorded Videos</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Timed 20-Question Exam (70% Pass)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Tamper-Proof Digital Certificates</span>
              </div>
            </div>

          </div>

          {/* Right Column: Hero Visual Card with High-Res Course Preview */}
          <div className="lg:col-span-5">
            <div className="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden relative group">
              
              {/* Image banner */}
              <div className="relative aspect-video overflow-hidden bg-slate-900">
                <img
                  src="/src/assets/images/course_python_hero_1794126944045.jpg"
                  alt="Python Programming Masterclass preview"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent" />
                
                <button
                  onClick={onExplore}
                  className="absolute inset-0 flex items-center justify-center group-hover:scale-110 transition-transform focus:outline-none"
                >
                  <div className="w-16 h-16 rounded-full bg-blue-600/90 text-white flex items-center justify-center shadow-lg backdrop-blur-xs">
                    <PlayCircle className="w-9 h-9 ml-0.5" />
                  </div>
                </button>

                <div className="absolute bottom-3 left-3 right-3 text-white">
                  <div className="text-xs font-semibold text-blue-300">Featured On-Demand Track</div>
                  <div className="text-sm font-bold truncate">Python Programming Masterclass</div>
                </div>
              </div>

              {/* Card Meta Body */}
              <div className="p-5 space-y-4">
                <div className="flex items-center justify-between text-xs text-slate-500">
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    <span>32 hours on-demand</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Video className="w-3.5 h-3.5 text-slate-400" />
                    <span>3 modules · 9 recorded lectures</span>
                  </div>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-800">Next Live Doubt Session</span>
                    <span className="text-blue-600 font-medium">Thursday 18:00</span>
                  </div>
                  <p className="text-xs text-slate-500 leading-snug">
                    Hosted by Dr. Elena Vance via Google Meet. Submit your questions ahead of time.
                  </p>
                </div>

                <div className="flex items-center justify-between pt-1">
                  <div className="flex items-center gap-2">
                    <img
                      src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=100&q=80"
                      alt="Dr. Elena Vance"
                      referrerPolicy="no-referrer"
                      className="w-8 h-8 rounded-full object-cover"
                    />
                    <div>
                      <div className="text-xs font-bold text-slate-900">Dr. Elena Vance</div>
                      <div className="text-[11px] text-slate-500">Senior CS Professor</div>
                    </div>
                  </div>

                  <button
                    onClick={onExplore}
                    className="px-3.5 py-1.5 text-xs font-semibold text-blue-600 hover:text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors"
                  >
                    Start Learning
                  </button>
                </div>

              </div>

            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
