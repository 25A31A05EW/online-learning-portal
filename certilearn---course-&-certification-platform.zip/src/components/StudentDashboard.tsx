import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useCourse } from '../context/CourseContext';
import { Course, Certificate } from '../types';
import {
  BookOpen,
  Award,
  Video,
  Clock,
  CheckCircle2,
  Calendar,
  AlertCircle,
  ArrowRight,
  TrendingUp,
  FileCheck,
  HelpCircle,
  ExternalLink
} from 'lucide-react';

interface StudentDashboardProps {
  onSelectCourse: (courseId: string) => void;
  onOpenCertificateModal: (cert: Certificate) => void;
  onNavigateToSessions: () => void;
  onExploreMore: () => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({
  onSelectCourse,
  onOpenCertificateModal,
  onNavigateToSessions,
  onExploreMore
}) => {
  const { currentUser } = useAuth();
  const {
    courses,
    enrolledCourseIds,
    getCourseCompletionPercentage,
    doubtSessions,
    certificates,
    submissions,
    doubts
  } = useCourse();

  // Enrolled courses list
  const enrolledCourses = courses.filter(c => enrolledCourseIds.includes(c.id));
  
  // Completed vs In-progress
  const completedCourses = enrolledCourses.filter(c => getCourseCompletionPercentage(c.id) === 100);
  const inProgressCourses = enrolledCourses.filter(c => getCourseCompletionPercentage(c.id) < 100);

  // My certificates
  const myCertificates = certificates.filter(c => c.studentId === currentUser?.id);

  // Upcoming sessions registered
  const upcomingRegisteredSessions = doubtSessions.filter(
    s => s.status === 'upcoming' && currentUser && s.registeredStudentIds.includes(currentUser.id)
  );

  // My doubts
  const myDoubts = doubts.filter(d => d.studentId === currentUser?.id);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-blue-700 via-blue-800 to-indigo-900 rounded-2xl p-6 sm:p-8 text-white shadow-md flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-blue-200 bg-blue-600/50 px-3 py-1 rounded-md">
            <span>Student Academic Portal</span>
            <span>·</span>
            <span>Recorded Learning Track</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Welcome back, {currentUser?.name}!
          </h1>
          <p className="text-xs sm:text-sm text-blue-100 max-w-xl leading-relaxed">
            Continue watching recorded video classes at your own convenience. Check upcoming teacher doubt sessions and complete final examinations to earn accredited certificates.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={onExploreMore}
            className="px-4 py-2.5 text-xs font-semibold text-blue-900 bg-white hover:bg-blue-50 rounded-lg shadow-sm transition-colors whitespace-nowrap"
          >
            Explore More Courses
          </button>
        </div>
      </div>

      {/* KPI Stats Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span>Enrolled Courses</span>
            <BookOpen className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-2">
            {enrolledCourses.length}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            {inProgressCourses.length} in progress · {completedCourses.length} finished
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span>Certificates Earned</span>
            <Award className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-2">
            {myCertificates.length}
          </div>
          <div className="text-[11px] text-emerald-600 mt-1">
            Official verifiable credentials
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span>Registered Doubt Sessions</span>
            <Calendar className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-2">
            {upcomingRegisteredSessions.length}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Next on Thursday via Meet
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span>Doubts Submitted</span>
            <HelpCircle className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-2">
            {myDoubts.length}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            {myDoubts.filter(d => d.status === 'resolved').length} resolved by instructors
          </div>
        </div>

      </div>

      {/* Main Grid: Courses In Progress & Side Widgets */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column (8 cols): Enrolled Courses */}
        <div className="lg:col-span-8 space-y-6">
          
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-900">
              My Courses ({enrolledCourses.length})
            </h2>
            <button
              onClick={onExploreMore}
              className="text-xs font-semibold text-blue-600 hover:text-blue-700"
            >
              Browse All Courses →
            </button>
          </div>

          {enrolledCourses.length === 0 ? (
            <div className="bg-white rounded-xl border border-slate-200 p-12 text-center space-y-3">
              <BookOpen className="w-10 h-10 text-slate-300 mx-auto" />
              <h3 className="text-sm font-bold text-slate-700">No Courses Enrolled Yet</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Explore our catalog of recorded video courses and start building your certification portfolio.
              </p>
              <button
                onClick={onExploreMore}
                className="px-4 py-2 text-xs font-bold text-white bg-blue-600 rounded-lg shadow-sm"
              >
                Browse Catalog
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {enrolledCourses.map(course => {
                const percent = getCourseCompletionPercentage(course.id);
                const cert = certificates.find(
                  c => c.courseId === course.id && c.studentId === currentUser?.id
                );

                return (
                  <div
                    key={course.id}
                    className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs hover:shadow-md transition-all flex flex-col sm:flex-row gap-5 items-start sm:items-center justify-between"
                  >
                    <div className="flex items-center gap-4">
                      <img
                        src={course.imageUrl}
                        alt={course.title}
                        className="w-24 h-16 rounded-lg object-cover bg-slate-900 shrink-0"
                      />
                      <div className="space-y-1">
                        <div className="text-[11px] text-slate-400 font-medium">
                          {course.category} · Instructor: {course.teacherName}
                        </div>
                        <h3 className="text-sm font-bold text-slate-900 line-clamp-1">
                          {course.title}
                        </h3>
                        
                        {/* Progress Bar */}
                        <div className="flex items-center gap-3 pt-1">
                          <div className="w-32 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-blue-600 rounded-full"
                              style={{ width: `${percent}%` }}
                            />
                          </div>
                          <span className="text-xs font-semibold text-slate-700">
                            {percent}% watched
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 self-end sm:self-center">
                      {cert && (
                        <button
                          onClick={() => onOpenCertificateModal(cert)}
                          className="px-3 py-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg flex items-center gap-1.5"
                        >
                          <Award className="w-3.5 h-3.5" />
                          <span>Certificate</span>
                        </button>
                      )}

                      <button
                        onClick={() => onSelectCourse(course.id)}
                        className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs flex items-center gap-1.5"
                      >
                        <span>Resume Lectures</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Earned Certificates Showcase */}
          {myCertificates.length > 0 && (
            <div className="space-y-4 pt-4">
              <h2 className="text-base font-bold text-slate-900">
                Earned Certificates ({myCertificates.length})
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {myCertificates.map(cert => (
                  <div
                    key={cert.id}
                    className="bg-white rounded-xl border border-slate-200 p-5 space-y-3 shadow-xs hover:border-blue-300 transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
                        <Award className="w-4 h-4" />
                      </div>
                      <span className="font-mono text-[11px] text-slate-400">{cert.id}</span>
                    </div>

                    <div>
                      <h4 className="text-xs font-bold text-slate-900 line-clamp-1">
                        {cert.courseTitle}
                      </h4>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Issued: {cert.issueDate} · Exam Score: {cert.scorePercentage}%
                      </p>
                    </div>

                    <button
                      onClick={() => onOpenCertificateModal(cert)}
                      className="w-full py-2 text-xs font-semibold text-blue-600 hover:text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors"
                    >
                      View & Download Credential
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Right Column (4 cols): Scheduled Doubt Sessions & Quick Reminders */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Upcoming Live Doubt Sessions */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-4 shadow-xs">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                Upcoming Doubt Sessions
              </h3>
              <button
                onClick={onNavigateToSessions}
                className="text-[11px] font-semibold text-blue-600 hover:underline"
              >
                All Sessions
              </button>
            </div>

            <div className="divide-y divide-slate-100">
              {doubtSessions.slice(0, 3).map(session => (
                <div key={session.id} className="py-3 space-y-1.5 first:pt-0 last:pb-0">
                  <div className="text-[11px] font-semibold text-blue-600">
                    {session.courseTitle}
                  </div>
                  <h4 className="text-xs font-bold text-slate-900 leading-snug">
                    {session.topic}
                  </h4>
                  <div className="flex items-center gap-3 text-[11px] text-slate-400">
                    <span>{session.sessionDate}</span>
                    <span>·</span>
                    <span>{session.startTime} UTC</span>
                  </div>
                  <div className="pt-1">
                    <a
                      href={session.meetingLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-[11px] font-semibold text-white bg-blue-600 hover:bg-blue-700 px-2.5 py-1 rounded-md"
                    >
                      <Video className="w-3 h-3" />
                      <span>Join Google Meet</span>
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Doubts Activity */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-3 shadow-xs">
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
              Recent Doubts Activity
            </h3>
            
            {myDoubts.length === 0 ? (
              <p className="text-xs text-slate-500">
                You haven't asked any doubts yet. Have a question while watching? Click "Ask a Doubt" inside any lesson!
              </p>
            ) : (
              <div className="space-y-2.5">
                {myDoubts.slice(0, 3).map(d => (
                  <div key={d.id} className="p-3 bg-slate-50 rounded-lg text-xs space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-800 truncate max-w-[170px]">{d.title}</span>
                      <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${
                        d.status === 'resolved' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {d.status}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400">
                      {d.replies.length} replies
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>

      </div>

    </div>
  );
};
