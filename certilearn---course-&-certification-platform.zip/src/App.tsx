import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { CourseProvider, useCourse } from './context/CourseContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { HomePage } from './components/HomePage';
import { CourseExplorer } from './components/CourseExplorer';
import { ClassroomView } from './components/ClassroomView';
import { DoubtSessionsView } from './components/DoubtSessionsView';
import { CertificateVerifier } from './components/CertificateVerifier';
import { StudentDashboard } from './components/StudentDashboard';
import { TeacherDashboard } from './components/TeacherDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { ExamModal } from './components/ExamModal';
import { CertificateModal } from './components/CertificateModal';
import { DoubtModal } from './components/DoubtModal';
import { CppArchitectureModal } from './components/CppArchitectureModal';
import { AuthModal } from './components/AuthModal';
import { Certificate, UserRole } from './types';

function MainApp() {
  const { currentUser } = useAuth();
  const { courses, certificates } = useCourse();

  // Navigation State
  const [currentView, setCurrentView] = useState<string>('home');
  const [selectedCourseId, setSelectedCourseId] = useState<string>('course-python-101');

  // Modals
  const [showExamModal, setShowExamModal] = useState(false);
  const [showCertificateModal, setShowCertificateModal] = useState(false);
  const [activeCertificate, setActiveCertificate] = useState<Certificate | null>(null);
  const [showDoubtModal, setShowDoubtModal] = useState(false);
  const [doubtModalLessonId, setDoubtModalLessonId] = useState<string | undefined>(undefined);
  const [showCppDocs, setShowCppDocs] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');

  // Selected Course
  const activeCourse = courses.find(c => c.id === selectedCourseId) || courses[0];

  const handleSelectCourse = (courseId: string) => {
    setSelectedCourseId(courseId);
    setCurrentView('classroom');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenCertificate = (cert?: Certificate) => {
    if (cert) {
      setActiveCertificate(cert);
    } else {
      // Find cert for active course or fallback
      const found = certificates.find(
        c => c.courseId === selectedCourseId && c.studentId === currentUser?.id
      ) || certificates[0];
      setActiveCertificate(found || null);
    }
    setShowCertificateModal(true);
  };

  const handleOpenAuth = (mode: 'login' | 'register' = 'login') => {
    setAuthMode(mode);
    setShowAuthModal(true);
  };

  const handleOpenDoubtModal = (lessonId?: string) => {
    setDoubtModalLessonId(lessonId);
    setShowDoubtModal(true);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      
      {/* Top Bar adhering to Universal Design Top Bar Contract */}
      <Navbar
        currentView={currentView}
        setCurrentView={setCurrentView}
        onOpenAuth={handleOpenAuth}
        onOpenCppDocs={() => setShowCppDocs(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        
        {currentView === 'home' && (
          <HomePage
            onSelectCourse={handleSelectCourse}
            onExplore={() => {
              setCurrentView('explore');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onOpenDoubtSessions={() => {
              setCurrentView('doubt-sessions');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onVerify={() => {
              setCurrentView('verify-certificate');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onOpenAuth={handleOpenAuth}
          />
        )}

        {currentView === 'explore' && (
          <CourseExplorer onSelectCourse={handleSelectCourse} />
        )}

        {currentView === 'classroom' && activeCourse && (
          <ClassroomView
            course={activeCourse}
            onOpenExam={() => setShowExamModal(true)}
            onOpenCertificate={() => handleOpenCertificate()}
            onOpenDoubtModal={handleOpenDoubtModal}
          />
        )}

        {currentView === 'doubt-sessions' && (
          <DoubtSessionsView
            onScheduleNew={() => {
              setCurrentView('teacher-dashboard');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {currentView === 'verify-certificate' && (
          <CertificateVerifier
            onViewCertificateModal={(cert) => {
              setActiveCertificate(cert);
              setShowCertificateModal(true);
            }}
          />
        )}

        {currentView === 'student-dashboard' && (
          <StudentDashboard
            onSelectCourse={handleSelectCourse}
            onOpenCertificateModal={(cert) => {
              setActiveCertificate(cert);
              setShowCertificateModal(true);
            }}
            onNavigateToSessions={() => setCurrentView('doubt-sessions')}
            onExploreMore={() => setCurrentView('explore')}
          />
        )}

        {currentView === 'teacher-dashboard' && (
          <TeacherDashboard onSelectCourse={handleSelectCourse} />
        )}

        {currentView === 'admin-dashboard' && (
          <AdminDashboard
            onOpenCppDocs={() => setShowCppDocs(true)}
            onOpenCertificateModal={(cert) => {
              setActiveCertificate(cert);
              setShowCertificateModal(true);
            }}
          />
        )}

      </main>

      {/* Footer with contact, links and architecture info */}
      <Footer
        onNavigate={(view) => {
          setCurrentView(view);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenCppDocs={() => setShowCppDocs(true)}
      />

      {/* Modals */}
      {showExamModal && activeCourse && (
        <ExamModal
          course={activeCourse}
          onClose={() => setShowExamModal(false)}
          onCertificateEarned={() => {
            const cert = certificates.find(c => c.courseId === activeCourse.id);
            if (cert) {
              setActiveCertificate(cert);
              setShowCertificateModal(true);
            }
          }}
        />
      )}

      {showCertificateModal && activeCertificate && (
        <CertificateModal
          certificate={activeCertificate}
          onClose={() => setShowCertificateModal(false)}
        />
      )}

      {showDoubtModal && (
        <DoubtModal
          courseId={selectedCourseId}
          initialLessonId={doubtModalLessonId}
          onClose={() => setShowDoubtModal(false)}
        />
      )}

      {showCppDocs && (
        <CppArchitectureModal onClose={() => setShowCppDocs(false)} />
      )}

      {showAuthModal && (
        <AuthModal
          initialMode={authMode}
          onClose={() => setShowAuthModal(false)}
          onSuccess={(role: UserRole) => {
            if (role === 'student') setCurrentView('student-dashboard');
            else if (role === 'teacher') setCurrentView('teacher-dashboard');
            else if (role === 'admin') setCurrentView('admin-dashboard');
          }}
        />
      )}

    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <CourseProvider>
        <MainApp />
      </CourseProvider>
    </AuthProvider>
  );
}
