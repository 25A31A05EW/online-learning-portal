import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Course,
  Doubt,
  DoubtSession,
  Assignment,
  AssignmentSubmission,
  Certificate,
  VideoProgress,
  ExamAttempt
} from '../types';
import {
  INITIAL_COURSES,
  INITIAL_DOUBTS,
  INITIAL_DOUBT_SESSIONS,
  INITIAL_ASSIGNMENTS,
  INITIAL_SUBMISSIONS,
  INITIAL_CERTIFICATES,
  PYTHON_EXAM_QUESTIONS
} from '../data/initialData';
import { useAuth } from './AuthContext';

interface CourseContextType {
  courses: Course[];
  enrolledCourseIds: string[];
  enrollInCourse: (courseId: string) => void;
  isEnrolled: (courseId: string) => boolean;
  videoProgress: Record<string, VideoProgress>; // key: `${userId}_${courseId}_${lessonId}`
  saveVideoProgress: (courseId: string, lessonId: string, seconds: number, totalSeconds: number, markCompleted?: boolean) => void;
  getLessonProgress: (courseId: string, lessonId: string) => VideoProgress | undefined;
  getCourseCompletionPercentage: (courseId: string) => number;
  doubts: Doubt[];
  submitDoubt: (courseId: string, lessonId: string | undefined, title: string, description: string, screenshotUrl?: string) => void;
  replyToDoubt: (doubtId: string, content: string) => void;
  resolveDoubt: (doubtId: string) => void;
  doubtSessions: DoubtSession[];
  registerForSession: (sessionId: string) => void;
  createDoubtSession: (session: Omit<DoubtSession, 'id' | 'registeredStudentIds' | 'status'>) => void;
  assignments: Assignment[];
  submissions: AssignmentSubmission[];
  submitAssignment: (assignmentId: string, courseId: string, text: string, attachmentName?: string) => void;
  gradeSubmission: (submissionId: string, marks: number, feedback: string) => void;
  certificates: Certificate[];
  verifyCertificateById: (certId: string) => Certificate | undefined;
  submitExam: (courseId: string, answers: { [qId: string]: number }) => ExamAttempt;
  createCourse: (newCourse: Partial<Course>) => void;
  updateCourse: (courseId: string, updated: Partial<Course>) => void;
  addLessonToCourse: (courseId: string, moduleId: string, lesson: any) => void;
}

const CourseContext = createContext<CourseContextType | undefined>(undefined);

export const CourseProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();

  // Load state from localStorage or initial dataset
  const [courses, setCourses] = useState<Course[]>(() => {
    const saved = localStorage.getItem('certilearn_courses');
    return saved ? JSON.parse(saved) : INITIAL_COURSES;
  });

  const [enrolledCourseIds, setEnrolledCourseIds] = useState<string[]>(() => {
    const saved = localStorage.getItem('certilearn_enrollments');
    return saved ? JSON.parse(saved) : ['course-python-101']; // Enrolled in Python by default for rich preview
  });

  const [videoProgress, setVideoProgress] = useState<Record<string, VideoProgress>>(() => {
    const saved = localStorage.getItem('certilearn_videoprogress');
    if (saved) return JSON.parse(saved);
    // Pre-seed some progress for demonstration
    return {
      'user-student-1_course-python-101_les-py-1-1': {
        userId: 'user-student-1',
        courseId: 'course-python-101',
        lessonId: 'les-py-1-1',
        watchedSeconds: 1080,
        totalSeconds: 1080,
        completed: true,
        lastWatchedAt: '2026-03-01'
      },
      'user-student-1_course-python-101_les-py-1-2': {
        userId: 'user-student-1',
        courseId: 'course-python-101',
        lessonId: 'les-py-1-2',
        watchedSeconds: 1440,
        totalSeconds: 1440,
        completed: true,
        lastWatchedAt: '2026-03-02'
      },
      'user-student-1_course-python-101_les-py-1-3': {
        userId: 'user-student-1',
        courseId: 'course-python-101',
        lessonId: 'les-py-1-3',
        watchedSeconds: 450,
        totalSeconds: 1200,
        completed: false,
        lastWatchedAt: '2026-03-03'
      }
    };
  });

  const [doubts, setDoubts] = useState<Doubt[]>(() => {
    const saved = localStorage.getItem('certilearn_doubts');
    return saved ? JSON.parse(saved) : INITIAL_DOUBTS;
  });

  const [doubtSessions, setDoubtSessions] = useState<DoubtSession[]>(() => {
    const saved = localStorage.getItem('certilearn_sessions');
    return saved ? JSON.parse(saved) : INITIAL_DOUBT_SESSIONS;
  });

  const [assignments] = useState<Assignment[]>(INITIAL_ASSIGNMENTS);

  const [submissions, setSubmissions] = useState<AssignmentSubmission[]>(() => {
    const saved = localStorage.getItem('certilearn_submissions');
    return saved ? JSON.parse(saved) : INITIAL_SUBMISSIONS;
  });

  const [certificates, setCertificates] = useState<Certificate[]>(() => {
    const saved = localStorage.getItem('certilearn_certificates');
    return saved ? JSON.parse(saved) : INITIAL_CERTIFICATES;
  });

  // Sync state to LocalStorage
  useEffect(() => {
    localStorage.setItem('certilearn_courses', JSON.stringify(courses));
  }, [courses]);

  useEffect(() => {
    localStorage.setItem('certilearn_enrollments', JSON.stringify(enrolledCourseIds));
  }, [enrolledCourseIds]);

  useEffect(() => {
    localStorage.setItem('certilearn_videoprogress', JSON.stringify(videoProgress));
  }, [videoProgress]);

  useEffect(() => {
    localStorage.setItem('certilearn_doubts', JSON.stringify(doubts));
  }, [doubts]);

  useEffect(() => {
    localStorage.setItem('certilearn_sessions', JSON.stringify(doubtSessions));
  }, [doubtSessions]);

  useEffect(() => {
    localStorage.setItem('certilearn_submissions', JSON.stringify(submissions));
  }, [submissions]);

  useEffect(() => {
    localStorage.setItem('certilearn_certificates', JSON.stringify(certificates));
  }, [certificates]);

  const enrollInCourse = (courseId: string) => {
    if (!enrolledCourseIds.includes(courseId)) {
      setEnrolledCourseIds(prev => [...prev, courseId]);
      setCourses(prev =>
        prev.map(c =>
          c.id === courseId ? { ...c, enrolledStudentsCount: c.enrolledStudentsCount + 1 } : c
        )
      );
    }
  };

  const isEnrolled = (courseId: string) => enrolledCourseIds.includes(courseId);

  const saveVideoProgress = (
    courseId: string,
    lessonId: string,
    seconds: number,
    totalSeconds: number,
    markCompleted = false
  ) => {
    const userId = currentUser?.id || 'guest';
    const key = `${userId}_${courseId}_${lessonId}`;
    const isDone = markCompleted || (totalSeconds > 0 && seconds >= totalSeconds * 0.9);

    setVideoProgress(prev => ({
      ...prev,
      [key]: {
        userId,
        courseId,
        lessonId,
        watchedSeconds: Math.floor(seconds),
        totalSeconds: Math.floor(totalSeconds),
        completed: prev[key]?.completed || isDone,
        lastWatchedAt: new Date().toISOString()
      }
    }));
  };

  const getLessonProgress = (courseId: string, lessonId: string) => {
    const userId = currentUser?.id || 'guest';
    return videoProgress[`${userId}_${courseId}_${lessonId}`];
  };

  const getCourseCompletionPercentage = (courseId: string) => {
    const course = courses.find(c => c.id === courseId);
    if (!course || course.modules.length === 0) return 0;
    
    let totalLessons = 0;
    let completedLessons = 0;
    const userId = currentUser?.id || 'guest';

    course.modules.forEach(m => {
      m.lessons.forEach(l => {
        totalLessons++;
        const prog = videoProgress[`${userId}_${courseId}_${l.id}`];
        if (prog?.completed) {
          completedLessons++;
        }
      });
    });

    if (totalLessons === 0) return 0;
    return Math.round((completedLessons / totalLessons) * 100);
  };

  const submitDoubt = (
    courseId: string,
    lessonId: string | undefined,
    title: string,
    description: string,
    screenshotUrl?: string
  ) => {
    const course = courses.find(c => c.id === courseId);
    let lessonTitle: string | undefined;
    if (lessonId && course) {
      for (const m of course.modules) {
        const found = m.lessons.find(l => l.id === lessonId);
        if (found) {
          lessonTitle = found.title;
          break;
        }
      }
    }

    const newDoubt: Doubt = {
      id: `doubt-${Date.now()}`,
      courseId,
      courseTitle: course?.title || 'Course',
      lessonId,
      lessonTitle,
      studentId: currentUser?.id || 'anon',
      studentName: currentUser?.name || 'Student',
      studentAvatar: currentUser?.avatar,
      title,
      description,
      screenshotUrl,
      status: 'pending',
      createdAt: new Date().toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }),
      replies: []
    };

    setDoubts(prev => [newDoubt, ...prev]);
  };

  const replyToDoubt = (doubtId: string, content: string) => {
    if (!currentUser) return;
    const newReply = {
      id: `reply-${Date.now()}`,
      doubtId,
      authorId: currentUser.id,
      authorName: currentUser.name,
      authorRole: currentUser.role,
      authorAvatar: currentUser.avatar,
      content,
      createdAt: new Date().toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
    };

    setDoubts(prev =>
      prev.map(d => (d.id === doubtId ? { ...d, replies: [...d.replies, newReply] } : d))
    );
  };

  const resolveDoubt = (doubtId: string) => {
    setDoubts(prev =>
      prev.map(d => (d.id === doubtId ? { ...d, status: 'resolved' as const } : d))
    );
  };

  const registerForSession = (sessionId: string) => {
    const studentId = currentUser?.id || 'guest';
    setDoubtSessions(prev =>
      prev.map(s => {
        if (s.id === sessionId && !s.registeredStudentIds.includes(studentId)) {
          return { ...s, registeredStudentIds: [...s.registeredStudentIds, studentId] };
        }
        return s;
      })
    );
  };

  const createDoubtSession = (data: Omit<DoubtSession, 'id' | 'registeredStudentIds' | 'status'>) => {
    const newSession: DoubtSession = {
      ...data,
      id: `session-${Date.now()}`,
      registeredStudentIds: [],
      status: 'upcoming'
    };
    setDoubtSessions(prev => [newSession, ...prev]);
  };

  const submitAssignment = (
    assignmentId: string,
    courseId: string,
    text: string,
    attachmentName = 'solution_submission.py'
  ) => {
    const newSub: AssignmentSubmission = {
      id: `sub-${Date.now()}`,
      assignmentId,
      courseId,
      studentId: currentUser?.id || 'student-1',
      studentName: currentUser?.name || 'Student',
      submissionText: text,
      attachmentName,
      submittedAt: new Date().toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }),
      status: 'submitted'
    };
    setSubmissions(prev => [newSub, ...prev]);
  };

  const gradeSubmission = (submissionId: string, marks: number, feedback: string) => {
    setSubmissions(prev =>
      prev.map(s =>
        s.id === submissionId
          ? {
              ...s,
              marksAwarded: marks,
              teacherFeedback: feedback,
              gradedAt: new Date().toISOString(),
              status: 'graded'
            }
          : s
      )
    );
  };

  const submitExam = (courseId: string, answers: { [qId: string]: number }): ExamAttempt => {
    const questions = PYTHON_EXAM_QUESTIONS; // In production this can be looked up per course
    let correctCount = 0;
    questions.forEach(q => {
      if (answers[q.id] === q.correctAnswerIndex) {
        correctCount++;
      }
    });

    const percentage = Math.round((correctCount / questions.length) * 100);
    const passed = percentage >= 70;

    const attempt: ExamAttempt = {
      id: `attempt-${Date.now()}`,
      courseId,
      studentId: currentUser?.id || 'anon',
      score: correctCount,
      totalQuestions: questions.length,
      percentage,
      passed,
      attemptedAt: new Date().toISOString(),
      answers
    };

    // If passed, automatically issue Certificate!
    if (passed && currentUser) {
      const course = courses.find(c => c.id === courseId);
      const randomSuffix = Math.floor(1000 + Math.random() * 9000);
      const code = `CL-VERIFY-${randomSuffix}-PY-2026`;
      const certId = `CERT-2026-PY-${randomSuffix}`;

      // Check if user already has certificate for this course
      const existing = certificates.find(
        c => c.courseId === courseId && c.studentId === currentUser.id
      );

      if (!existing) {
        const newCert: Certificate = {
          id: certId,
          courseId,
          courseTitle: course?.title || 'Professional Certification',
          studentId: currentUser.id,
          studentName: currentUser.name,
          issueDate: new Date().toISOString().split('T')[0],
          teacherName: course?.teacherName || 'Academic Director',
          scorePercentage: percentage,
          verificationCode: code
        };
        setCertificates(prev => [newCert, ...prev]);
      }
    }

    return attempt;
  };

  const verifyCertificateById = (certId: string) => {
    const cleanId = certId.trim().toUpperCase();
    return certificates.find(
      c => c.id.toUpperCase() === cleanId || c.verificationCode.toUpperCase() === cleanId
    );
  };

  const createCourse = (newCourseData: Partial<Course>) => {
    const newCourse: Course = {
      id: `course-${Date.now()}`,
      title: newCourseData.title || 'Untitled Course',
      subtitle: newCourseData.subtitle || 'Course description subtitle',
      description: newCourseData.description || '',
      category: newCourseData.category || 'Programming Languages',
      level: newCourseData.level || 'Beginner',
      durationHours: newCourseData.durationHours || 20,
      teacherId: currentUser?.id || 'user-teacher-1',
      teacherName: currentUser?.name || 'Dr. Elena Vance',
      teacherAvatar: currentUser?.avatar || 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80',
      teacherTitle: 'Lead Instructor',
      imageUrl: newCourseData.imageUrl || '/src/assets/images/course_python_hero_1794126944045.jpg',
      rating: 5.0,
      reviewCount: 1,
      status: 'published',
      passingPercentage: 70,
      enrolledStudentsCount: 0,
      requirements: ['Basic computer skills'],
      whatYouWillLearn: ['Master core concepts and applied projects'],
      modules: newCourseData.modules || [],
      materials: []
    };
    setCourses(prev => [newCourse, ...prev]);
  };

  const updateCourse = (courseId: string, updated: Partial<Course>) => {
    setCourses(prev => prev.map(c => (c.id === courseId ? { ...c, ...updated } : c)));
  };

  const addLessonToCourse = (courseId: string, moduleId: string, lesson: any) => {
    setCourses(prev =>
      prev.map(c => {
        if (c.id !== courseId) return c;
        return {
          ...c,
          modules: c.modules.map(m => {
            if (m.id !== moduleId) return m;
            return {
              ...m,
              lessons: [...m.lessons, { ...lesson, id: `les-${Date.now()}` }]
            };
          })
        };
      })
    );
  };

  return (
    <CourseContext.Provider
      value={{
        courses,
        enrolledCourseIds,
        enrollInCourse,
        isEnrolled,
        videoProgress,
        saveVideoProgress,
        getLessonProgress,
        getCourseCompletionPercentage,
        doubts,
        submitDoubt,
        replyToDoubt,
        resolveDoubt,
        doubtSessions,
        registerForSession,
        createDoubtSession,
        assignments,
        submissions,
        submitAssignment,
        gradeSubmission,
        certificates,
        verifyCertificateById,
        submitExam,
        createCourse,
        updateCourse,
        addLessonToCourse
      }}
    >
      {children}
    </CourseContext.Provider>
  );
};

export function useCourse() {
  const context = useContext(CourseContext);
  if (!context) {
    throw new Error('useCourse must be used within a CourseProvider');
  }
  return context;
}
