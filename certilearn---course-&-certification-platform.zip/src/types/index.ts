export type UserRole = 'student' | 'teacher' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  avatar?: string;
  bio?: string;
  joinedDate: string;
}

export interface Lesson {
  id: string;
  moduleId: string;
  title: string;
  durationMinutes: number;
  videoUrl: string; // Video URL or simulation stream
  description: string;
  codeSnippet?: string;
  codeLanguage?: string;
  order: number;
}

export interface Module {
  id: string;
  courseId: string;
  title: string;
  order: number;
  lessons: Lesson[];
}

export interface StudyMaterial {
  id: string;
  courseId: string;
  lessonId?: string;
  title: string;
  type: 'pdf' | 'ppt' | 'code' | 'doc';
  fileSize: string;
  downloadUrl: string;
  description: string;
  uploadedAt: string;
}

export interface Course {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  category: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  durationHours: number;
  teacherId: string;
  teacherName: string;
  teacherAvatar: string;
  teacherTitle: string;
  imageUrl: string;
  rating: number;
  reviewCount: number;
  modules: Module[];
  materials: StudyMaterial[];
  status: 'published' | 'draft' | 'under_review';
  passingPercentage: number;
  enrolledStudentsCount: number;
  requirements: string[];
  whatYouWillLearn: string[];
}

export interface VideoProgress {
  userId: string;
  courseId: string;
  lessonId: string;
  watchedSeconds: number;
  totalSeconds: number;
  completed: boolean;
  lastWatchedAt: string;
}

export interface DoubtReply {
  id: string;
  doubtId: string;
  authorId: string;
  authorName: string;
  authorRole: UserRole;
  authorAvatar?: string;
  content: string;
  createdAt: string;
}

export interface Doubt {
  id: string;
  courseId: string;
  courseTitle: string;
  lessonId?: string;
  lessonTitle?: string;
  studentId: string;
  studentName: string;
  studentAvatar?: string;
  title: string;
  description: string;
  screenshotUrl?: string;
  status: 'pending' | 'resolved';
  createdAt: string;
  replies: DoubtReply[];
}

export interface DoubtSession {
  id: string;
  courseId: string;
  courseTitle: string;
  teacherId: string;
  teacherName: string;
  teacherAvatar: string;
  topic: string;
  description: string;
  sessionDate: string; // YYYY-MM-DD
  startTime: string;   // HH:MM (e.g. 18:00)
  endTime: string;     // HH:MM (e.g. 19:30)
  meetingLink: string; // e.g. https://meet.google.com/xyz-qwer-tyu
  registeredStudentIds: string[];
  recordingUrl?: string;
  status: 'upcoming' | 'completed' | 'cancelled';
}

export interface Assignment {
  id: string;
  courseId: string;
  title: string;
  instructions: string;
  deadline: string;
  totalMarks: number;
  starterCode?: string;
}

export interface AssignmentSubmission {
  id: string;
  assignmentId: string;
  courseId: string;
  studentId: string;
  studentName: string;
  submissionText: string;
  attachmentName?: string;
  submittedAt: string;
  marksAwarded?: number;
  teacherFeedback?: string;
  gradedAt?: string;
  status: 'submitted' | 'graded';
}

export interface ExamQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswerIndex: number;
  explanation: string;
}

export interface ExamAttempt {
  id: string;
  courseId: string;
  studentId: string;
  score: number;
  totalQuestions: number;
  percentage: number;
  passed: boolean;
  attemptedAt: string;
  answers: { [questionId: string]: number };
}

export interface Certificate {
  id: string; // Unique ID, e.g., CERT-2026-PY-9842
  courseId: string;
  courseTitle: string;
  studentId: string;
  studentName: string;
  issueDate: string;
  teacherName: string;
  scorePercentage: number;
  verificationCode: string;
  certificateUrl?: string;
}
